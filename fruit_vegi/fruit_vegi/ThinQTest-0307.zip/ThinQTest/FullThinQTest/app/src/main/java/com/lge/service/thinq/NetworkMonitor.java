package com.lge.service.thinq;

import android.content.Context;

public class NetworkMonitor {



    public NetworkMonitor(Context context) {

    }

    public void onNetwork(boolean flag) {

    }
}
