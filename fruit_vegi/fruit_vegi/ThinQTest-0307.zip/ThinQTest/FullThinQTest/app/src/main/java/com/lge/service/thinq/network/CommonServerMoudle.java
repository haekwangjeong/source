package com.lge.service.thinq.network;

import android.content.Context;

import androidx.annotation.NonNull;

import com.lge.service.thinq.configuration.ConfigProxy;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class CommonServerMoudle {

    // TODO : Read from Config.json
    private final static int HTTP_TIMEOUT = 20;

    private Context mContext;

    private CommonServerInterface mCommonServerInterface;

    public CommonServerMoudle(Context context) {
        mContext = context;
    }

    @NonNull
    private Retrofit.Builder getRetroBuilder(String url) {
        return new Retrofit.Builder()
                .baseUrl(url)
                .client(getOkHttpClient())
                .addConverterFactory(GsonConverterFactory.create());
    }

    @NonNull
    private OkHttpClient getOkHttpClient() {
        return new OkHttpClient.Builder()
                .connectTimeout(HTTP_TIMEOUT, TimeUnit.SECONDS)
                .readTimeout(HTTP_TIMEOUT, TimeUnit.SECONDS)
                .writeTimeout(HTTP_TIMEOUT, TimeUnit.SECONDS)
                .addInterceptor(new HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY))
                .build();
    }

    public CommonServerInterface createCommonServerInterface() {
        String baseUrl = ConfigProxy.getInstance(mContext).getCommonServerUrl();
        baseUrl += "/";

        if (mCommonServerInterface == null) {
            mCommonServerInterface = getRetroBuilder(baseUrl).build().create(CommonServerInterface.class);
        }

        return mCommonServerInterface;
    }

}
