package com.lge.service.thinq.network;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/*
{
  "resultCode": "0000",
  "result": {
    "otp": "XXXX",
    "publicKey": "xxxxxxx"
  }
}
* */
public class CertResult {
    @SerializedName("resultCode")
    @Expose
    private String mResultCode;

    @SerializedName("result")
    @Expose
    private Cert mResult;

    public class Cert {
        @SerializedName("otp")
        @Expose
        private String mOTP;

        @SerializedName("publicKey")
        @Expose
        private String mKey;

        public String getOTP() { return mOTP; }

        public String getKEY() { return mKey; }
    }

    public String getResultCode() {
        return mResultCode;
    }

    public Cert getResult() {
        return mResult;
    }

    public boolean isSuccess() { return mResultCode.compareTo("0000") == 0; }
}
