package com.lge.service.thinq.network;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/*
{
  "resultCode": "0000",
  "result": {
    "alias": "냉장고3",
    "online": false,
    "order": 0,
    "regIndex": 0,
    "initDevice": false,
    "tclcount": 0
  }
}
* */
public class RegisteredDeviceResult {
    @SerializedName("resultCode")
    @Expose
    private String mResultCode;

    @SerializedName("result")
    @Expose
    private Result mResult;

    public class Result {
        @SerializedName("alias")
        @Expose
        private String mAlias;

        public String getAlias() { return mAlias; }
    }

    public String getResultCode() {
        return mResultCode;
    }

    public boolean isSuccess() { return mResultCode.compareTo("0000") == 0; }
}
