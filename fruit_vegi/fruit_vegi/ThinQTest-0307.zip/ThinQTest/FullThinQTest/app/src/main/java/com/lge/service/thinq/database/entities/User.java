package com.lge.service.thinq.database.entities;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "user")
public class User {
    @PrimaryKey
    @NonNull
    @ColumnInfo(name = "user_id")
    public String userId;

    @ColumnInfo(name = "displayName")
    public String displayName;

    @ColumnInfo(name = "deviceId")
    public String deviceId;

    @ColumnInfo(name = "user_number")
    public String userNo;

    @ColumnInfo(name = "accountType")
    public String accountType;  // LGE, GGL, FBK from EMP service

    @ColumnInfo(name = "loginType")
    public String loginType;  // emp, lga, ggl, fbk

    @ColumnInfo(name = "countryCode")
    public String countryCode;

    @ColumnInfo(name = "access_token")

    public String accessToken;

    @ColumnInfo(name = "refresh_token")
    public String refreshToken;

    @ColumnInfo(name = "oauth_backend_url")
    public String oAuthBackendUrl;

    @ColumnInfo(name = "token_expired_at")
    public long tokenExpiredAt;

    @ColumnInfo(name = "endpoint_url")
    public String endpointUrl;


    public User(String userId, String displayName, String deviceId, String userNo, String accountType, String loginType,
                String countryCode, String accessToken, String refreshToken, String oAuthBackendUrl, long tokenExpiredAt, String endpointUrl) {
        this.userId = userId;
        this.displayName = displayName;
        this.deviceId = deviceId;
        this.userNo = userNo;
        this.accountType = accountType;
        this.loginType = loginType;
        this.countryCode = countryCode;
        this.accessToken = accessToken;
        this.refreshToken = refreshToken;
        this.oAuthBackendUrl = oAuthBackendUrl;
        this.tokenExpiredAt = tokenExpiredAt;
        this.endpointUrl = endpointUrl;
    }

    @Override
    public String toString() {
        return "User{" +
                "userId='" + userId + '\'' +
                ", userNo='" + userNo + '\'' +
                ", displayId='" + deviceId + '\'' +
                ", displayName='" + displayName + '\'' +
                ", accountType='" + accountType + '\'' +
                ", loginType='" + loginType + '\'' +
                ", countryCode='" + countryCode + '\'' +
                ", accessToken='" + accessToken + '\'' +
                ", refreshToken='" + refreshToken + '\'' +
                ", oAuthBackendUrl='" + oAuthBackendUrl + '\'' +
                ", tokenExpiredAt=" + tokenExpiredAt + '\'' +
                ", endpointUrl=" + endpointUrl +
                '}';
    }
}
