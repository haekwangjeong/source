package com.lge.service.thinq;

/**
 * Provides constants that are defined somewhere else and must be cloned here
 */
final class ThinQExternalConstants {
    private ThinQExternalConstants() {
        throw new UnsupportedOperationException("contains only static constants");
    }

    static final String THINQ_SERVICE_INTERFACE = "com.lge.service.thinq.IThinQ";


}
