package com.lge.service.thinq.configuration;

import android.content.Context;
import android.util.Log;

import com.lge.service.thinq.ThinQConfigurationService;

import org.json.JSONException;
import com.google.gson.Gson;

import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;
import java.util.logging.LogManager;

// 주의 : target에는 com.lge.service.thinq.R로 넣어야함.
import com.lge.app.thinq.R;
import com.lge.service.thinq.utils.IdentifierGenerator;
import com.lge.service.thinq.utils.PreferencesManager;

public class ConfigProxy {

    private static String TAG = "ConfigProxy";

    private final Context mServiceContext;

    private static ConfigProxy mInstance;

    private final ConfigProxy.JsonReader mJsonReader;

    private ConfigObject mConfigObject;

    private String mServiceServerDomain;

    private String mCommonServerDomain;

    private String mOAuthDomain;

    private String mOAuthAppKey;

    private String mOAuthSecretKey;

    private static final String mSvcCode = "SVC202";

    public enum ConfigValue {
        TARGET_VERSION,
        TARGET_COUNTRY,
        TARGET_LANG_CODE,
        TARGET_STAGE,
        TARGET_MODELNAME,
        TARGET_DEVICE_TYPE,
        TARGET_DEVICE_ALIAS
    }

    interface JsonReader {
        /**
         * Returns the contents of the JSON file that is pointed to by the given {@code resId} as
         * a string.
         *
         * @param context The current Context.
         * @param resId The resource id of the JSON file.
         * @return A string representation of the file or {@code null} if an error occurred.
         */
        String jsonFileToString(Context context, int resId);
    }

    private enum OAUTH_SERVER_BASEURL {
        OP("https://%s.lgeapi.com"),
        QA("https://qa-%s.lgeapi.com"),
        ST("https://qa-%s.lgeapi.com");

        private String base_url;

        OAUTH_SERVER_BASEURL(String val) {
            base_url = val;
        }
    }

    private enum SERVICE_SERVER_BASEURL {
        OP("https://kic-service.lgthinq.com:46030"),
        QA("https://kic-qa-service.lgthinq.com:46030"),
        ST("https://kic-st-service.lgthinq.com:46030");

        private String base_url;

        SERVICE_SERVER_BASEURL(String val) {
            base_url = val;
        }
    }

    private enum COMMON_SERVER_BASEURL {
        OP("https://kic-common.lgthinq.com:443"),
        QA("https://kic-qa-common.lgthinq.com:443"),
        ST("https://kic-st-common.lgthinq.com:443");

        private String base_url;

        COMMON_SERVER_BASEURL(String val) {
            base_url = val;
        }
    }

    public ConfigProxy(Context context) {
        this.mServiceContext = context;
        this.mJsonReader = new JsonReaderImpl();

        init();
    }

    public synchronized static ConfigProxy getInstance(Context context) {
        if (mInstance == null) {
            mInstance = new ConfigProxy(context);
        }

        return mInstance;
    }

    private void init() {
        String jsonString = mJsonReader.jsonFileToString(mServiceContext, R.raw.thinq_config);

        if (jsonString != null) {
            Gson gson = new Gson();
            mConfigObject = gson.fromJson(jsonString, ConfigObject.class);
            Log.d(TAG, "configuration = " + mConfigObject.toString());

            mOAuthDomain = OAUTH_SERVER_BASEURL.valueOf(mConfigObject.getStage()).base_url;
            mOAuthDomain = String.format(mOAuthDomain,
                    mConfigObject.getCountry().toLowerCase(Locale.ROOT));

            mCommonServerDomain = COMMON_SERVER_BASEURL.valueOf(mConfigObject.getStage()).base_url;

            mServiceServerDomain = SERVICE_SERVER_BASEURL.valueOf(mConfigObject.getStage()).base_url;

            String stage = mConfigObject.getStage();
            if (stage.compareTo("OP") == 0) {
                mOAuthAppKey = StringConstants.OAUTH_OP_APIKEY;
                mOAuthSecretKey = StringConstants.OAUTH_OP_SECRETKEY;
            } else if (stage.compareTo("QA") == 0) {
                mOAuthAppKey = StringConstants.OAUTH_QA_APIKEY;
                mOAuthSecretKey = StringConstants.OAUTH_QA_SECRETKEY;
            } else {
                mOAuthAppKey = StringConstants.OAUTH_ST_APIKEY;
                mOAuthSecretKey = StringConstants.OAUTH_ST_SECRETKEY;
            }
        }

        String deviceId =
                PreferencesManager.getInstance(mServiceContext).getString("deviceId");

        if (deviceId.isEmpty()) {
            Log.d(TAG, "No device id, let's make this");
            deviceId = IdentifierGenerator.getRandomKey(32);
            PreferencesManager.getInstance(mServiceContext).setString("deviceId", deviceId);
        } else {
            Log.d(TAG, "Loaded from preference, deviceId = " + deviceId);
        }

        setDeviceId(deviceId);
    }

    public String getConfig(ConfigValue item) {
        String value;
        switch(item) {
            case TARGET_VERSION: value = mConfigObject.getVersion(); break;
            case TARGET_COUNTRY: value = mConfigObject.getCountry(); break;
            case TARGET_LANG_CODE: value = mConfigObject.getLangCode(); break;
            case TARGET_STAGE: value = mConfigObject.getStage(); break;
            case TARGET_MODELNAME: value = mConfigObject.getModelName(); break;
            case TARGET_DEVICE_TYPE: value = mConfigObject.getDeviceType(); break;
            case TARGET_DEVICE_ALIAS: value = mConfigObject.getDeviceAlias(); break;
            default : value = null; break;
        }

        return value;
    }

    public boolean isDebugMode() {
        return mConfigObject.getDebugMode();
    }

    public String getOAuthDomain() {
        return mOAuthDomain;
    }

    public String getServiceServerUrl() {
        return mServiceServerDomain;
    }

    public String getCommonServerUrl() {
        return mCommonServerDomain;
    }

    public String getOAuthAppKey() {
        return mOAuthAppKey;
    }

    public String getOAuthSecretKey() {
        return mOAuthSecretKey;
    }

    public String getThinQServiceCode() { return mSvcCode; }

    //        "appInfo": {
    //            "modelName": "SMARTREFGIDKR_T2",
    //            "modelLanguage": "01",
    //            "softVer": "1.0.0",
    //            "ruleVer": "1.0.0",
    //            "countryCode": "KR",
    //            "subCountryCode": "KR",
    //            "appVersion": "clip_hna_v1.0.001",
    //            "modemType": "M16",
    //            "regionalCode": "kic",
    //            "timezone": "+0900",
    //            "svcCode": "SVC202",
    //            "HomeApSsid": "HomeApSsid",
    //            "DeviceType": "101"
    //        },
    //        "platformInfo": {
    //            "provisioningKey": "SMARTREFGIDKR_T2",
    //            "version": "clip_v2.00.15-CLIP-webOS-5-RELEASE"
    //        }
    public String getDeviceProvisioningData() {

        return null;
    }

    //TODO : 임시
    public String getDeviceId() { return mConfigObject.getDeviceId(); }
    public void setDeviceId(String deviceId) { mConfigObject.setDeviceId(deviceId); }
}
