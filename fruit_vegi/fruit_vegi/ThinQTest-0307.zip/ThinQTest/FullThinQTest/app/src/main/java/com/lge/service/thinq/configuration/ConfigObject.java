package com.lge.service.thinq.configuration;

import com.google.gson.annotations.SerializedName;

public class ConfigObject {
    @SerializedName("version")
    private String mVersion;

    @SerializedName("country")
    private String mCountry;

    @SerializedName("language")
    private String mLangCode;

    @SerializedName("stage")
    private String mStage;

    @SerializedName("debug")
    private boolean mDebug;

    @SerializedName("modelName")
    private String mModelName;

    @SerializedName("device")
    private Device mDevice;

    class Device {
        @SerializedName("type")
        private String mType;

        @SerializedName("defaultAlias")
        private String mDefaultAlias;

        public String getType() { return mType; }

        public String getDefaultAlias() { return mDefaultAlias; }
    }

    @SerializedName("device-id")
    private String mDeviceId;

    public String getVersion() { return mVersion; }

    public String getCountry() { return mCountry; }

    public String getLangCode() { return mLangCode; }

    public String getStage() { return mStage; }

    public boolean getDebugMode() { return mDebug; }

    public String getModelName() { return mModelName; }

    public String getDeviceType() { return mDevice.getType(); }

    public String getDeviceAlias() { return mDevice.getDefaultAlias(); }

    public String getDeviceId() { return mDeviceId; }

    public void setDeviceId(String deviceId) { mDeviceId = deviceId; }

    @Override
    public String toString() {
        return new String(
                "version = " + mVersion + " country = " + mCountry
        );
    }
}
