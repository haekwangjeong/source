package com.lge.service.thinq;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import timber.log.Timber;

import com.lge.service.thinq.database.AppDatabase;
import com.lge.service.thinq.database.UserRepository;

import lge.home.thinq.ThinQError;

public class ThinQService extends Service {
    private static String TAG = "ThinQService";

    private static final String THINQ_SERVICE_NAME = "lge.home.thinq_service";

    private static final String PROPERTY_THINQ_SERVICE_CREATED = "boot.lge.thinq_service_created";

    private IThinQImpl mThinQImpl;

    private UserRepository mUserRepository;

    public ThinQService() {
    }

    @Override
    public void onCreate() {
        Log.d(TAG, "ThinQ Service onCreate");

        Timber.plant(new Timber.DebugTree());
        // 주의 : source upload시 해당 코드는 enable되면 안됨.
        //android.os.Debug.waitForDebugger();

//        InputStream logPropStream = this.getResources().openRawResource(R.raw.jsr47min);
//        try {
//            LogManager.getLogManager().readConfiguration(logPropStream);
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//
//        MqttLogger.reset(new MqttLogger());
//        java.util.logging.Logger.getLogger("org.eclipse.paho.client.mqttv3.*").setLevel(Level.ALL);

        mUserRepository = UserRepository.getInstance(AppDatabase.getInstance(this));

        if (mUserRepository == null) {
            Log.e(TAG, "Failed load user repository");
            throw new UnsupportedOperationException(ThinQError.ERROR_FETAL_ERROR.toString());
        }

        mThinQImpl = new IThinQImpl(this, mUserRepository);

        if (mThinQImpl == null) {
            Log.e(TAG, "Failed create mThinQImpl");
            throw new UnsupportedOperationException(ThinQError.ERROR_FETAL_ERROR.toString());
        }

        mThinQImpl.init();

        //ServiceManager.addService(THINQ_SERVICE_NAME, mThinQImpl);
        //SystemProperties.set(PROPERTY_THINQ_SERVICE_CREATED, "1");
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // keep it alive.
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return mThinQImpl;
    }

    @Override
    public void onDestroy() {
        Log.d(TAG, "ThinQ Service onDestroy");
        mThinQImpl.release();

        //ServiceManager.addService(THINQ_SERVICE_NAME, null);
        //SystemProperties.set(PROPERTY_THINQ_SERVICE_CREATED, "0");
        super.onDestroy();
    }
}