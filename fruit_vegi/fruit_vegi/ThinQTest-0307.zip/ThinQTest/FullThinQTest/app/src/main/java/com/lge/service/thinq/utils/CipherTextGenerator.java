package com.lge.service.thinq.utils;

import org.spongycastle.openssl.jcajce.JcaPEMWriter;
import org.spongycastle.operator.ContentSigner;
import org.spongycastle.operator.OperatorCreationException;
import org.spongycastle.operator.jcajce.JcaContentSignerBuilder;
import org.spongycastle.pkcs.PKCS10CertificationRequest;
import org.spongycastle.pkcs.PKCS10CertificationRequestBuilder;
import org.spongycastle.pkcs.jcajce.JcaPKCS10CertificationRequestBuilder;

import java.io.IOException;
import java.io.StringWriter;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.security.auth.x500.X500Principal;

public class CipherTextGenerator {

    static public String generateCipherText(Key signKey, String randomKey, String otp, String deviceId, String csr, String publicKey) {
        // randomKey(8)|otp(48)|SHA256(DeviceId)(32)|SHA256(CSR)(32)|SHA256(publicKey)(32)
        ByteBuffer buffer = ByteBuffer.allocate(152);

        SHA256 sha256 = new SHA256();

        // PART1 : stores random number;
        buffer.put(randomKey.getBytes(StandardCharsets.UTF_8));
        // PART2 : stores random number;
        buffer.put(otp.getBytes(StandardCharsets.UTF_8));

        try {
            // PART3-1
            byte[] hashedDeviceId = StringUtils.convertHexToBytes(sha256.encrypt(deviceId));
            // PART3-2
            buffer.put(hashedDeviceId);

            // PART4-1
            byte[] hashedCSR = StringUtils.convertHexToBytes(sha256.encrypt(csr));
            // PART4-2
            buffer.put(hashedCSR);

            // PART5-1
            byte[] hashedPublicKey = StringUtils.convertHexToBytes(sha256.encrypt(publicKey));
            // PART5-2
            buffer.put(hashedPublicKey);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }

        // set position to 0
        buffer.flip();

        return doEncryption(signKey, buffer);
    }

    static public String generateCipherText(Key signKey, String randomKey, String deviceId) {
        // PART1(0~ 7) : random number (8bytes)
        // PART2(8~40) : hashed plainTexts (32bytes)
        ByteBuffer buffer = ByteBuffer.allocate(40);

        SHA256 sha256 = new SHA256();

        // PART1 : stores random number;
        buffer.put(randomKey.getBytes(StandardCharsets.UTF_8));

        try {
            // PART2-1 : convert hex string to bytes array
            byte[] hashedBytes = StringUtils.convertHexToBytes(sha256.encrypt(deviceId));
            // PART2-2 : stores bytes array
            buffer.put(hashedBytes);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }

        // set position to 0
        buffer.flip();

        return doEncryption(signKey, buffer);
    }

    static private String doEncryption(Key signKey, ByteBuffer buffer) {
        String encodedString = null;

        try {
            Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            cipher.init(Cipher.ENCRYPT_MODE, signKey);
            byte[] digest = cipher.doFinal(buffer.array());
            encodedString = Base64.getEncoder().encodeToString(digest);
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | BadPaddingException | IllegalBlockSizeException e) {
            throw new RuntimeException(e);
        }

        return encodedString;
    }

    static public PublicKey convertStringToKey(String strKey) {
        PublicKey publicKey = null;

        // removes '\n' character.
        strKey = strKey.replace("\n", "");

        // removes BEGIN header
        strKey = strKey.replace("-----BEGIN PUBLIC KEY-----", "");

        // removes END header
        strKey = strKey.replace("-----END PUBLIC KEY-----", "");

        KeyFactory keyFactory = null;
        try {
            byte[] publicBytes = Base64.getDecoder().decode(strKey);
            X509EncodedKeySpec keySpec = new X509EncodedKeySpec(publicBytes);
            keyFactory = KeyFactory.getInstance("RSA");
            publicKey = keyFactory.generatePublic(keySpec);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (InvalidKeySpecException e) {
            e.printStackTrace();
        }

        return publicKey;
    }

    static public PKCS10CertificationRequest generateCSR(KeyPair pair, String cn) throws OperatorCreationException {
        PKCS10CertificationRequestBuilder csrBuilder = new JcaPKCS10CertificationRequestBuilder(
                new X500Principal("CN=" + cn), pair.getPublic());
        JcaContentSignerBuilder signerBuilder = new JcaContentSignerBuilder("SHA256withRSA");
        ContentSigner signer = signerBuilder.build(pair.getPrivate());
        return csrBuilder.build(signer);
    }

    static public String convertToPemString(Object object) throws IOException {
        StringWriter stringWriter = new StringWriter();
        JcaPEMWriter pemWriter = new JcaPEMWriter(stringWriter);

        pemWriter.writeObject(object);
        pemWriter.flush();
        pemWriter.close();

        return stringWriter.toString();
    }

    static public KeyPair generateKeyPair() throws NoSuchAlgorithmException, NoSuchProviderException {
        KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
        KeyPair pair = generator.generateKeyPair();
        return pair;
    }

}
