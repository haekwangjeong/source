package com.lge.app.thinq;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import timber.log.Timber;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.PreferenceFragmentCompat;

import lge.home.thinq.ThinQAgent;
import lge.home.thinq.ThinQConfigManager;
import lge.home.thinq.ThinQDeviceManager;

public class EmpLoginActivity extends AppCompatActivity {
    private ThinQAgent mAgent;
    public static Context mContext;
    private static final String TAG = "SettingActivity";
    private final Handler mHandler = new Handler(Looper.getMainLooper());

    private ThinQConfigManager mConfigManager;
    private ThinQDeviceManager mDeviceManager;
    private boolean mServiceReady = false;

    private String empUrl = "";
    private String returnUrl;
    boolean loadingFinished = true;
    boolean redirect = false;
    private String accesstoken;
    private String refreshtoken;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings_activity);

        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        Timber.plant(new Timber.DebugTree());

        createThinQService();
        mContext = this;

    }

    protected void runEmppage() {
        if (!mServiceReady) {
            Toast.makeText(mContext, "ThinQService unavailable", Toast.LENGTH_LONG);
            return;
        }

        WebView web = findViewById(R.id.run_webview);
        // enable scrollbar
        web.setVerticalScrollBarEnabled (true);
        web.getSettings().setJavaScriptEnabled(true); //웹페이지의 자바스크립트 허용
        empUrl = mConfigManager.getLogInUrl();
        web.loadUrl(empUrl);
        webPageInfo(web);
    }

    protected void webPageInfo(WebView web) {
        web.setWebViewClient(new WebViewClient() {

            public void onPageStarted(WebView view, String url) {
                loadingFinished = false;
            }

            public void onPageFinished(WebView view, String url) {

                if (!redirect) {
                    loadingFinished = true;
                    if(url.contains("access_token=")) {
                        int accessIndex = url.indexOf("access_token=");
                        int endIndex = url.indexOf("&refresh_token");

                        accesstoken = url.substring(accessIndex+13, endIndex);

                        int refreshIndex = url.indexOf("&refresh_token");
                        endIndex = url.indexOf("&oauth");
                        refreshtoken  = url.substring(refreshIndex+15, endIndex);
                        returnUrl = url;
                        changeActivity(false);
                    } else {

                    }
                    //HIDE LOADING IT HAS FINISHED
                } else {
                    redirect = false;

                }
            }
        });
    }
    protected void changeActivity(boolean isRegistered) {
        Intent intent = new Intent(EmpLoginActivity.this, MenuActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        intent.putExtra("accesstoken", accesstoken);
        intent.putExtra("refreshtoken", refreshtoken);
        intent.putExtra("url", empUrl);
        intent.putExtra("deviceRegistered", isRegistered);
        startActivity(intent);
    }

    public static class SettingsFragment extends PreferenceFragmentCompat {
        @Override
        public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
            setPreferencesFromResource(R.xml.root_preferences, rootKey);
        }
    }

    private void createThinQService() {
        mAgent = ThinQAgent.createThinQAgent(this, mHandler,
            (agent, ready) -> {
                if (!ready) {
                    mServiceReady = false;
                    return;
                }

                mServiceReady = true;
                mConfigManager = (ThinQConfigManager) agent.getManager(ThinQAgent.CONFIG_SERVICE);
                mDeviceManager = (ThinQDeviceManager) agent.getManager(ThinQAgent.DEVICE_SERVICE);

                //  이미 제품 등록이 되어 있는 경우
                boolean isRegistered=false;
                isRegistered = mDeviceManager.isDeviceRegistered();
                
                if (isRegistered) {
                    changeActivity(true);
                } else {
                    runEmppage();
                }
            });
    }
}