package com.lge.service.thinq.network;

import com.google.gson.JsonObject;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/*
{
  "resultCode": "0000",
  "result": {
  }
}
* */
public class BasicObjectResult {
    @SerializedName("resultCode")
    @Expose
    private String mResultCode;

    @SerializedName("result")
    @Expose
    private JsonObject mJsonResult;

    public String getResultCode() {
        return mResultCode;
    }

    public JsonObject getJsonResult() { return mJsonResult; }

    public boolean isSuccess() { return mResultCode.compareTo("0000") == 0; }
}
