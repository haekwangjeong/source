package com.lge.service.thinq.network;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class AddDeviceResult {
    @SerializedName("resultCode")
    @Expose
    private String mResultCode;
    @SerializedName("result")
    @Expose
    private String mResultMessage;

    public String getResultCode() {
        return mResultCode;
    }

    public String getResultMessage() {
        return mResultMessage;
    }

    public boolean isSuccess() { return mResultCode.compareTo("0000") == 0; }
}
