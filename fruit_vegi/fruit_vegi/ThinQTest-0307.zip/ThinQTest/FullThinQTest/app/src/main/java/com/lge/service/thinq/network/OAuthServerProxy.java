package com.lge.service.thinq.network;

import android.content.Context;
import android.os.Bundle;
import android.util.Base64;

import com.lge.service.thinq.DeviceStateMonitor;
import com.lge.service.thinq.configuration.ConfigProxy;
import com.lge.service.thinq.database.UserRepository;
import com.lge.service.thinq.database.entities.User;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Observable;
import java.util.Observer;
import java.util.concurrent.ExecutionException;
import android.util.Log;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import okhttp3.RequestBody;
import retrofit2.Call;
import timber.log.Timber;

public class OAuthServerProxy implements Observer {

    private static final String TAG = "OAuthProxy";

    private Context mServiceContext;

    private static OAuthServerProxy mInstance;

    private static final Object mLock = new Object();

    private OAuthServerInterface mOAuthInterface;

    private final String mAppKey;

    private final String mSecretKey;

    private UserRepository mUserRepository;

    private boolean mReadyUserRepository;

    private DeviceStateMonitor mDeviceStateMonitor;

    private User mUser;

    private static final String USER_NO = "userNo";

    private static final String USER_DISPLAY_ID = "userDiplayId";

    public synchronized static OAuthServerProxy getInstance(Context context, UserRepository userRepository) {
        if (mInstance == null) {
            mInstance = new OAuthServerProxy(context, userRepository);
        }

        return mInstance;
    }

    public OAuthServerProxy(Context context, UserRepository userRepository) {
        mServiceContext = context;
        mUserRepository = userRepository;

        mOAuthInterface =
                HttpAdapter.getInstance(mServiceContext).createOAuthServerModule();

        mAppKey = ConfigProxy.getInstance(context).getOAuthAppKey();

        mSecretKey = ConfigProxy.getInstance(context).getOAuthSecretKey();

        try {
            mReadyUserRepository = mUserRepository.hasUser();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void update(Observable o, Object arg) {
        if (o == mDeviceStateMonitor) {
            mReadyUserRepository = mDeviceStateMonitor.isDeviceRegistered();

            Log.d(TAG, "onUpdate device state mReadyUserRepository = " + mReadyUserRepository);
        }
    }

    public void setObserver(DeviceStateMonitor deviceMonitor) {
        mDeviceStateMonitor = deviceMonitor;
    }

    public boolean isReady() {
        return mReadyUserRepository;
    }

    public String getAccessToken(String refreshToken) {
        // STEP - 1
        // EMP에서 현재 Date & Time 가져온다.
        Call<OAuthDateTimeResult> call = mOAuthInterface.getDateTime(mAppKey);
        String dateString = null;
        try {
            dateString = call.execute().body().getDate();
            Timber.d("date = " + dateString);
        } catch (IOException e) {
            e.printStackTrace();
        }

        // STEP - 2
        // make signature
        String requestUri = "/oauth/1.0/oauth2/token?grant_type=refresh_token&refresh_token=";
        requestUri += refreshToken;
        String signature = makeSignature(requestUri, dateString);

        // STEP - 3
        // issue accessToken
        String bodyString = "grant_type=refresh_token&refresh_token=" + refreshToken;
        RequestBody reqBody = RequestBody.create(bodyString.getBytes(StandardCharsets.UTF_8));

        Call<OAuthTokenResult> tokenReq =
                mOAuthInterface.getAccessToken(mAppKey, signature, dateString, reqBody);

        String accessToken = null;
        long expires_in = 0;
        try {
            OAuthTokenResult result = tokenReq.execute().body();
            accessToken = result.getAccessToken();
            expires_in = result.getExpiresIn();
            Timber.d("response = " + accessToken);
        } catch (IOException e) {
            e.printStackTrace();
        }

        // STEP - 4
        // Stores Access Token and Time stamp (UserRepository)
        // expires_in is second, so we should convert second to milliseconds
        long expires_at = System.currentTimeMillis() + (expires_in * 1000);

        Timber.d("token expires_at = %s", String.valueOf(expires_at));

        try {
            mUserRepository.updateToken(accessToken, expires_at);
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        return accessToken;
    }

    public String getAccessToken() {
        String refreshToken;

        synchronized (mLock) {
            // UserRepository가 준비 안된 상태에서는 처리 할 수 없음.
            if (!mReadyUserRepository) {
                // TODO : Error process
                return null;
            }
        }

        // STEP - 1
        // 1시간 이내에 이미 발급 받은 Token이 있는지 검사한다.
        if (mUserRepository.hasValidToken()) {
            return mUserRepository.getAccessToken();
        }

        // STEP - 2
        // Refresh token이 저장 된게 있는지 검사
        refreshToken = mUserRepository.getRefreshToken();
        if (refreshToken.isEmpty()) {
            // TODO : Return json to describe Error Status
            return null;
        }

        return getAccessToken(refreshToken);
    }

    public Bundle getUserProfile(String accessToken) {

//        synchronized (mLock) {
//            // UserRepository가 준비 안된 상태에서는 처리 할 수 없음.
//            if (!mReadyUserRepository) {
//                // TODO : Error process
//                return null;
//            }
//        }

        // STEP - 1
        // EMP에서 현재 Date & Time 가져온다.
        Call<OAuthDateTimeResult> reqDateTime = mOAuthInterface.getDateTime(mAppKey);
        String dateString = null;
        try {
            dateString = reqDateTime.execute().body().getDate();
            Timber.d("date = " + dateString);
        } catch (IOException e) {
            e.printStackTrace();
        }

        // STEP - 2
        // make signature
        String requestUri = "/oauth/1.1/users/profile";
        String signature = makeSignature(requestUri, dateString);

        // STEP - 3
        // get accessToken
        String authString = "Bearer ";
        if (accessToken.isEmpty()) {
            authString += getAccessToken();
        } else {
            authString += accessToken;
        }

        // STEP - 4
        // request
        Call<OAuthUserAccountResult> reqUserProfile =
                mOAuthInterface.getUserProfile(
                        mAppKey,
                        signature,
                        dateString,
                        authString,
                        "a2:a4"
                );

        Bundle bundle = new Bundle();
        try {
            OAuthUserAccountResult resultBody = reqUserProfile.execute().body();
            OAuthUserProfileResult profileBody = resultBody.getUserProfile();
            bundle.putString(USER_NO, profileBody.getUserNo());
            bundle.putString(USER_DISPLAY_ID, profileBody.getDisplayId());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return bundle;
    }

    private String makeSignature(String requestUrl, String requestedDatetime) {
        String data = requestUrl + "\n" + requestedDatetime;

        SecretKeySpec signKey = new SecretKeySpec(mSecretKey.getBytes(), "HmacSHA1");
        Mac mac = null;
        try {
            mac = Mac.getInstance("HmacSHA1");
            mac.init(signKey);
        } catch (Exception e) {
            e.printStackTrace();
        }

        byte[] rawHmac = mac.doFinal(data.getBytes());
        String signature = Base64.encodeToString(rawHmac, Base64.NO_WRAP);
        Timber.d("signature:= %s", signature);
        Timber.d("String to sign(%s) %n", data);

        return signature;
    }
}
