package com.lge.service.thinq.configuration;


public class StringConstants {

    public final static String OAUTH_OP_APIKEY = "LGAO222A02";

    public final static String OAUTH_OP_SECRETKEY = "11cd263df3d9b640b46dc6fc9cb0be88";

    public final static String OAUTH_QA_APIKEY = "LGAO212A02";

    public final static String OAUTH_QA_SECRETKEY = "6a075a56c3c4aa1f62a65b75c9e38ce4";

    public final static String OAUTH_ST_APIKEY = "LGAO212A02";

    public final static String OAUTH_ST_SECRETKEY = "6a075a56c3c4aa1f62a65b75c9e38ce4";


}
