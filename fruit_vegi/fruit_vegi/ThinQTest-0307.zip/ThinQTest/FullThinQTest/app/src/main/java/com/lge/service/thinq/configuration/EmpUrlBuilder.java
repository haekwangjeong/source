package com.lge.service.thinq.configuration;

import android.text.TextUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/*
* Mobile Front UI 연동 규격서 참조
* http://collab.lge.com/main/pages/viewpage.action?pageId=266452152
* */
public class EmpUrlBuilder {
    private String mUrl;

    private static final String ALLOW_COUNTRY_LIST = "allow_country_list";
    private static final String CLIENT_ID = "client_id";
    private static final String COUNTRY = "country";
    private static final String DIVISION = "division";
    private static final String LANGUAGE = "language";
    private static final String OS = "os";
    private static final String SVC_LIST = "svc_list";
    private static final String SHOW_THIRDPARTY_LOGIN = "show_thirdparty_login";
    private static final String OAUTH_SVC_TYPE = "authSvr";
    private static final String OAUTH_GRANT_TYPE = "grant_type";
    private static final String DIRECT_LOGOUT = "directCancelMembership";

    private static final String SVC_CODE_VALUE = "SVC202";
    private static final String CLIENT_ID_VALUE = "LGAO212A02";
    private static final String DIVISION_VALUE = "ha";
    private static final String THIRDPARTY_LOGIN_VALUE = "Y";
    private static final String OAUTH_SVC_VALUE = "oauth2";
    private static final String OAUTH_GRANT_TYPE_VALUE = "password";
    private static final String OS_VALUE = "android";
    private static final String DIRECT_LOGOUT_VALUE = "Y";

    private static final String FRONT_USER_LOGIN_URL = "/login/sign_in";
    private static final String FRONT_USER_LOGOUT_URL = "/member/delete_account_intro";
    private static final String FRONT_SHOW_TERMS_URL = "/member/serviceTerms";
    private static final String FRONT_UPDATE_TERMS_URL = "/login/terms_update";

    public enum EMP_URL_TYPE {
        USER_LOGIN,
        USER_LOGOUT,
        SHOW_TERMS,
        UPDATE_TERMS,
    }

    private enum EMP_MOBILE_SERVER_BASEURL_FORMAT {
        OP("https://%s.m.lgaccount.com"),
        QA("https://qt-%s.m.lgaccount.com"),
        ST("https://qt-%s.m.lgaccount.com");

        private String base_url;

        EMP_MOBILE_SERVER_BASEURL_FORMAT(String val) {
            base_url = val;
        }
    }

    // IETF Language Code (5digits)
    private enum LANG_CODE {
        US("en-US"),
        KR("ko-KR");

        private String lang_code;

        LANG_CODE(String val) { lang_code = val; }
    }

    public String getUrl() {
        return mUrl;
    }

    public static class Builder {
        private String mCountry = "KR";
        private String mServerStage= "OP";
        private String mLanguage = "ko";
        private EMP_URL_TYPE mUrlType = EMP_URL_TYPE.USER_LOGIN;

        public Builder setCountry(String country) {
            this.mCountry = country;
            this.mLanguage = LANG_CODE.valueOf(mCountry).lang_code;
            return this;
        }

        public Builder setServerStage(String stage) {
            this.mServerStage = stage;
            return this;
        }

        public Builder setUrlType(EMP_URL_TYPE type) {
            this.mUrlType = type;
            return this;
        }

        private String makeLoginQuery() {
            Map<String, String> params = new HashMap<>();
            params.put(EmpUrlBuilder.ALLOW_COUNTRY_LIST, mCountry);
            params.put(EmpUrlBuilder.COUNTRY, mCountry);
            params.put(EmpUrlBuilder.LANGUAGE, LANG_CODE.valueOf(mCountry).lang_code);
            params.put(EmpUrlBuilder.SVC_LIST, SVC_CODE_VALUE);
            params.put(EmpUrlBuilder.CLIENT_ID, CLIENT_ID_VALUE);
            params.put(EmpUrlBuilder.OAUTH_SVC_TYPE, OAUTH_SVC_VALUE);
            params.put(EmpUrlBuilder.OAUTH_GRANT_TYPE, OAUTH_GRANT_TYPE_VALUE);
            params.put(EmpUrlBuilder.SHOW_THIRDPARTY_LOGIN, THIRDPARTY_LOGIN_VALUE);
            params.put(EmpUrlBuilder.DIVISION, DIVISION_VALUE);
            params.put(EmpUrlBuilder.OS, OS_VALUE);

            if (mUrlType == EMP_URL_TYPE.USER_LOGOUT) {
                params.put(EmpUrlBuilder.DIRECT_LOGOUT, DIRECT_LOGOUT_VALUE);
            }

            return toQueryParams(params);
        }

        private String toQueryParams(Map<String, String> paramsMap) {
            List<String> queries = new ArrayList();
            for (String key : paramsMap.keySet()) {
                queries.add(key + "=" + paramsMap.get(key));
            }
            return TextUtils.join("&", queries);
        }

        private String makeBaseUrl(String country, EMP_URL_TYPE urlType) {
            String baseUrl = EMP_MOBILE_SERVER_BASEURL_FORMAT.valueOf(mServerStage).base_url;
            String baseUrlPrefix = String.format(baseUrl, country.toLowerCase(Locale.ROOT));
            StringBuilder sb = new StringBuilder(baseUrlPrefix);

            switch (urlType) {
                case USER_LOGIN: sb.append(FRONT_USER_LOGIN_URL); break;
                case USER_LOGOUT: sb.append(FRONT_USER_LOGOUT_URL); break;
                case SHOW_TERMS: sb.append(FRONT_SHOW_TERMS_URL); break;
                case UPDATE_TERMS: sb.append(FRONT_UPDATE_TERMS_URL); break;
                default: sb.append(FRONT_USER_LOGIN_URL); break;
            }

            return sb.toString();
        }

        public EmpUrlBuilder build() {
            EmpUrlBuilder empUrlBuilder = new EmpUrlBuilder();
            // make up base url
            String baseUrl = makeBaseUrl(mCountry, mUrlType);

            // add query param delimeter
            baseUrl += "?";

            // make up login params
            baseUrl += makeLoginQuery();

            empUrlBuilder.mUrl = baseUrl;
            return empUrlBuilder;
        }
    }
}
