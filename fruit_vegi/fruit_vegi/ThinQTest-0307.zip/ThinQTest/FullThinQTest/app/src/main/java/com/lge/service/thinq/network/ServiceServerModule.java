package com.lge.service.thinq.network;

import android.content.Context;

import androidx.annotation.NonNull;

import com.lge.service.thinq.configuration.ConfigProxy;
import com.lge.service.thinq.database.UserRepository;
import com.lge.service.thinq.database.entities.User;
import com.lge.service.thinq.utils.IdentifierGenerator;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import okhttp3.Headers;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import timber.log.Timber;

public class ServiceServerModule {
    // TODO : Read from Config.json
    private final static int HTTP_TIMEOUT = 20;

    private Context mContext;

    private UserRepository mUserRepository;

    private ServiceServerInterface mServiceInterface;

    public ServiceServerModule(Context context) {
        mContext = context;
    }

    public ServiceServerInterface createServiceServerInterface(UserRepository userRepository) {
        String baseUrl = ConfigProxy.getInstance(mContext).getServiceServerUrl();
        baseUrl += "/";

        if (mServiceInterface == null) {
            mServiceInterface = getRetroBuilder(baseUrl).build().create(ServiceServerInterface.class);
        }

        mUserRepository = userRepository;

        return mServiceInterface;
    }

    @NonNull
    private Retrofit.Builder getRetroBuilder(String url) {
        return new Retrofit.Builder()
                .baseUrl(url)
                .client(getOkHttpClient())
                .addConverterFactory(GsonConverterFactory.create());
    }

    @NonNull
    private OkHttpClient getOkHttpClient() {
        return new OkHttpClient.Builder()
                .connectTimeout(HTTP_TIMEOUT, TimeUnit.SECONDS)
                .readTimeout(HTTP_TIMEOUT, TimeUnit.SECONDS)
                .writeTimeout(HTTP_TIMEOUT, TimeUnit.SECONDS)
                .addInterceptor(new HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY))
                .build();
    }
}
