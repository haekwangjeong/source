package com.lge.service.thinq.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class PreferencesManager {

    private static final String KEY_SHARED_PREFERENCES = "com.lge.service.thinq.thinq_preferences";

    public static final String PREF_REFRESH_TOKEN = "refresh_token";

    public static final String PREF_ACCESS_TOKEN = "access_token";

    public static final String PREF_ACCESS_TOKEN_TIMESTAMP = "access_token_timestamp";

    private static final String DEFAULT_VALUE_STRING = "";

    private static final int DEFAULT_VALUE_INTEGER = 0;

    private static final boolean DEFAULT_VALUE_BOOLEAN = false;

    private static PreferencesManager mInstance;

    private Context mContext;

    private PreferencesManager(Context context) {
        mContext = context;
    }

    public synchronized static PreferencesManager getInstance(Context context) {
        if (mInstance == null) {
            mInstance = new PreferencesManager(context);
        }
        return mInstance;
    }

    private static SharedPreferences getPreferences(Context context) {
        return context.getSharedPreferences(KEY_SHARED_PREFERENCES, Context.MODE_PRIVATE);
    }

    public void setString(String key, String value) {
        SharedPreferences prefs = getPreferences(mContext);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(key, value);
        editor.commit();
    }

    public String getString(String key) {
        SharedPreferences prefs = getPreferences(mContext);
        return prefs.getString(key, DEFAULT_VALUE_STRING);
    }

    public void setInteger(String key, int value) {
        SharedPreferences prefs = getPreferences(mContext);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt(key, value);
        editor.commit();
    }

    public int getInteger(String key) {
        SharedPreferences prefs = getPreferences(mContext);
        return prefs.getInt(key, DEFAULT_VALUE_INTEGER);
    }

    public void setBoolean(String key, boolean value) {
        SharedPreferences prefs = getPreferences(mContext);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean(key, value);
        editor.commit();
    }

    public boolean getBoolean(String key) {
        SharedPreferences prefs = getPreferences(mContext);
        return prefs.getBoolean(key, DEFAULT_VALUE_BOOLEAN);
    }
}
