package com.lge.service.thinq.mqtt;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.UnrecoverableEntryException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

public class MqttKeyManager {

    private static final String DEFAULT_ANDROID_KEYSTORE = "AndroidKeyStore";

    private static final String ALIAS_DEVICE_RSA_KEY = "THINQ_SERVICE_DEVICE_RSA_KEY";

    public static KeyStore buildKeyStore(X509Certificate certChain, PrivateKey key, char[] password)
            throws KeyStoreException, NoSuchAlgorithmException,
            CertificateException, IOException {
        KeyStore keyStore = KeyStore.getInstance(DEFAULT_ANDROID_KEYSTORE);
        keyStore.load(null);
        keyStore.setKeyEntry(ALIAS_DEVICE_RSA_KEY, key, password, new Certificate[] {certChain});
        return keyStore;
    }

    public static KeyStore getKeyStore(char[] password)
            throws KeyStoreException, NoSuchAlgorithmException,
            CertificateException, IOException, UnrecoverableEntryException {
        KeyStore keyStore = KeyStore.getInstance(DEFAULT_ANDROID_KEYSTORE);
        keyStore.load(null);
        KeyStore.Entry entry = keyStore.getEntry(ALIAS_DEVICE_RSA_KEY, null);
        keyStore.setKeyEntry(
                ALIAS_DEVICE_RSA_KEY,
                ((KeyStore.PrivateKeyEntry) entry).getPrivateKey(),
                password,
                ((KeyStore.PrivateKeyEntry) entry).getCertificateChain()
        );

        return keyStore;
    }

    public static boolean delete() {
        try {
            KeyStore keyStore = KeyStore.getInstance(DEFAULT_ANDROID_KEYSTORE);
            keyStore.load(null);
            keyStore.deleteEntry(ALIAS_DEVICE_RSA_KEY);
            return true;
        } catch (KeyStoreException | CertificateException | IOException | NoSuchAlgorithmException e) {
            e.printStackTrace();
        }

        return false;
    }

    public static X509Certificate generateX509Certificate(byte[] pem) throws IOException, CertificateException {
        CertificateFactory factory = CertificateFactory.getInstance("X.509");
        InputStream stream = new ByteArrayInputStream(pem);
        return (X509Certificate) factory.generateCertificate(stream);
    }

//    private static char[] getPassword() throws NoSuchAlgorithmException,
//            UnsupportedEncodingException {
//        MessageDigest md = MessageDigest.getInstance("SHA-256");
//        byte[] data = digest.digest(getDeviceId(mContext).getBytes("UTF-8"));
//        char[] password = new String(data, "UTF-8").toCharArray();
//        return password;
//    }

//    public void initialize() {
//        try {
//            // AndroidKeyStore 정확하게 기입
//            KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
//            ks.load(null);
//
//            // KeyStore에 해당 패키지 네임이 등록되어있는가?
//            if (!ks.containsAlias(getKeyStoreAlias())) {
//                generateKeyPair(getKeyStoreAlias());
//            }
//
//            mKeyEntry = ks.getEntry( mServiceContext.getPackageName(), null );
//        } catch (KeyStoreException |
//                IOException |
//                NoSuchAlgorithmException |
//                CertificateException |
//                UnrecoverableEntryException e) {
//            e.printStackTrace();
//        }
//    }

//    private void generateKeyPair(String alias) {
//        try {
//            KeyPairGenerator kpg =
//                    KeyPairGenerator.getInstance( KeyProperties.KEY_ALGORITHM_RSA, "AndroidKeyStore" );
//            kpg.initialize(
//                new KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_SIGN | KeyProperties.PURPOSE_VERIFY)
//                    .setAlgorithmParameterSpec(new RSAKeyGenParameterSpec(2048, RSAKeyGenParameterSpec.F4))
//                    .setBlockModes(KeyProperties.BLOCK_MODE_CBC)
//                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_RSA_PKCS1)
//                    .setDigests(KeyProperties.DIGEST_SHA512, KeyProperties.DIGEST_SHA384, KeyProperties.DIGEST_SHA256)
//                    .setSignaturePaddings(KeyProperties.SIGNATURE_PADDING_RSA_PKCS1)
//                    .setUserAuthenticationRequired(false)
//                    .build()
//            );
//
//            kpg.generateKeyPair();
//        } catch (NoSuchAlgorithmException |
//                NoSuchProviderException |
//                InvalidAlgorithmParameterException e) {
//            e.printStackTrace();
//        }
//    }

//    public KeyPair getDeviceKeyPair() {
//        try {
//            KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
//            keyStore.load(null);
//
//            Key key = keyStore.getKey(getKeyStoreAlias(), null);
//
//            if (key instanceof PrivateKey) {
//                // Get certificate of public key
//                Certificate cert = keyStore.getCertificate(getKeyStoreAlias());
//
//                // Get public key
//                PublicKey publicKey = cert.getPublicKey();
//
//                // Return a key pair
//                return new KeyPair(publicKey, (PrivateKey) key);
//            }
//         } catch (CertificateException |
//                IOException |
//                NoSuchAlgorithmException |
//                UnrecoverableKeyException |
//                KeyStoreException e) {
//            e.printStackTrace();
//        }
//
//        return null;
//    }


//    private static final String THE_CERT = "-----BEGIN CERTIFICATE-----\n" +
//            "MIIIPjCCByagAwIBAgIIWcyJ5Cnzp3UwDQYJKoZIhvcNAQELBQAwSTELMAkGA1UE\n" +
//            "BhMCVVMxEzARBgNVBAoTCkdvb2dsZSBJbmMxJTAjBgNVBAMTHEdvb2dsZSBJbnRl\n" +
//            "cm5ldCBBdXRob3JpdHkgRzIwHhcNMTgwMzEzMTgzMDQ1WhcNMTgwNjA1MTgxNjAw\n" +
//            "WjBmMQswCQYDVQQGEwJVUzETMBEGA1UECAwKQ2FsaWZvcm5pYTEWMBQGA1UEBwwN\n" +
//            "TW91bnRhaW4gVmlldzETMBEGA1UECgwKR29vZ2xlIEluYzEVMBMGA1UEAwwMKi5n\n" +
//            "b29nbGUuY29tMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAtXqeeS6r\n" +
//            "sLfE5dx5asD7dngw0Dev9rhgDYM9kAuV9VxbZJ2ehZM4Nk1zGGSlqidgRWsVSNrx\n" +
//            "qb513IyrtxDSvTTGh8ihFGNTL/H61e+cYU565RCw4siOU0IevyhynPVh8D38pe5U\n" +
//            "bkGDmkiP7tOVozQE+3Q7l6xaIvlq9hIAb0aTWdJ6AOm3r/iMRdiUv/kxIienQ4v/\n" +
//            "RY/h3K/llz1E+S+TAyM2+As8o2nRMGrp9/hg8zIs3CLLv2km9VS/fgTQrM5pcfDf\n" +
//            "iX6Tgzb+6RSGHnT7GgNA3R1LXo96gnwf3zlX3SqpvV8pQf2Y3TxhLRB7J28yZFef\n" +
//            "P6d9t2EqlHZv+wIDAQABo4IFCzCCBQcwEwYDVR0lBAwwCgYIKwYBBQUHAwEwggPh\n" +
//            "BgNVHREEggPYMIID1IIMKi5nb29nbGUuY29tgg0qLmFuZHJvaWQuY29tghYqLmFw\n" +
//            "cGVuZ2luZS5nb29nbGUuY29tghIqLmNsb3VkLmdvb2dsZS5jb22CFCouZGI4MzM5\n" +
//            "NTMuZ29vZ2xlLmNuggYqLmcuY2+CDiouZ2NwLmd2dDIuY29tghYqLmdvb2dsZS1h\n" +
//            "bmFseXRpY3MuY29tggsqLmdvb2dsZS5jYYILKi5nb29nbGUuY2yCDiouZ29vZ2xl\n" +
//            "LmNvLmlugg4qLmdvb2dsZS5jby5qcIIOKi5nb29nbGUuY28udWuCDyouZ29vZ2xl\n" +
//            "LmNvbS5hcoIPKi5nb29nbGUuY29tLmF1gg8qLmdvb2dsZS5jb20uYnKCDyouZ29v\n" +
//            "Z2xlLmNvbS5jb4IPKi5nb29nbGUuY29tLm14gg8qLmdvb2dsZS5jb20udHKCDyou\n" +
//            "Z29vZ2xlLmNvbS52boILKi5nb29nbGUuZGWCCyouZ29vZ2xlLmVzggsqLmdvb2ds\n" +
//            "ZS5mcoILKi5nb29nbGUuaHWCCyouZ29vZ2xlLml0ggsqLmdvb2dsZS5ubIILKi5n\n" +
//            "b29nbGUucGyCCyouZ29vZ2xlLnB0ghIqLmdvb2dsZWFkYXBpcy5jb22CDyouZ29v\n" +
//            "Z2xlYXBpcy5jboIUKi5nb29nbGVjb21tZXJjZS5jb22CESouZ29vZ2xldmlkZW8u\n" +
//            "Y29tggwqLmdzdGF0aWMuY26CDSouZ3N0YXRpYy5jb22CCiouZ3Z0MS5jb22CCiou\n" +
//            "Z3Z0Mi5jb22CFCoubWV0cmljLmdzdGF0aWMuY29tggwqLnVyY2hpbi5jb22CECou\n" +
//            "dXJsLmdvb2dsZS5jb22CFioueW91dHViZS1ub2Nvb2tpZS5jb22CDSoueW91dHVi\n" +
//            "ZS5jb22CFioueW91dHViZWVkdWNhdGlvbi5jb22CByoueXQuYmWCCyoueXRpbWcu\n" +
//            "Y29tghphbmRyb2lkLmNsaWVudHMuZ29vZ2xlLmNvbYILYW5kcm9pZC5jb22CG2Rl\n" +
//            "dmVsb3Blci5hbmRyb2lkLmdvb2dsZS5jboIcZGV2ZWxvcGVycy5hbmRyb2lkLmdv\n" +
//            "b2dsZS5jboIEZy5jb4IGZ29vLmdsghRnb29nbGUtYW5hbHl0aWNzLmNvbYIKZ29v\n" +
//            "Z2xlLmNvbYISZ29vZ2xlY29tbWVyY2UuY29tghhzb3VyY2UuYW5kcm9pZC5nb29n\n" +
//            "bGUuY26CCnVyY2hpbi5jb22CCnd3dy5nb28uZ2yCCHlvdXR1LmJlggt5b3V0dWJl\n" +
//            "LmNvbYIUeW91dHViZWVkdWNhdGlvbi5jb22CBXl0LmJlMGgGCCsGAQUFBwEBBFww\n" +
//            "WjArBggrBgEFBQcwAoYfaHR0cDovL3BraS5nb29nbGUuY29tL0dJQUcyLmNydDAr\n" +
//            "BggrBgEFBQcwAYYfaHR0cDovL2NsaWVudHMxLmdvb2dsZS5jb20vb2NzcDAdBgNV\n" +
//            "HQ4EFgQU2Xh9D7F5dJYCBqsWcKChI16NReswDAYDVR0TAQH/BAIwADAfBgNVHSME\n" +
//            "GDAWgBRK3QYWG7z2aLV29YG2u2IaulqBLzAhBgNVHSAEGjAYMAwGCisGAQQB1nkC\n" +
//            "BQEwCAYGZ4EMAQICMDAGA1UdHwQpMCcwJaAjoCGGH2h0dHA6Ly9wa2kuZ29vZ2xl\n" +
//            "LmNvbS9HSUFHMi5jcmwwDQYJKoZIhvcNAQELBQADggEBAFxBsH2U6j4KzZbNcyN1\n" +
//            "UGiJnMn64DIXH8wsWrFEGAq3ONRhPgKd3AnbaBUdNdrRgOhfA3RtLvvnxsKn0rX6\n" +
//            "Oz8+p5DZxJooUgWlet9NounLDe5um6m5NqLIGefdI49Ukn6IwBtCO5DD7rZTygTa\n" +
//            "B499H9N0ixI9wGBdlZ37tOpCxayNb08eizU1uQEhb1/oxnXf0e6trPfC8krDL0Ks\n" +
//            "Pyf3JgB5oBTiNAfix2zme1FrpXcKehOj2urnLQRr5EpminCJ+0uHI1sqiJbcSHrU\n" +
//            "6TPQcOzZ7/haw1yY2bpy+sB4oXUMaNJxh6e2AiCeVf4MtX9EsYEnhsfc2XS50J32\n" +
//            "nKo=\n" +
//            "-----END CERTIFICATE-----";
//
//    private void doExample() {
//        try {
//            X509Certificate googleCert = (X509Certificate) CertificateFactory.getInstance("X509").generateCertificate(new ByteArrayInputStream(THE_CERT.getBytes(StandardCharsets.UTF_8)));
//            KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
//            KeyProtection keyProtection = new KeyProtection.Builder(KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_VERIFY)
//                    .setDigests(KeyProperties.DIGEST_SHA1, KeyProperties.DIGEST_SHA256)
//                    .setRandomizedEncryptionRequired(true)
//                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_RSA_OAEP)
//                    .setSignaturePaddings(KeyProperties.SIGNATURE_PADDING_RSA_PSS)
//                    .setUserAuthenticationRequired(false)
//                    .build();
//            keyStore.load(null);
//            keyStore.setEntry("googlecert", new KeyStore.TrustedCertificateEntry(googleCert), keyProtection);
//            // Now use the entry
//            KeyGenerator aesKeygen = KeyGenerator.getInstance("AES");
//            aesKeygen.init(128);
//            Key aesKey = aesKeygen.generateKey();
//            // Wrap key for transport
//            KeyStore keyStore2 = KeyStore.getInstance("AndroidKeyStore");
//            keyStore2.load(null);
//            Certificate googleCert2 = keyStore2.getCertificate("googlecert");
//            Cipher rsaCipher = Cipher.getInstance("RSA/ECB/OAEPwithSHA-256andMGF1Padding");
//            rsaCipher.init(Cipher.WRAP_MODE, googleCert2);
//            byte[] rsaEncrypted = rsaCipher.wrap(aesKey);
//            Log.d("crypt", Base64.encodeToString(rsaEncrypted, Base64.DEFAULT));
//        } catch (Exception e) {
//            throw new RuntimeException(e);
//        }
//    }

}
