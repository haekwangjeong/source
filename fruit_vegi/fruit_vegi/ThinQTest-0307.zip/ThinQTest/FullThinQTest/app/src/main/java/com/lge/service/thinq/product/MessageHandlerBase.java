package com.lge.service.thinq.product;

import android.os.Handler;

import java.io.PrintWriter;
import java.util.List;

public interface MessageHandlerBase {
    /**
     * All necessary initialization should be done and service should be
     * functional after this.
     */
    void init();

    /**
     * should stop and all resources should be released.
     */
    void release();

    /**
     * should return handler to receive message
     */
    Handler getHandler();

    /**
     * should return command messge to handle it.
     * @return
     */
    List<String> getCommands();

    void dump(PrintWriter writer);
}
