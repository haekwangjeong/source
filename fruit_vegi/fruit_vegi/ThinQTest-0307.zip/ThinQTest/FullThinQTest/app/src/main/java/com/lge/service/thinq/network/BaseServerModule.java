package com.lge.service.thinq.network;

import android.content.Context;
import timber.log.Timber;

import androidx.annotation.NonNull;

import com.lge.service.thinq.utils.IdentifierGenerator;

import java.util.concurrent.TimeUnit;

import okhttp3.Headers;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public abstract class BaseServerModule {

    // TODO : Read from Config.json
    private final static int HTTP_TIMEOUT = 20;

    private Context mContext;

    private IdentifierGenerator mIdGenerator;

    public BaseServerModule(Context context) {
        mContext = context;
    }

    @NonNull
    protected Retrofit.Builder getRetroBuilder(String url) {
        return new Retrofit.Builder()
                .baseUrl(url)
                .client(getOkHttpClient())
                .addConverterFactory(GsonConverterFactory.create());
    }

    @NonNull
    protected OkHttpClient getOkHttpClient() {
        return new OkHttpClient.Builder()
                .connectTimeout(HTTP_TIMEOUT, TimeUnit.SECONDS)
                .readTimeout(HTTP_TIMEOUT, TimeUnit.SECONDS)
                .writeTimeout(HTTP_TIMEOUT, TimeUnit.SECONDS)
                .addInterceptor(chain -> {
                    Request original = chain.request();

                    Timber.d("getOkHttpClient = " + String.valueOf(original.url()));

                    Request request = original.newBuilder()
                            .headers(getHeader())
                            .method(original.method(), original.body())
                            .build();

                    return chain.proceed(request);
                })
                .addInterceptor(new HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY))
                /*.addInterceptor(new AuthInterceptor(mContext))*/
                .build();
    }

//    private Headers makeCommonHeader() {
//        Headers.Builder builder = CommonHeader.builder(mContext, mIdGenerator);
//
//        builder.set("x-api-key", getApiKey());
////        User user = userRepository.getUser();
////        if (user != null) {
////            builder.add("x-emp-token", user.accessToken);
////            builder.add("x-user-no", user.userNo);
////            builder.set("x-api-key", getApiKey());
////        }
//
//
//        return builder.build();
//    }

    protected abstract Headers getHeader();

}
