package com.lge.service.thinq.mqtt;

import com.amazonaws.services.iot.client.AWSIotMessage;
import com.amazonaws.services.iot.client.AWSIotQos;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.Random;

public class MqttMsgGenerator {
    private static final String JSON_KEY_MID = "mid";

    private static final String JSON_KEY_DID = "did";

    private static final String JSON_KEY_KIND = "kind";

    private static final String JSON_KEY_CMD = "cmd";

    private static final String JSON_KEY_DATA = "data";

    private static final String JSON_KEY_TYPE = "type";

    private static final String JSON_VALUE_REQ_TIMESYNC = "req_timesync";

    private static final String JSON_VALUE_DEVICE_PACKET = "device_packet";

    private static final String JSON_VALUE_DEPLOY = "deploy";

    private static final String JSON_VALUE_UNDEPLOY = "undeploy";

    private static final int TYPE_JSON = 0;

    private static final int TYPE_STRING = 1;

    private static final String PREFIX_PROVISIONING_TOPIC = "clip/provisioning/devices/";

    private static final String PREFIX_SUBSCRIBE_TOPIC = "lime/devices/";

    private static final String PREFIX_SEND_TOPIC = "clip/message/devices/";

    private final String mDeviceId;

    private final String mKind;

    public enum TopicType {
        TOPIC_WILL,
        TOPIC_PROVISIONING,
        TOPIC_PUBLISH,
        TOPIC_SUBSCRIBE,
    }

    public MqttMsgGenerator(String deviceId, String modelName) {
        mDeviceId = deviceId;
        mKind = modelName;
    }

    private int getMessageId() {
        int maximumValue = Integer.MAX_VALUE;

        Random random = new Random();
        int messageId = 0;
        try {
            messageId = random.nextInt(maximumValue);
        } catch(Exception e) {
            e.printStackTrace();
        }

        return messageId;
    }

    public String makeTopic(MqttMsgGenerator.TopicType type) {
        String topic = null;

        switch(type) {
            case TOPIC_WILL:
            case TOPIC_PROVISIONING:
                topic = PREFIX_PROVISIONING_TOPIC + mDeviceId;
                break;

            case TOPIC_SUBSCRIBE:
                topic = PREFIX_SUBSCRIBE_TOPIC + mDeviceId;
                break;

            case TOPIC_PUBLISH:
                topic = PREFIX_SEND_TOPIC + mDeviceId;
                break;
        }

        return topic;
    }

    public AWSIotMessage makeIotMessage(String topic, String payload) {
        return new AWSIotMessage(topic, AWSIotQos.QOS0, payload);
    }

    public AWSIotMessage makeWillMessage() {
        return new AWSIotMessage(makeTopic(TopicType.TOPIC_WILL), AWSIotQos.QOS0, getWillPayload());
    }

    // Makes will message
    //
    // # Samples
    //{
    //    "did": "4a7074688ea4a32cd257f7c672d56365",
    //    "kind": "SMARTREFGIDKR_T2",
    //    "cmd": "undeploy"
    //}
    public String getWillPayload() {
        JsonObject message = new JsonObject();
        message.addProperty(JSON_KEY_DID, mDeviceId);
        message.addProperty(JSON_KEY_KIND, mKind);
        message.addProperty(JSON_KEY_CMD, JSON_VALUE_UNDEPLOY);
        return message.toString();
    }

    // Makes request to sync time
    //
    // # Samples
    //{
    //    "mid": 34045,
    //    "did": "4a7074688ea4a32cd257f7c672d56365",
    //    "kind": "SMARTREFGIDKR_T2",
    //    "cmd": "req_timesync",
    //    "data": null,
    //    "type": 1
    //}
    public String getReqTimeSync() {
        JsonObject message = new JsonObject();
        message.addProperty(JSON_KEY_DID, mDeviceId);
        message.addProperty(JSON_KEY_MID, getMessageId());
        message.addProperty(JSON_KEY_KIND, mKind);
        message.addProperty(JSON_KEY_CMD, JSON_VALUE_REQ_TIMESYNC);
        message.add(JSON_KEY_DATA, null);
        message.addProperty(JSON_KEY_TYPE, TYPE_STRING);
        return message.toString();
    }

    // Makes device provisioning message
    //
    // # Samples
    //{
    //    "mid": 34029,
    //    "did": "4a7074688ea4a32cd257f7c672d56365",
    //    "kind": "SMARTREFGIDKR_T2",
    //    "cmd": "deploy",
    //    "data": {
    //        "appInfo": {
    //            "modelName": "SMARTREFGIDKR_T2",
    //            "modelLanguage": "01",
    //            "softVer": "1.0.0",
    //            "ruleVer": "1.0.0",
    //            "countryCode": "KR",
    //            "subCountryCode": "KR",
    //            "appVersion": "clip_hna_v1.0.001",
    //            "modemType": "M16",
    //            "regionalCode": "kic",
    //            "timezone": "+0900",
    //            "svcCode": "SVC202",
    //            "HomeApSsid": "HomeApSsid",
    //            "DeviceType": "101"
    //        },
    //        "platformInfo": {
    //            "provisioningKey": "SMARTREFGIDKR_T2",
    //            "version": "clip_v2.00.15-CLIP-webOS-5-RELEASE"
    //        }
    //    },
    //    "type": 0
    //}
    public String getProvisioningPayload(String data) {
        JsonObject jsonData = JsonParser.parseString(data).getAsJsonObject();
        return getProvisioningPayload(jsonData);
    }

    public String getProvisioningPayload(JsonObject data) {
        JsonObject message = new JsonObject();
        message.addProperty(JSON_KEY_DID, mDeviceId);
        message.addProperty(JSON_KEY_MID, getMessageId());
        message.addProperty(JSON_KEY_KIND, mKind);
        message.addProperty(JSON_KEY_CMD, JSON_VALUE_DEPLOY);
        message.add(JSON_KEY_DATA, data);
        message.addProperty(JSON_KEY_TYPE, TYPE_JSON);
        return message.toString();
    }

    // Makes device packet
    //
    // # Samples
    //{
    //    "mid": 34050,
    //    "did": "4a7074688ea4a32cd257f7c672d56365",
    //    "kind": "SMARTREFGIDKR_T2",
    //    "cmd": "device_packet",
    //    "data": "AA07F000CE3ABB",
    //    "type": 1
    //}
    public String getDevicePacketPayload(String data) {
        JsonObject message = new JsonObject();
        message.addProperty(JSON_KEY_DID, mDeviceId);
        message.addProperty(JSON_KEY_MID, getMessageId());
        message.addProperty(JSON_KEY_KIND, mKind);
        message.addProperty(JSON_KEY_CMD, JSON_VALUE_DEVICE_PACKET);
        message.addProperty(JSON_KEY_DATA, data);
        message.addProperty(JSON_KEY_TYPE, TYPE_STRING);
        return message.toString();
    }
}
