package com.lge.service.thinq.configuration;

import android.content.Context;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

public class JsonReaderImpl implements ConfigProxy.JsonReader {
    private static final int BUF_SIZE = 0x1000; // 2K chars (4K bytes)
    private static final String JSON_FILE_ENCODING = "UTF-8";

    /**
     * Takes a resource file that is considered to be a JSON file and parses it into a String that
     * is returned.
     *
     * @param resId The resource id pointing to the json file.
     * @return A {@code String} representing the file contents, or {@code null} if
     */
    @Override
    public String jsonFileToString(Context context, int resId) {
        InputStream is = context.getResources().openRawResource(resId);

        // Note: this "try" will close the Reader, thus closing the associated InputStreamReader
        // and InputStream.
        try (Reader reader = new BufferedReader(new InputStreamReader(is, JSON_FILE_ENCODING))) {
            char[] buffer = new char[BUF_SIZE];
            StringBuilder stringBuilder = new StringBuilder();

            int bufferedContent;
            while ((bufferedContent = reader.read(buffer)) != -1) {
                stringBuilder.append(buffer, /* offset= */ 0, bufferedContent);
            }

            return stringBuilder.toString();
        } catch (IOException e) {
            return null;
        }
    }
}
