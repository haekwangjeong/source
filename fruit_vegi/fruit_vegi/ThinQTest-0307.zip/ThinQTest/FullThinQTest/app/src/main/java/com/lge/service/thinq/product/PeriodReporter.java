package com.lge.service.thinq.product;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;

import com.lge.service.thinq.configuration.ConfigProxy;
import com.lge.service.thinq.mqtt.MqttMessageBroker;
import com.lge.service.thinq.mqtt.MqttMsgGenerator;
import com.lge.service.thinq.utils.StringUtils;
import com.lge.service.thinq.utils.ThreadUtil;

import java.util.Arrays;

import timber.log.Timber;

public class PeriodReporter {

    private final MqttMessageBroker mMessageBroker;

    private final HandlerThread mHandlerThread
            = ThreadUtil.getHandlerThread(getClass().getSimpleName());

    private final PeriodReporter.MessageHandler mHandler
            = new PeriodReporter.MessageHandler(mHandlerThread.getLooper(), this);

    byte[] mMonitoringData = null;

    boolean mIsWaitingFirstData = false;

    private static final class MessageHandler extends Handler {
        private static final String TAG =
                PeriodReporter.MessageHandler.class.getSimpleName();

        private static PeriodReporter mHost = null;

        private final int MSG_SHORT_TERM = 0 ;
        private final int MSG_LONG_TERM = 1 ;

        private MessageHandler(Looper looper, PeriodReporter host) {
            super(looper);
            mHost = host;
        }

        @Override
        public void handleMessage(Message msg) {
            switch(msg.what) {
                case MSG_SHORT_TERM: break;
                case MSG_LONG_TERM: break;
            }
        }
    }

    public PeriodReporter(MqttMessageBroker mMessageBroker) {
        this.mMessageBroker = mMessageBroker;

        mMonitoringData = new byte[BasePacket.LENGTH_MONITORING_PACKET];

        mIsWaitingFirstData = true;
    }

    public void updateMonitoringData(byte[] data, int length) {
        if (mIsWaitingFirstData) {
            mIsWaitingFirstData = false;

            System.arraycopy(data, 0, mMonitoringData, 0, length);
            mMonitoringData[BasePacket.PKT_FRAMEID_INDEX] = BasePacket.FID_EVENT_DRIVEN_DATA;

            // re-make crc number
            int packetLength = mMonitoringData[BasePacket.PKT_LENGTH_INDEX];
            mMonitoringData[packetLength-2] =
                    (byte) PacketUtil.makeCRC(mMonitoringData, packetLength-2);

            // send to cloudlet
            mMessageBroker.publish(mMonitoringData);
        } else {
            if (isChanged(data)) {
                // build a new assembled data.
                byte[] assembled = buildMonitoringData(mMonitoringData, data);

                // backup current monitoring data.
                System.arraycopy(data, 0, mMonitoringData, 0, length);

                // send to cloudlet
                mMessageBroker.publish(assembled);
            }
        }
    }

    private boolean isChanged(byte[] data) {
        boolean changed = false;

        // skip 6bytes (header(4),crc(1),footer(1)),
        // only compares from 4 ~ 21 (18bytes)
        for (int i=BasePacket.PKT_DATA_INDEX; i<BasePacket.LENGTH_MONITORING_DATA+BasePacket.PKT_DATA_INDEX; i++) {
            if (mMonitoringData[i] != data[i]) {
                changed = true;
                break;
            }
        }

        return changed;
    }

    private byte[] buildMonitoringData(byte[] before, byte[] after) {
        // 42 : header(4) | before(18) | after(18) | CRC(1) | Footer(1)
        int totalLength = BasePacket.LENGTH_MONITORING_PACKET_HEADER +
                (BasePacket.LENGTH_MONITORING_DATA * 2) +
                BasePacket.LENGTH_MONITORING_PACKET_CHECKSUM +
                BasePacket.LENGTH_MONITORING_PACKET_FOOTER;

        byte[] combined = new byte[totalLength];
        Arrays.fill(combined, (byte)0);

        // 0 ~ 3 : header
        combined[BasePacket.PKT_START_INDEX] = (byte)0xAA;
        combined[BasePacket.PKT_LENGTH_INDEX] = (byte) totalLength;
        combined[BasePacket.PKT_DEVICETYPE_INDEX] = getDeviceType();
        combined[BasePacket.PKT_FRAMEID_INDEX] = BasePacket.FID_EVENT_DRIVEN_CHANGE_DATA;

        // 4~21 : copy before monitoring data
        System.arraycopy(
                before, BasePacket.PKT_DATA_INDEX + BasePacket.LENGTH_MONITORING_DATA,
                combined, BasePacket.PKT_DATA_INDEX,
                BasePacket.LENGTH_MONITORING_DATA
        );

        // 22~39 : now monitoring data
        System.arraycopy(
                after, BasePacket.PKT_DATA_INDEX,
                combined, BasePacket.LENGTH_MONITORING_PACKET_HEADER + BasePacket.LENGTH_MONITORING_DATA,
                BasePacket.LENGTH_MONITORING_DATA
        );

        // 40 : CRC
        combined[totalLength-2] = (byte) PacketUtil.makeCRC(combined, totalLength-2);

        // 41 : footer
        combined[totalLength-1] = (byte) BasePacket.PKT_END_BYTE;
        return combined;
    }

    private byte getDeviceType() {
        // TODO : Config.json에 정의된 DeviceType에의해서 결정되어야함.
        return BasePacket.PKT_DEVICE_REF;
    }
}
