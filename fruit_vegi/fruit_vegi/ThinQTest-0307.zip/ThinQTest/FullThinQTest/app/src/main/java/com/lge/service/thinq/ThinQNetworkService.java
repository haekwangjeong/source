package com.lge.service.thinq;

import android.content.Context;
import android.os.RemoteException;
import android.util.Log;

import com.lge.service.thinq.configuration.ConfigProxy;
import com.lge.service.thinq.database.UserRepository;
import com.lge.service.thinq.database.entities.User;
import com.lge.service.thinq.network.OAuthServerProxy;
import com.lge.service.thinq.network.ServiceServerProxy;
import lge.home.thinq.IThinQNetwork;
import lge.home.thinq.ThinQError;

import java.io.PrintWriter;
import java.util.Map;
import java.util.concurrent.ExecutionException;

public class ThinQNetworkService extends IThinQNetwork.Stub
        implements ThinQServiceBase {
    private final String TAG = "ThinQNetworkService";

    private Context mServiceContext;

    private UserRepository mUserRepository;

    private OAuthServerProxy mOAuthProxy;

    private ServiceServerProxy mServiceServerProxy;

    private ConfigProxy mConfigProxy;

    ThinQNetworkService(Context context,
                        UserRepository userRepository,
                        ConfigProxy configProxy,
                        OAuthServerProxy oauthProxy,
                        ServiceServerProxy serviceProxy) {
        mServiceContext = context;
        mUserRepository = userRepository;
        mConfigProxy = configProxy;
        mOAuthProxy = oauthProxy;
        mServiceServerProxy = serviceProxy;
    }

    @Override
    public void init() {
    }

    @Override
    public void release() {
    }

    @Override
    public void dump(PrintWriter writer) {
    }

    @Override
    public String getAccessToken() throws RemoteException {
//        User currentUser;
//        String accessToken;
//
//        try {
//            currentUser = mUserRepository.getUser();
//        } catch (ExecutionException | InterruptedException e) {
//            throw new UnsupportedOperationException(ThinQError.ERROR_INTERNAL_ERROR.toString());
//        }
//
//        if (!mUserRepository.hasValidToken()) {
//            Log.d(TAG, "Has no valid token. let's issue token");
//            accessToken = mOAuthProxy.getAccessToken(currentUser.refreshToken);
//        } else {
//            Log.d(TAG, "Has valid token. Reuse it");
//            accessToken = mOAuthProxy.getAccessToken();
//        }

        return mOAuthProxy.getAccessToken();
    }

    @Override
    public String getServiceServerUrl() throws RemoteException {
        return mConfigProxy.getServiceServerUrl();
    }

    @Override
    public Map<String, String> getDefaultHeaders() throws RemoteException {
//        User currentUser;
//        String accessToken;
//        String userNo;
//
//        try {
//            currentUser = mUserRepository.getUser();
//        } catch (ExecutionException | InterruptedException e) {
//            throw new UnsupportedOperationException(ThinQError.ERROR_INTERNAL_ERROR.toString());
//        }
//
//        userNo = currentUser.userNo;
//
//        if (!mUserRepository.hasValidToken()) {
//            Log.d(TAG, "Has no valid token. let's issue token");
//            accessToken = mOAuthProxy.getAccessToken(currentUser.refreshToken);
//        } else {
//            Log.d(TAG, "Has valid token. Reuse it");
//            accessToken = mOAuthProxy.getAccessToken();
//        }
//
//        return mServiceServerProxy.getDefaultHeaders(accessToken, userNo);
        return mServiceServerProxy.getDefaultHeaders();
    }
}
