package com.lge.service.thinq.database;

import timber.log.Timber;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.lge.service.thinq.database.dao.UserDao;
import com.lge.service.thinq.database.entities.User;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class UserRepository {

    private static UserRepository mInstance;
    private final UserDao mUserDao;

    private User mUser;

    private String mRefreshToken;

    private String mAccessToken;

    private long mTimeStamp;

    private ExecutorService mExecutor;

    synchronized public static UserRepository getInstance(AppDatabase appDatabase) {
        if (mInstance == null) {
            mInstance = new UserRepository(appDatabase);
        }

        return mInstance;
    }

    private UserRepository(AppDatabase db) {
        this.mUserDao = db.userDao();

        mExecutor = Executors.newSingleThreadExecutor();
    }

    private synchronized User encryptData(@NonNull User user) {
        if (user == null) {
            return null;
        }

        // TODO : database에 read/write시 암/복호화가 필요할까?
        return new User(user.userId,
                user.displayName,
                user.deviceId,
                user.userNo,
                user.accountType,
                user.loginType,
                user.countryCode,
                user.accessToken,
                user.refreshToken,
                user.oAuthBackendUrl,
                user.tokenExpiredAt,
                user.endpointUrl);
    }

    private synchronized @Nullable User decryptData(@Nullable User user) {
        if (user == null) {
            return null;
        }

        // TODO : database에 read/write시 암/복호화가 필요할까?
        return new User(user.userId,
                user.displayName,
                user.deviceId,
                user.userNo,
                user.accountType,
                user.loginType,
                user.countryCode,
                user.accessToken,
                user.refreshToken,
                user.oAuthBackendUrl,
                user.tokenExpiredAt,
                user.endpointUrl);
    }

    private User getUserData(User user) {
        if (user == null) {
            return null;
        }

        return new User(user.userId,
                user.displayName,
                user.deviceId,
                user.userNo,
                user.accountType,
                user.loginType,
                user.countryCode,
                user.accessToken,
                user.refreshToken,
                user.oAuthBackendUrl,
                user.tokenExpiredAt,
                user.endpointUrl);
    }

    public User getUser() throws ExecutionException, InterruptedException {
        if (mUser == null) {
            Callable<User> callable = new Callable<User>() {
                @Override
                public User call() throws Exception {
                    return decryptData(mUserDao.getUser());
                }
            };

            Future<User> future = mExecutor.submit(callable);
            mUser = future.get();

            updateUserData(mUser);
        }

        return mUser;
    }

    private void updateUserData(@NonNull User user) {
        mRefreshToken = user.refreshToken;
        mAccessToken = user.accessToken;
        mTimeStamp = user.tokenExpiredAt;
    }

    public void insert(@NonNull User user) throws ExecutionException, InterruptedException {
        Timber.d("insert: %s", user.userId);

        Callable<Void> callable = new Callable<Void>() {
            @Override
            public Void call() throws Exception {
                User encryptUser = encryptData(user);
                mUserDao.insert(encryptUser);
                return null;
            }
        };

        Future<Void> future = mExecutor.submit(callable);
        future.get();
    }

    public void deleteUser() throws ExecutionException, InterruptedException {
        Callable<Void> callable = new Callable<Void>() {
            @Override
            public Void call() throws Exception {
                mUserDao.deleteAll();
                return null;
            }
        };

        Future<Void> future = mExecutor.submit(callable);
        future.get();
    }

    public void insertOrReplace(@NonNull User user) {
        Timber.d("insertOrReplace: %s", user.userId);

        new Thread(() -> insertOrReplaceSync(user)).start();
    }

    public void insertOrReplaceSync(User user) {
        User encryptUser = encryptData(user);
        mUserDao.insertOrReplace(user);
    }

    public boolean hasValidToken() {
        long now = System.currentTimeMillis();

        // 현재 timestamp가 token 만료시간 이내면 이전 발급된 token을 재사용한다.
        if (now < mTimeStamp) {
            Timber.d("we've got already valid token.");
            return true;
        }

        return false;
    }

    public String getAccessToken() {
        return mAccessToken;
    }

    public void updateToken(String newToken, long expiredAtMillis) throws ExecutionException, InterruptedException {
        mAccessToken = newToken;
        mTimeStamp = expiredAtMillis;

        Callable<Void> callable = new Callable<Void>() {
            @Override
            public Void call() throws Exception {
                mUserDao.updateToken(newToken, expiredAtMillis);
                return null;
            }
        };

        Future<Void> future = mExecutor.submit(callable);
        future.get();
    }

    public String getRefreshToken() {
        return mRefreshToken;
    }

    public boolean hasUser() throws ExecutionException, InterruptedException {
        Callable<Boolean> callable = new Callable<Boolean>() {
            @Override
            public Boolean call() throws Exception {
                return mUserDao.getCount() == 1;
            }
        };

        Future<Boolean> future = mExecutor.submit(callable);

        return future.get();
    }

    public void updateEndPointUrl(String endpoint) throws ExecutionException, InterruptedException {
        Callable<Void> callable = new Callable<Void>() {
            @Override
            public Void call() throws Exception {
                mUserDao.updateEndPointUrl(endpoint);
                return null;
            }
        };

        Future<Void> future = mExecutor.submit(callable);
        future.get();
    }
}
