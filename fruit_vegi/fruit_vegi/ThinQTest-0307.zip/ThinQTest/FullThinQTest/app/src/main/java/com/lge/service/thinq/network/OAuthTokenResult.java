package com.lge.service.thinq.network;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/*
{"access_token":"20c3dc0a6027919b22bc9c4348d0ae07e3eb6e098ee6e7830bea68959394be5b73bb2a9f6b64e58e973120de2a280a70","expires_in":"3600"}
* */
public class OAuthTokenResult {
    @SerializedName("access_token")
    @Expose
    private String mToken;

    @SerializedName("expires_in")
    @Expose
    private String mExpiresIn;

    public String getAccessToken() {
        return mToken;
    }

    public int getExpiresIn() {
        return Integer.parseInt(mExpiresIn);
    }
}
