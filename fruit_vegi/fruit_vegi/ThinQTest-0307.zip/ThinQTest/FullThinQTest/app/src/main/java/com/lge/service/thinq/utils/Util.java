package com.lge.service.thinq.utils;


public class Util {

    // format : ssl://a33mkx0uol0g9c.iot.ap-northeast-2.amazonaws.com:8883
    static public String getHostName(String full) {

        // no spec string. error
        if ((full.indexOf("http:") == -1) &&
                (full.indexOf("https:") == -1) &&
                (full.indexOf("ssl:") == -1)) {
            return null;
        }

        int startPos = full.indexOf("//") + 2;
        int endPos = full.lastIndexOf(":");

        if (endPos == -1 ) {
            endPos = full.length();
        }

        return full.substring(startPos, endPos);
    }

    // format : jeremy.kim@lge.com
    static public String getUserName(String full) {

        int endPos = full.lastIndexOf("@");

        if (endPos == -1 ) {
            endPos = full.length();
        }

        return full.substring(0, endPos);
    }
}
