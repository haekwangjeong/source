package com.lge.service.thinq.network;

import android.content.Context;
import com.lge.service.thinq.utils.SHA256;
import com.lge.service.thinq.configuration.ConfigProxy;
import com.lge.service.thinq.utils.IdentifierGenerator;

import java.security.NoSuchAlgorithmException;

import okhttp3.Headers;

public class CommonHeader {
    private static final String APPLICATION_JSON_CHARSET_UTF8 =
            "application/json;charset=UTF-8";
    private static final String APPLICATION_JSON = "application/json";
    private static final String API_KEY = "VGhpblEyLjAgU0VSVklDRQ==";
    private static String mServiceCode;

    private static Context mContext;

    public CommonHeader() {
    }

    public static Headers.Builder builder(Context context, IdentifierGenerator generator) {
        mContext = context;

        Headers.Builder commonHeader = new Headers.Builder();
        commonHeader.add("Content-Type", APPLICATION_JSON_CHARSET_UTF8);
        commonHeader.add("Accept", APPLICATION_JSON);
        commonHeader.add("x-client-id", getHashedDeviceId());
        commonHeader.add("x-api-key", API_KEY);
        commonHeader.add("x-service-code", getServiceCode());
        commonHeader.add("x-country-code", getCountryCode());
        commonHeader.add("x-language-code", getLanguageCode());
        commonHeader.add("x-message-id", generator.getMessageId());
        commonHeader.add("x-origin", getModelName());
        commonHeader.add("x-service-phase", getServicePhase());
        return commonHeader;
    }

    private static String getHashedDeviceId() {
        String hashedDeviceId = null;

        SHA256 sha256 = new SHA256();
        try {
            // TODO : read from secure storage
            hashedDeviceId = sha256.encrypt(ConfigProxy.getInstance(mContext).getDeviceId());
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }

        return hashedDeviceId;
    }

    private static String getServiceCode() {
        if (mServiceCode == null || mServiceCode.isEmpty()) {
            mServiceCode = ConfigProxy.getInstance(mContext).getThinQServiceCode();
        }

        return mServiceCode;
    }

    private static String getCountryCode() {
        return ConfigProxy.getInstance(mContext).getConfig(ConfigProxy.ConfigValue.TARGET_COUNTRY);
    }

    private static String getLanguageCode() {
        return ConfigProxy.getInstance(mContext).getConfig(ConfigProxy.ConfigValue.TARGET_LANG_CODE);
    }

    private static String getModelName() {
        return ConfigProxy.getInstance(mContext).getConfig(ConfigProxy.ConfigValue.TARGET_MODELNAME);
    }

    private static String getServicePhase() {
        return ConfigProxy.getInstance(mContext).getConfig(ConfigProxy.ConfigValue.TARGET_STAGE);
    }

    private static String getDeviceId() {
        // TODO : read from secure storage
        return ConfigProxy.getInstance(mContext).getDeviceId();
    }

}
