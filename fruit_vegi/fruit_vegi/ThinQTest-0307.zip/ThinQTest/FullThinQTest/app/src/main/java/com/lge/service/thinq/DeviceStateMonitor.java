package com.lge.service.thinq;

import java.util.Observable;

public class DeviceStateMonitor extends Observable {
    private boolean isDeviceRegistered = false;

    public DeviceStateMonitor(boolean state) {
        isDeviceRegistered = state;
    }

    public void updateDeviceState(boolean flag) {
        isDeviceRegistered = flag;
        setChanged();
        notifyObservers(flag);
    }

    public boolean isDeviceRegistered() {
        return isDeviceRegistered;
    }
}
