package com.lge.service.thinq;

import android.content.Context;
import android.os.Bundle;
import android.os.RemoteException;

import com.google.gson.JsonObject;
import com.lge.service.thinq.configuration.ConfigProxy;
import com.lge.service.thinq.database.UserRepository;
import com.lge.service.thinq.database.entities.User;
import com.lge.service.thinq.network.CertResult;
import com.lge.service.thinq.network.OAuthServerProxy;
import com.lge.service.thinq.network.ServiceServerProxy;
import com.lge.service.thinq.network.CommonServerProxy;
import com.lge.service.thinq.utils.CipherTextGenerator;
import com.lge.service.thinq.utils.IdentifierGenerator;
import com.lge.service.thinq.mqtt.MqttKeyManager;
import com.lge.service.thinq.utils.Util;
import lge.home.thinq.IThinQDevice;
import lge.home.thinq.ThinQError;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PublicKey;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.concurrent.ExecutionException;

import timber.log.Timber;

public class ThinQDeviceService extends IThinQDevice.Stub
        implements ThinQServiceBase {

    private Context mServiceContext;

    private OAuthServerProxy mOAuthProxy;

    private ServiceServerProxy mServiceServerProxy;

    private CommonServerProxy mCommonServerProxy;

    private UserRepository mUserRepository;

    private ThinQMqttService mMqttService;

    private DeviceStateMonitor mDeviceStateMonitor;

    ThinQDeviceService(Context context,
                       UserRepository userRepository,
                       ThinQMqttService mqttService,
                       DeviceStateMonitor deviceStateMonitor,
                       OAuthServerProxy oauthProxy,
                       ServiceServerProxy serviceProxy) {
        mServiceContext = context;
        mUserRepository = userRepository;
        mMqttService = mqttService;
        mDeviceStateMonitor = deviceStateMonitor;

        mOAuthProxy = oauthProxy;
        mServiceServerProxy = serviceProxy;
        mCommonServerProxy = CommonServerProxy.getInstance(context);
    }

    @Override
    public void init() {
    }

    @Override
    public void release() {
    }

    @Override
    public void dump(PrintWriter writer) {
    }

    @Override
    public boolean addDevice(String accessToken, String refreshToken, String backendUrl) throws UnsupportedOperationException {

        if (accessToken.isEmpty() || refreshToken.isEmpty()) {
            throw new UnsupportedOperationException(ThinQError.ERROR_INVALID_PARAM.toString());
        }

        // token 만료시간을 3600으로 계산 해야 하나 처음 발급후, 제품 등록으로 시간이 지났음을 감안해서 -100한 값으로 저장한다.
        long expires_at = System.currentTimeMillis() + (3500 * 1000);

        // STEP 1 : Device용 비대칭키 생성 signing시 사용됨.
        KeyPair deviceKeyPair = null;
        try {
            deviceKeyPair = CipherTextGenerator.generateKeyPair();
        } catch (NoSuchAlgorithmException | NoSuchProviderException e) {
            throw new UnsupportedOperationException(ThinQError.ERROR_FAILED_ADD_DEVICE.toString());
        }

        // STEP 2 : 사용자 정보를 얻어 온다.
        Bundle userProfile = mOAuthProxy.getUserProfile(accessToken);
        String userNo = userProfile.getString("userNo");
        String userId = userProfile.getString("userDiplayId");
        String userDisplayId = Util.getUserName(userId);

        Timber.d("user no = %s", userNo);
        Timber.d("user displayId = %s", userDisplayId);

        // STEP 3 : 사용자계정을 등록한다.
        if (!mServiceServerProxy.requestAddClient(accessToken, userNo)) {
            throw new UnsupportedOperationException(ThinQError.ERROR_FAILED_ADD_CLIENT.toString());
        }

        // STEP 4 : 제품등록을위해 사전 OTP, PublicKey를 얻어 온다.
        CertResult.Cert cert = mServiceServerProxy.requestCertificate(accessToken, userNo);

        if (cert == null) {
            throw new UnsupportedOperationException(ThinQError.ERROR_OPENAPI_RETURN_ERROR.toString());
        }

        String otp = cert.getOTP();
        String strKey = cert.getKEY();
        PublicKey pubKey = CipherTextGenerator.convertStringToKey(strKey);

        // STEP 5 : PublicKey(RandomKey + SHA256(DeviceId))로 ciphertext을 생성한다.
        String randomKey = IdentifierGenerator.getRandomKey(8);
        String deviceId = ConfigProxy.getInstance(mServiceContext).getDeviceId();
        String cipherText = CipherTextGenerator.generateCipherText(pubKey, randomKey, deviceId);

        // STEP 6: 제품 등록을 요청 한다.
        if (!mServiceServerProxy.requestAddDevice(accessToken, refreshToken, userNo, deviceId, cipherText)) {
            throw new UnsupportedOperationException(ThinQError.ERROR_FAILED_ADD_DEVICE.toString());
        }

        // STEP 7 : MQTT 접속을 위해 서버 인증서 발급 요청 한다.
        JsonObject jsonCertificationInfo =
             mCommonServerProxy.issueServerCertification(pubKey, randomKey, otp, deviceId, deviceKeyPair);

        String serverCertPemString = jsonCertificationInfo.get("certificatePem").getAsString();

        X509Certificate mqttBrokerCertification = null;
        try {
            mqttBrokerCertification =
                 MqttKeyManager.generateX509Certificate(serverCertPemString.getBytes(StandardCharsets.UTF_8));
        } catch (IOException |  CertificateException e) {
            throw new UnsupportedOperationException(ThinQError.ERROR_FAILED_ADD_DEVICE.toString());
        }

        KeyStore keyStore = null;
        try {
             keyStore =
                     MqttKeyManager.buildKeyStore(mqttBrokerCertification, deviceKeyPair.getPrivate(), null);
        } catch (KeyStoreException | NoSuchAlgorithmException | CertificateException | IOException e) {
            throw new UnsupportedOperationException(ThinQError.ERROR_FAILED_ADD_DEVICE.toString());
        }

        // STEP 8 : MQTT Broker URI를 조회한다.
        JsonObject jsonEndPointInfo = mCommonServerProxy.getEndPoint();
        // Samples, "ssl://a33mkx0uol0g9c.iot.ap-northeast-2.amazonaws.com:8883"
        String hostNameMqttBroker = Util.getHostName(jsonEndPointInfo.get("mqttServer").getAsString());

        // STEP 9 : MQTT 접속을 시도한다.
        /*
         mqtt 가 connect 될때까지 polling 한다.
         1) service server에 제품 등록이 되고
         2) mqtt connect가 되어야 제품등록이 완료 되기 때문에,
        */
        int retryCount = 0;
        boolean connected = false;
        final int MQTT_POLLING_MAX_RETRY = 5;

        String modelName =
                ConfigProxy.getInstance(mServiceContext).getConfig(ConfigProxy.ConfigValue.TARGET_MODELNAME);

        mMqttService.start(modelName, deviceId, hostNameMqttBroker);
        Timber.d("addDevice() ThinQMqttService start()");

        // MQTT 접속 시도후, 최대 MQTT_POLLING_MAX_RETRY 만큼
        // Polling하면서 Connection 상태를 검사 한다.
        while(retryCount < MQTT_POLLING_MAX_RETRY) {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
            }

            connected = mMqttService.isConnected();

            if (connected) {
                break;
            }

            retryCount++;
        }

        Timber.d("addDevice() ThinQMqttService status = %b", connected);

        if (connected == false) {
            return false;
        }

        // STEP 10 : 제품 등록 완료시 User정보를 database에 저장한다.
        try {
            String country =
                    ConfigProxy.getInstance(mServiceContext).getConfig(ConfigProxy.ConfigValue.TARGET_COUNTRY);
            mUserRepository.insert(new User(
                    userId, userDisplayId, deviceId, userNo,
                    "LGE","LGE",
                    country, accessToken, refreshToken, backendUrl,expires_at, hostNameMqttBroker)
            );
        } catch (ExecutionException | InterruptedException e) {
            throw new UnsupportedOperationException(ThinQError.ERROR_FAILED_ADD_DEVICE.toString());
        }

        // STEP 11 : Device 등록 되었음을 Broadcast한다.
        mDeviceStateMonitor.updateDeviceState(true);
        return true;
    }

    @Override
    public boolean deleteDevice() throws UnsupportedOperationException {
        boolean hasUser = false;
        User userInfo = null;

        try {
            hasUser = mUserRepository.hasUser();
            userInfo = mUserRepository.getUser();
        } catch (ExecutionException | InterruptedException e) {
            throw new UnsupportedOperationException(ThinQError.ERROR_FAILED_DELETE_DEVICE.toString());
        }

        // user 정보가 없다는건 제품 등록이 안된것으로 판단함.
        if (hasUser == false) {
            throw new UnsupportedOperationException(ThinQError.ERROR_FAILED_DELETE_DEVICE.toString());
        }

        String accessToken = null;
        if (mUserRepository.hasValidToken()) {
            accessToken = mUserRepository.getAccessToken();
        } else {
            accessToken = mOAuthProxy.getAccessToken();
        }

        String deviceId = ConfigProxy.getInstance(mServiceContext).getDeviceId();

        boolean result = mServiceServerProxy.requestDeleteDevice(accessToken, userInfo.refreshToken, deviceId, userInfo.userNo);

        if (result) {
            try {
                mUserRepository.deleteUser();
            } catch (ExecutionException | InterruptedException e) {
                throw new UnsupportedOperationException(ThinQError.ERROR_FAILED_DELETE_DEVICE.toString());
            }
        }

        // Device 해지 되었음을 Broadcast한다.
        mDeviceStateMonitor.updateDeviceState(false);
        return result;
    }

    @Override
    public boolean isDeviceRegistered() {
        boolean isRegistered = false;

        try {
            isRegistered = mUserRepository.hasUser();
        } catch (Exception e) {
            ThinQError.throwException(ThinQError.ERROR_INTERNAL_ERROR.toString());
        }

        return isRegistered;
    }

    @Override
    public String controlDeviceSync(String targetDeviceid, String jsonMessage) throws RemoteException {
        boolean hasUser = false;
        User userInfo = null;

        try {
            hasUser = mUserRepository.hasUser();
            userInfo = mUserRepository.getUser();
        } catch (ExecutionException | InterruptedException e) {
            throw new UnsupportedOperationException(ThinQError.ERROR_NO_DEVICE_REGISTRATION.toString());
        }

        // user 정보가 없다는건 제품 등록이 안된것으로 판단함.
        if (hasUser == false) {
            throw new UnsupportedOperationException(ThinQError.ERROR_NO_DEVICE_REGISTRATION.toString());
        }

        String accessToken = null;
        if (mUserRepository.hasValidToken()) {
            accessToken = mUserRepository.getAccessToken();
        } else {
            accessToken = mOAuthProxy.getAccessToken();
        }

        String response =
                mServiceServerProxy.controlDeviceSync(accessToken, userInfo.userNo, targetDeviceid, jsonMessage);

        return response;
    }

}
