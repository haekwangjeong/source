package com.lge.service.thinq;

import java.io.PrintWriter;

public interface ThinQServiceBase {
    /**
     * service is started. All necessary initialization should be done and service should be
     * functional after this.
     */
    void init();

    /** service should stop and all resources should be released. */
    void release();

    void dump(PrintWriter writer);
}
