package com.lge.service.thinq;

import android.content.Context;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;

import com.amazonaws.services.iot.client.AWSIotConnectionStatus;
import com.amazonaws.services.iot.client.AWSIotException;
import com.amazonaws.services.iot.client.AWSIotMessage;
import com.amazonaws.services.iot.client.AWSIotMqttClient;
import com.amazonaws.services.iot.client.AWSIotQos;
import com.amazonaws.services.iot.client.AWSIotTopic;
import com.google.gson.JsonObject;
import com.lge.service.thinq.configuration.ConfigProxy;
import com.lge.service.thinq.database.UserRepository;
import com.lge.service.thinq.database.entities.User;
import com.lge.service.thinq.mqtt.MqttKeyManager;
import com.lge.service.thinq.mqtt.MqttMessageBroker;
import com.lge.service.thinq.mqtt.MqttMsgGenerator;
import com.lge.service.thinq.network.CommonServerProxy;
import com.lge.service.thinq.network.ServiceServerProxy;
import com.lge.service.thinq.utils.AES256;
import com.lge.service.thinq.utils.IdentifierGenerator;
import com.lge.service.thinq.utils.PreferencesManager;
import com.lge.service.thinq.utils.ThreadUtil;
import com.lge.service.thinq.utils.Util;

import androidx.annotation.NonNull;

import java.io.PrintWriter;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.util.Observable;
import java.util.Observer;
import java.util.concurrent.ExecutionException;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import timber.log.Timber;

public class ThinQMqttService implements ThinQServiceBase, Observer {

    private Context mServiceContext;

    private CommonServerProxy mCommonServerProxy;

    private UserRepository mUserRepository;

    private DeviceStateMonitor mDeviceStateMonitor;

    private boolean mReady;

    private String mDeviceId;

    private String mEndPoint;

    private String mModelName;

    private MqttMsgGenerator mMessageGenerator = null;

    private MqttMessageBroker mMessageBroker = null;

    private final HandlerThread mHandlerThread = ThreadUtil.getHandlerThread(getClass().getSimpleName());

    private final ThinQMqttService.MqttProcessHandler mHandler
            = new ThinQMqttService.MqttProcessHandler(mHandlerThread.getLooper(), this);

    // CONNECT_MAX_RETRY * CONNECT_RETRY_INTERVAL_MS 만큼 connect 되기를 wait한다.
    private static final long CONNECT_MAX_RETRY = 3;
    private static final long CONNECT_RETRY_INTERVAL_MS = 500;
    private int mConnectionRetryCount;

    private AWSIotMqttClient mAWSIotClient = null;

    private boolean mConnected = false;

    private boolean mClientReady = false;

    private final Object mLock = new Object();

    private static final class MqttProcessHandler extends Handler {
        private static final String TAG = ThinQMqttService.MqttProcessHandler.class.getSimpleName();

        private static ThinQMqttService mHost = null;

        private static final int MSG_PRE_INIT = 4;
        private static final int MSG_INIT = 0;
        private static final int MSG_CONNECT = 1;
        private static final int MSG_SEND_PROVISIONING = 2;
        private static final int MSG_DISCONNECT = 3;
        private static final int MSG_DEINIT = 99;

        private MqttProcessHandler(Looper looper, ThinQMqttService host) {
            super(looper);

            mHost = host;
        }

        private void requestPreInit() {
            Message msg = obtainMessage(HandlerMessageIds.MSG_MQTT_PRE_INIT);
            sendMessage(msg);
        }

        private void requestInit() {
            Message msg = obtainMessage(HandlerMessageIds.MSG_MQTT_INIT);
            sendMessage(msg);
        }

        private void requestConnect(int timeout) {
            Message msg = obtainMessage(HandlerMessageIds.MSG_MQTT_CONNECT, timeout, 0);
            sendMessage(msg);
        }

        private void requestProvisioning() {
            Message msg = obtainMessage(HandlerMessageIds.MSG_MQTT_SEND_PROVISIONING);
            sendMessage(msg);
        }

        private void requestDisconnect() {
            Message msg = obtainMessage(HandlerMessageIds.MSG_MQTT_DISCONNECT);
            sendMessage(msg);
        }

        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case HandlerMessageIds.MSG_MQTT_PRE_INIT:
                    mHost.doHandlePreInit();
                    break;

                case HandlerMessageIds.MSG_MQTT_INIT:
                    mHost.doHandleInit();
                    break;

                case HandlerMessageIds.MSG_MQTT_CONNECT:
                    mHost.doHandleConnect(msg.arg1);
                    break;

                case HandlerMessageIds.MSG_MQTT_SEND_PROVISIONING:
                    mHost.doSendProvisioning();
                    break;

                case HandlerMessageIds.MSG_MQTT_COMPLETEPROVISIONING:
                    mHost.doCompleteProvisioning();
                    break;

                case HandlerMessageIds.MSG_MQTT_DISCONNECT:
                    mHost.doHandleDisconnect();
                    break;



                case HandlerMessageIds.MSG_MQTT_DEINIT:
                    break;
            }
        }
    }

    private final Runnable mConnectionRetryRunnable = new Runnable() {
        @Override
        public void run() {
            mHandler.requestConnect(0);
        }
    };

    ThinQMqttService(Context context, UserRepository userRepository, DeviceStateMonitor deviceStateMonitor) {
        mServiceContext = context;
        mUserRepository = userRepository;
        mDeviceStateMonitor = deviceStateMonitor;

        mReady = false;
        mCommonServerProxy = CommonServerProxy.getInstance(context);
    }

    @Override
    public void init() {
    }

    @Override
    public void release() {
        if (mConnected) {
            disconnect(true);
        }
    }

    @Override
    public void dump(PrintWriter writer) {
    }

    @Override
    public void update(Observable o, Object arg) {
        if (o == mDeviceStateMonitor) {
            boolean deviceRegistered = mDeviceStateMonitor.isDeviceRegistered();

            if (mReady != deviceRegistered) {
                Timber.d("Device state changed isRegistered = " + deviceRegistered);

                mReady = deviceRegistered;

                // Device가 등록 되어 있음.
                if (mReady == true) {
                    // MQTT 접속 준비하고, Connect 한다.
                    start();
                } else {
                    // Device 등록 해지 됨.
                    if (isConnected()) {
                        disconnect(false);
                    }
                }
            }
        }
    }

    // Service Start후, 사용자 등록이 되어 있는 경우 start()한다.
    public void start() {
        User user;

        try {
            // 필요한 데이타를 Load한다.
            user = mUserRepository.getUser();
        } catch (ExecutionException | InterruptedException e) {
            Timber.e("Failed user database on start() %s", e.getMessage());
            // User정보를 확인 못하면 안됨.
            mReady = false;
            return;
        }

        mDeviceId = user.deviceId;
        mEndPoint = user.endpointUrl;
        mModelName =
                ConfigProxy.getInstance(mServiceContext).getConfig(ConfigProxy.ConfigValue.TARGET_MODELNAME);

        // endPoint 변경을 검사하기 때문에 PreInit 한다.
        mHandler.requestPreInit();
    }

    // ThinQDeviceServer.addDevice()에서 device등록이 완료되는 경우 호출한다.
    public void start(@NonNull String modelName, @NonNull String deviceId, @NonNull String endPoint) {
        mDeviceId = deviceId;
        mEndPoint = endPoint;
        mModelName = modelName;

        // ThinQDeviceService.start()에서 지금 제품 등록이 되었기 때문에 요청 하였으므로
        // mReady를 true로 set한다.
        mReady = true;

        // 새롭게 모든 정보를 얻어 왔으므로,
        // pre-init하지 않고 바로 init한다.
        mHandler.requestInit();

        Timber.d("start() requestInit()");
    }

    public boolean isConnected() {
        return mConnected;
    }

    // Run from HandlerThread
    private void doHandlePreInit() {
        JsonObject jsonResponse = mCommonServerProxy.getEndPoint();

        if (jsonResponse != null) {
            String newEndPoint = Util.getHostName(jsonResponse.get("mqttServer").getAsString());

            // 저장된 정보와 새로 조회한 EndPoint Url이 다르면 새롭게 갱신한다.
            if (mEndPoint.compareTo(newEndPoint) != 0) {
                try {
                    mUserRepository.updateEndPointUrl(newEndPoint);
                } catch (ExecutionException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                mEndPoint = newEndPoint;
            }
        }

        mHandler.requestInit();
    }

    // Run from HandlerThread
    private void doHandleInit() {
        KeyStore keyStore = null;
        try {
            // Load server certification for device
            keyStore = MqttKeyManager.getKeyStore(null);

            String keyPassword = new BigInteger(128, new SecureRandom()).toString(32);
            mAWSIotClient = new AWSIotMqttClient(mEndPoint, mDeviceId, keyStore, keyPassword);
            mMessageGenerator = new MqttMsgGenerator(mDeviceId, mModelName);

            AWSIotMessage willMessage = mMessageGenerator.makeWillMessage();

            mAWSIotClient.setWillMessage(willMessage);
            mAWSIotClient.setConnectionTimeout(20);
            mAWSIotClient.setMaxConnectionRetries(1);
            mAWSIotClient.setKeepAliveInterval(60000);
            mAWSIotClient.setNumOfClientThreads(1);

            mClientReady = true;
            mConnected = false;
        } catch (Exception e) {
            Timber.d("doHandleInit() has Exception = %s", e.getMessage());
            mClientReady = false;
            mConnected = false;
        }

        if (mClientReady) {
            mConnectionRetryCount = 0;
            mHandler.requestConnect(0);
        } else {
            // TODO : Process Error
        }

        Timber.d("doHandleInit() requestConnect()");
    }

    // Run from HandlerThread
    private void doHandleConnect(int timeout) {

        Timber.d("doHandleConnect() try connect endPoint = %s", mEndPoint);

        synchronized (mLock) {
            mConnectionRetryCount++;

            if (mConnectionRetryCount < CONNECT_MAX_RETRY) {
                try {
                    mAWSIotClient.connect(timeout);
                } catch (Exception e) {
                    Timber.e("Failed mAWSIotClient.connect() has exception %s", e.getMessage());
                }

                mConnected = AWSIotConnectionStatus.CONNECTED == mAWSIotClient.getConnectionStatus();

                if (!mConnected) {
                    Timber.d("doHandleConnect() MQTT not Connected, retry = %d", mConnectionRetryCount);
                    mHandler.postDelayed(mConnectionRetryRunnable, CONNECT_RETRY_INTERVAL_MS);
                    return;
                }
            }
        }

        Timber.d("doHandleConnect() MQTT Connected");

        if (!mConnected) {
            // TODO : callback listener를 만들어서 caller에서 fail을 알려줘야함.
            return;
        }

        // Creates message broker to handle received message from MQTT server.
        mMessageBroker =
                new MqttMessageBroker(mServiceContext, mAWSIotClient, mMessageGenerator, mHandler);

        mMessageBroker.start();

        // send device provisioning message
        mHandler.requestProvisioning();
    }

    // Run from HandlerThread
    private void doSendProvisioning() {
        if (mMessageGenerator == null || mMessageGenerator == null) {
            return;
        }

        // TODO : ConfigProxy로부터 읽어 와야함.
        String provisionData =
                "{\"appInfo\":{\"modelName\":\"SMARTREFGIDKR_T2\",\"modelLanguage\":\"01\",\"softVer\":\"1.0.0\",\"ruleVer\":\"1.0.0\",\"countryCode\":\"KR\",\"subCountryCode\":\"KR\",\"appVersion\":\"clip_hna_v1.0.001\",\"modemType\":\"M16\",\"regionalCode\":\"kic\",\"timezone\":\"+0900\",\"svcCode\":\"SVC202\",\"HomeApSsid\":\"HomeApSsid\",\"DeviceType\":\"101\"},\"platformInfo\":{\"provisioningKey\":\"SMARTREFGIDKR_T2\",\"version\":\"clip_v2.00.15-CLIP-webOS-5-RELEASE\"}}";

        boolean result = mMessageBroker.sendProvisioning(provisionData);
    }

    // Run from HandlerThread
    private void doCompleteProvisioning() {
//        String secretKey =
//            PreferencesManager.getInstance(mServiceContext).getString("secretKey");
//
//        if (secretKey.isEmpty()) {
//            String genKey = IdentifierGenerator.getSecretKey(256);
//            PreferencesManager.getInstance(mServiceContext).setString("secretKey", genKey);
//        }
//
//        Timber.d("CompleteProvisioning secretKey = %s", secretKey);
//
//        final SecretKeySpec aesKey =
//                new SecretKeySpec(secretKey.getBytes(),"AES");
//
//        String normal = "this is test message";
//        String encoded = AES256.encode(aesKey, normal);
//        String decoded = AES256.decode(aesKey, encoded);
//
//        Timber.d("CompleteProvisioning decoded = %s", decoded);
    }

    public void disconnect(boolean force) {
        if (force) {
            doHandleDisconnect();
        } else {
            mHandler.requestDisconnect();
        }
    }

    // Run from HandlerThread
    private void doHandleDisconnect() {
        try {
            // disconnect and delete
            mAWSIotClient.disconnect();
            mAWSIotClient = null;

            // disconnected stop MessageBroker and delete
            mMessageBroker.stop();
            mMessageBroker = null;
        } catch (AWSIotException e) {
            Timber.e("Failed mAWSIotClient.doHandleDisconnect() has exception %s", e.getMessage());
        }
    }

}
