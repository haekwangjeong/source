package com.lge.service.thinq;

public class HandlerMessageIds {

    public static final int MSG_MQTT_PRE_INIT = 1;

    public static final int MSG_MQTT_INIT = 2;

    public static final int MSG_MQTT_CONNECT = 3;

    public static final int MSG_MQTT_SEND_PROVISIONING = 4;

    public static final int MSG_MQTT_DISCONNECT = 5;

    public static final int MSG_MQTT_DEINIT = 6;

    public static final int MSG_MQTT_COMPLETEPROVISIONING = 7;

    public static final int MSG_MQTT_PACKET = 8;

}
