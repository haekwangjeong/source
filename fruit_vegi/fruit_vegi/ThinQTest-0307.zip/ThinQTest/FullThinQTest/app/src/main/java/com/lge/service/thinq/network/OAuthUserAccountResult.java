package com.lge.service.thinq.network;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/*
{"account":{"userNo":"xxxxxxx","displayUserID":"xxxxxxx@yopmail.com"}}
* */
public class OAuthUserAccountResult {
    @SerializedName("account")
    @Expose
    private OAuthUserProfileResult mUserProfile;

    public void setUserProfile(OAuthUserProfileResult userProfile) {
        this.mUserProfile = userProfile;
    }

    public OAuthUserProfileResult getUserProfile() {
        return mUserProfile;
    }

}
