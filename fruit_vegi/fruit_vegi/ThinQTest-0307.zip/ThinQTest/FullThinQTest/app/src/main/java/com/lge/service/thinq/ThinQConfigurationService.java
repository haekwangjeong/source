package com.lge.service.thinq;

import android.content.Context;
import android.os.RemoteException;

import java.io.PrintWriter;

import com.lge.service.thinq.configuration.ConfigProxy;
import com.lge.service.thinq.configuration.EmpUrlBuilder;
import com.lge.service.thinq.database.UserRepository;

import lge.home.thinq.IThinQConfiguration;

public class ThinQConfigurationService extends IThinQConfiguration.Stub
        implements ThinQServiceBase {

    private final Context mServiceContext;

    private final UserRepository mUserRepository;

    private ConfigProxy mConfigProxy;

    ThinQConfigurationService(Context context, UserRepository userRepository, ConfigProxy configProxy) {
        mServiceContext = context;
        mUserRepository = userRepository;
        mConfigProxy = configProxy;
    }

    @Override
    public void init() {
    }

    @Override
    public void release() {
    }

    @Override
    public void dump(PrintWriter writer) {
    }

    @Override
    public String getCountry() {
        return mConfigProxy.getConfig(ConfigProxy.ConfigValue.TARGET_COUNTRY);
    }

    @Override
    public String getStage() {
        return mConfigProxy.getConfig(ConfigProxy.ConfigValue.TARGET_STAGE);
    }

    @Override
    public String getOAuthDomain() {
        return mConfigProxy.getOAuthDomain();
    }

    @Override
    public String getDeviceId() {
        return mConfigProxy.getDeviceId();
    }

    @Override
    public String getLogInUrl() throws RemoteException {
        return new EmpUrlBuilder.Builder()
                .setUrlType(EmpUrlBuilder.EMP_URL_TYPE.USER_LOGIN)
                .setServerStage(mConfigProxy.getConfig(ConfigProxy.ConfigValue.TARGET_STAGE))
                .setCountry(mConfigProxy.getConfig(ConfigProxy.ConfigValue.TARGET_COUNTRY))
                .build().getUrl();
    }

    // MEMBER.08
    // Method : GET
    // Headers
    // "X-emp_session" : "accessToken"
    @Override
    public String getLogOutUrl() throws RemoteException {
        return new EmpUrlBuilder.Builder()
                .setUrlType(EmpUrlBuilder.EMP_URL_TYPE.USER_LOGOUT)
                .setServerStage(mConfigProxy.getConfig(ConfigProxy.ConfigValue.TARGET_STAGE))
                .setCountry(mConfigProxy.getConfig(ConfigProxy.ConfigValue.TARGET_COUNTRY))
                .build().getUrl();
    }

    // MEMBER.04
    // Method : POST
    // Headers
    // "X-emp_session" : "accessToken"
    @Override
    public String getShowTermsUrl() throws RemoteException {
        return new EmpUrlBuilder.Builder()
                .setUrlType(EmpUrlBuilder.EMP_URL_TYPE.SHOW_TERMS)
                .setServerStage(mConfigProxy.getConfig(ConfigProxy.ConfigValue.TARGET_STAGE))
                .setCountry(mConfigProxy.getConfig(ConfigProxy.ConfigValue.TARGET_COUNTRY))
                .build().getUrl();
    }

    // LOGIN.03
    // Method : POST
    // Headers
    // "X-emp_session" : "accessToken"
    @Override
    public String getUpdateTermsUrl() throws RemoteException {
        return new EmpUrlBuilder.Builder()
                .setUrlType(EmpUrlBuilder.EMP_URL_TYPE.UPDATE_TERMS)
                .setServerStage(mConfigProxy.getConfig(ConfigProxy.ConfigValue.TARGET_STAGE))
                .setCountry(mConfigProxy.getConfig(ConfigProxy.ConfigValue.TARGET_COUNTRY))
                .build().getUrl();
    }

}
