package com.lge.service.thinq.product;

public class BasePacket {

    public static final byte PKT_DEVICE_REF = (byte) 0x10;
    public static final byte PKT_DEVICE_OVEN = (byte) 0x40;
    public static final byte PKT_DEVICE_AIRCON = (byte) 0x50;
    public static final byte PKT_DEVICE_MODEM = (byte) 0xF0;

    public static final byte PKT_START_BYTE = (byte) 0xAA;
    public static final byte PKT_END_BYTE = (byte) 0xBB;

    public static final int PKT_MINIMUM_SIZE = 6;

    public static final int PKT_START_INDEX = 0;
    public static final int PKT_LENGTH_INDEX = 1;
    public static final int PKT_DEVICETYPE_INDEX = 2;
    public static final int PKT_FRAMEID_INDEX = 3;
    public static final int PKT_DATA_INDEX = 4;

    public static final int PKT_HEADER_LENGTH = 4;
    public static final int PKT_FOOTER_LENGTH = 2;

    public static final int LENGTH_BLACKBOX_DATA_PACKET = 177; // 0xB1
    public static final int LENGTH_BLACKBOX_DATA        = 171; // 0xAA

    // if added wifi data + blackbox
    public static final int LENGTH_BLACKBOX_WIFI_DATA_PACKET = 215; // 0xD7
    public static final int LENGTH_BLACKBOX_WIFI_DATA        = 209; // 0xD1

    public static final int LENGTH_MONITORING_PACKET_HEADER = 4;
    public static final int LENGTH_MONITORING_DATA = 18;
    public static final int LENGTH_MONITORING_PACKET_CHECKSUM = 1;
    public static final int LENGTH_MONITORING_PACKET_FOOTER = 1;

    // LENGTH_MONITORING_PACKET_HEADER
    // + LENGTH_MONITORING_DATA
    // + LENGTH_MONITORING_PACKET_CHECKSUM
    // + LENGTH_MONITORING_PACKET_FOOTER
    public static final int LENGTH_MONITORING_PACKET = 24;

    public static final byte FID_ACK = (byte) 0x00;
    public static final byte FID_REFDIAG_START_REQUEST = (byte) 0x14;
    public static final byte FID_REF_MON_START_REQUEST = (byte) 0x11;
    public static final byte FID_REF_MON_STOP_REQUEST = (byte) 0xEA;
    public static final byte FID_REF_CONTROL_REQ_V2 = (byte) 0x17;
    public static final byte FID_PRODUCT_REGISTERED = (byte) 0x29;
    public static final byte FID_FOTA_DEVICEINFO = (byte) 0x31;
    public static final byte FID_FOTA_DEVICEINFO_ACK = (byte) 0x32;
    public static final byte FID_REQ_DEVICEINFO = (byte) 0x3A;
    public static final byte FID_PUSH_SVC_NOTIFICATION = (byte) 0x72;
    /* this is for only Instaview */
    public static final byte FID_CHANGED_DATA = (byte) 0x7A;
    public static final byte FID_EVENT_BLACKBOX_DATA = (byte) 0xBF;
    public static final byte FID_EVENT_BLACKBOX_DATA_20 = (byte) 0xBD;
    public static final byte FID_BLACKBOX_SETTING = (byte) 0xCE;
    public static final byte FID_STATE_BLACKBOX_DATA = (byte) 0xCF;
    public static final byte FID_EVENT_DRIVEN_START_REQUEST  = (byte) 0xED;
    public static final byte FID_EVENT_DRIVEN_STOP_REQUEST = (byte) 0xEE;
    public static final byte FID_EVENT_DRIVEN_MASK_ON_REQUEST = (byte) 0xEF;
    public static final byte FID_EVENT_DRIVEN_DATA = (byte) 0xEB;
    public static final byte FID_EVENT_DRIVEN_CHANGE_DATA = (byte) 0xEC;
    public static final byte FID_REF_DIAG_DATA = (byte) 0xAB;
    public static final byte FID_REF_MON_DATA = (byte) 0xAE;
    public static final byte FID_REF_ACTIVEDATA_REQ = (byte) 0x1A;
    public static final byte FID_SET_LOCALTIMEZONE = (byte) 0x1E;
    public static final byte FID_LIVE_CHECK = (byte) 0xFF;

    public static String convertToString(byte frameId) {
        String result;

        switch(frameId) {
            case FID_ACK : result ="FID_ACK"; break;
            case FID_REFDIAG_START_REQUEST : result ="FID_REFDIAG_START_REQUEST"; break;
            case FID_REF_MON_START_REQUEST : result ="FID_REF_MON_START_REQUEST"; break;
            case FID_REF_MON_STOP_REQUEST : result ="FID_REF_MON_STOP_REQUEST"; break;
            case FID_REF_CONTROL_REQ_V2 : result ="FID_REF_CONTROL_REQ_V2"; break;
            case FID_PRODUCT_REGISTERED : result ="FID_PRODUCT_REGISTERED"; break;
            case FID_FOTA_DEVICEINFO : result ="FID_FOTA_DEVICEINFO"; break;
            case FID_FOTA_DEVICEINFO_ACK : result ="FID_FOTA_DEVICEINFO_ACK"; break;
            case FID_REQ_DEVICEINFO : result ="FID_REQ_DEVICEINFO"; break;
            case FID_PUSH_SVC_NOTIFICATION : result ="FID_PUSH_SVC_NOTIFICATION"; break;
            case FID_CHANGED_DATA : result ="FID_CHANGED_DATA"; break;
            case FID_EVENT_BLACKBOX_DATA : result ="FID_EVENT_BLACKBOX_DATA"; break;
            case FID_EVENT_BLACKBOX_DATA_20 : result ="FID_EVENT_BLACKBOX_DATA_20"; break;
            case FID_BLACKBOX_SETTING : result ="FID_BLACKBOX_SETTING"; break;
            case FID_STATE_BLACKBOX_DATA : result ="FID_STATE_BLACKBOX_DATA"; break;
            case FID_EVENT_DRIVEN_START_REQUEST : result ="FID_EVENT_DRIVEN_START_REQUEST"; break;
            case FID_EVENT_DRIVEN_STOP_REQUEST : result ="FID_EVENT_DRIVEN_STOP_REQUEST"; break;
            case FID_EVENT_DRIVEN_MASK_ON_REQUEST : result ="FID_EVENT_DRIVEN_MASK_ON_REQUEST"; break;
            case FID_EVENT_DRIVEN_DATA : result ="FID_EVENT_DRIVEN_DATA"; break;
            case FID_EVENT_DRIVEN_CHANGE_DATA : result ="FID_EVENT_DRIVEN_CHANGE_DATA"; break;
            case FID_REF_DIAG_DATA : result ="FID_REF_DIAG_DATA"; break;
            case FID_REF_MON_DATA : result ="FID_REF_MON_DATA"; break;
            case FID_REF_ACTIVEDATA_REQ : result ="FID_REF_ACTIVEDATA_REQ"; break;
            case FID_SET_LOCALTIMEZONE : result ="FID_SET_LOCALTIMEZONE"; break;
            case FID_LIVE_CHECK : result ="FID_LIVE_CHECK"; break;
            default : result = String.valueOf(frameId); break;
        }

        return result;
    }
}
