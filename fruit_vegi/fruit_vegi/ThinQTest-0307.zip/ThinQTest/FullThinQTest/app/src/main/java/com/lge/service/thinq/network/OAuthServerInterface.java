package com.lge.service.thinq.network;

import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface OAuthServerInterface {
    @Headers({
            "Accept: application/json"
    })
    @GET("/oauth/1.0/datetime")
    Call<OAuthDateTimeResult> getDateTime(@Header("x-lge-appKey") String appKey);

    @Headers({
            "Accept: application/json",
            "Content-Type: application/x-www-form-urlencoded"
    })
    @POST("/oauth/1.0/oauth2/token")
    Call<OAuthTokenResult> getAccessToken(
            @Header("x-lge-appKey") String appKey,
            @Header("x-lge-oauth-signature") String signature,
            @Header("x-lge-oauth-date") String date,
            @Body RequestBody body);

    @Headers({
            "Accept: application/json"
    })
    @GET("/oauth/1.1/users/profile")
    Call<OAuthUserAccountResult> getUserProfile(
            @Header("x-lge-appKey") String appKey,
            @Header("x-lge-oauth-signature") String signature,
            @Header("x-lge-oauth-date") String date,
            @Header("Authorization") String auth,
            @Header("ProfileOpt") String option
    );

}
