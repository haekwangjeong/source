package com.lge.service.thinq;

import android.content.Context;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.RemoteException;
import android.util.Log;

import com.lge.service.thinq.configuration.ConfigProxy;
import com.lge.service.thinq.database.UserRepository;
import com.lge.service.thinq.network.OAuthServerProxy;
import com.lge.service.thinq.network.ServiceServerProxy;

import java.util.ArrayList;
import java.util.List;

import lge.home.thinq.IThinQ;
import lge.home.thinq.ThinQError;

public class IThinQImpl extends IThinQ.Stub {

    private static String TAG = "IThinQImpl";

    private final Context mServiceContext;

    private final DeviceStateMonitor mDeviceStateMonitor;

    private final ConfigProxy mConfigProxy;

    private final ThinQServiceBase[] mAllServices;

    private final ThinQConfigurationService mThinQConfigurationService;

    private final ThinQTokenService mThinQTokenService;

    private final ThinQDeviceService mThinQDeviceService;

    private final ThinQNetworkService mThinQNetworkService;

    private final ThinQMqttService mThinQMqttService;

    private final UserRepository mUserRepository;

    /** Handler for generic event dispatching. */
    private final Handler mEventHandler;

    public IThinQImpl(Context context, UserRepository userRepository) {

        mServiceContext = context;
        mUserRepository = userRepository;

        Looper looper = Looper.getMainLooper();
        mEventHandler = new Handler(looper);

        boolean isRegistered = false;
        try {
            isRegistered = userRepository.hasUser();
        } catch (Exception e) {
            throw new UnsupportedOperationException(ThinQError.ERROR_FETAL_ERROR.toString());
        }

        // Device 등록/해지상태를 Observer들에게 broadcast해준다.
        mDeviceStateMonitor = new DeviceStateMonitor(false);

        mConfigProxy = ConfigProxy.getInstance(context);

        OAuthServerProxy oauthProxy = OAuthServerProxy.getInstance(context, mUserRepository);

        if (oauthProxy == null) {
           Log.e(TAG, "Failed create oauthProxy");
           throw new UnsupportedOperationException(ThinQError.ERROR_FETAL_ERROR.toString());
        }
        oauthProxy.setObserver(mDeviceStateMonitor);
        mDeviceStateMonitor.addObserver(oauthProxy);

        ServiceServerProxy serviceProxy = ServiceServerProxy.getInstance(context, mUserRepository, oauthProxy);

        if (serviceProxy == null) {
           throw new UnsupportedOperationException(ThinQError.ERROR_FETAL_ERROR.toString());
        }

        mThinQConfigurationService = new ThinQConfigurationService(context, mUserRepository, mConfigProxy);

        if (mThinQConfigurationService == null) {
            Log.e(TAG, "Failed create mThinQConfigurationService");
            throw new UnsupportedOperationException(ThinQError.ERROR_FETAL_ERROR.toString());
        }

        mThinQMqttService = new ThinQMqttService(context, mUserRepository, mDeviceStateMonitor);
        mDeviceStateMonitor.addObserver(mThinQMqttService);

        mThinQTokenService = new ThinQTokenService(context, oauthProxy, serviceProxy);

        mThinQDeviceService =
               new ThinQDeviceService(context,
                       mUserRepository,
                       mThinQMqttService,
                       mDeviceStateMonitor,
                       oauthProxy,
                       serviceProxy);

        if (mThinQDeviceService == null) {
           Log.e(TAG, "Failed create mThinQDeviceService");
           throw new UnsupportedOperationException(ThinQError.ERROR_FETAL_ERROR.toString());
        }

        mThinQNetworkService =
               new ThinQNetworkService(context,
                       mUserRepository,
                       mConfigProxy,
                       oauthProxy,
                       serviceProxy);

        if (mThinQNetworkService == null) {
           Log.e(TAG, "Failed create mThinQNetworkService");
           throw new UnsupportedOperationException(ThinQError.ERROR_FETAL_ERROR.toString());
        }

        List<ThinQServiceBase> allServices = new ArrayList<>();
        allServices.add(mThinQConfigurationService);
        allServices.add(mThinQMqttService);
        allServices.add(mThinQTokenService);
        allServices.add(mThinQDeviceService);
        allServices.add(mThinQNetworkService);

        mAllServices = allServices.toArray(new ThinQServiceBase[allServices.size()]);
    }

    @Override
    public IBinder getThinQService(String serviceName) throws RemoteException {
        switch (serviceName) {
            case "config_service":
                return mThinQConfigurationService;

            case "token_service":
                return mThinQTokenService;

            case "device_service":
                return mThinQDeviceService;

            case "network_service":
                return mThinQNetworkService;

            default : throw new RemoteException("Exception");
        }
    }

    public void init() {
        // 각 서비스들의 초기화를 진행한다.
        for (ThinQServiceBase service : mAllServices) {
            service.init();
        }

        Log.d(TAG, "Services init done.");

        // 초기화 완료후, Device 등록 상태를 BroadCast 한다.
        boolean isRegistered = false;
        try {
            isRegistered = mUserRepository.hasUser();
        } catch (Exception e) {
            throw new UnsupportedOperationException(ThinQError.ERROR_FETAL_ERROR.toString());
        }

        if (isRegistered) {
            Log.d(TAG, "user registered");
        } else {
            Log.d(TAG, "user didn't registered");
        }

        mDeviceStateMonitor.updateDeviceState(isRegistered);
    }

    public void release() {
        // release done in opposite order from init
        for (int i = mAllServices.length - 1; i >= 0; i--) {
            mAllServices[i].release();
        }
    }
}
