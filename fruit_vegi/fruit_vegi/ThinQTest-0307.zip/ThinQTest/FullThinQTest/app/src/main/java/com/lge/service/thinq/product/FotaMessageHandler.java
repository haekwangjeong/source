package com.lge.service.thinq.product;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;

import com.lge.service.thinq.mqtt.MqttMessageBroker;
import com.lge.service.thinq.mqtt.MqttMsgGenerator;
import com.lge.service.thinq.utils.ThreadUtil;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import timber.log.Timber;

public class FotaMessageHandler implements MessageHandlerBase {
    private final MqttMessageBroker mMessageBroker;

    private final MqttMsgGenerator mMessageGenerator;

    private final HandlerThread mHandlerThread
            = ThreadUtil.getHandlerThread(getClass().getSimpleName());

    private final FotaMessageHandler.MessageHandler mHandler
            = new FotaMessageHandler.MessageHandler(mHandlerThread.getLooper(), this);

    public FotaMessageHandler(MqttMessageBroker mMessageBroker, MqttMsgGenerator mMessageGenerator) {
        this.mMessageBroker = mMessageBroker;
        this.mMessageGenerator = mMessageGenerator;
    }

    @Override
    public void init() {

    }

    @Override
    public void release() {

    }

    @Override
    public Handler getHandler() {
        return mHandler;
    }

    @Override
    public List<String> getCommands() {
        List<String> cmdList = new ArrayList<String>();
        // Request starting fota
        cmdList.add("startFota");
        return cmdList;
    }

    @Override
    public void dump(PrintWriter writer) {

    }

    private static final class MessageHandler extends Handler {
        private static final String TAG =
                FotaMessageHandler.MessageHandler.class.getSimpleName();

        private static FotaMessageHandler mHost = null;

        private MessageHandler(Looper looper, FotaMessageHandler host) {
            super(looper);
            mHost = host;
        }

        @Override
        public void handleMessage(Message msg) {
            int type = msg.arg1;

            String message = (String) msg.obj;
            Timber.d("Received message = %s", message);
        }
    }
}
