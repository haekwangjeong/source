package com.lge.service.thinq.network;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/*
{"account":{"userNo":"xxxxxxx","displayUserID":"xxxxxxx@yopmail.com"}}
* */
public class OAuthUserProfileResult {
    @SerializedName("userNo")
    @Expose
    private String mUserNo;

    @SerializedName("displayUserID")
    @Expose
    private String mDisplayId;

    public String getUserNo() {
        return mUserNo;
    }

    public String getDisplayId() {
        return mDisplayId;
    }
}
