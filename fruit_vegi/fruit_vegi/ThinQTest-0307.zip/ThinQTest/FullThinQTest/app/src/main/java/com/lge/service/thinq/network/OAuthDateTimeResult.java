package com.lge.service.thinq.network;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/* {"date":"Fri, 17 Dec 2021 06:54:31 +0000","timestamp":"1639724071"} */
public class OAuthDateTimeResult {
    @SerializedName("date")
    @Expose
    private String mDate;

    @SerializedName("timestamp")
    @Expose
    private String mTimeStamp;

    public String getDate() {
        return mDate;
    }

    public String getTimeStamp() {
        return mTimeStamp;
    }
}
