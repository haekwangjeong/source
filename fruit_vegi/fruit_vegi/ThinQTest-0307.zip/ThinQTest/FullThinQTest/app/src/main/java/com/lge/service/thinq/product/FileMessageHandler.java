package com.lge.service.thinq.product;

import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.util.Log;

import com.lge.service.thinq.mqtt.MqttMessageBroker;
import com.lge.service.thinq.mqtt.MqttMsgGenerator;
import com.lge.service.thinq.network.FileDownloadService;
import com.lge.service.thinq.network.FileUploadService;
import com.lge.service.thinq.network.HttpServiceGenerator;
import com.lge.service.thinq.utils.FileUtils;
import com.lge.service.thinq.utils.ThreadUtil;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import timber.log.Timber;

public class FileMessageHandler implements MessageHandlerBase {
    private Context mServiceContext;

    private final MqttMessageBroker mMessageBroker;

    private final MqttMsgGenerator mMessageGenerator;

    private final HandlerThread mHandlerThread
            = ThreadUtil.getHandlerThread(getClass().getSimpleName());

    private final FileMessageHandler.MessageHandler mHandler
            = new FileMessageHandler.MessageHandler(mHandlerThread.getLooper(), this);

    public FileMessageHandler(Context context, MqttMessageBroker mMessageBroker, MqttMsgGenerator mMessageGenerator) {
        this.mMessageBroker = mMessageBroker;
        this.mMessageGenerator = mMessageGenerator;
    }

    @Override
    public void init() {

    }

    @Override
    public void release() {

    }

    @Override
    public Handler getHandler() {
        return mHandler;
    }

    @Override
    public List<String> getCommands() {
        List<String> cmdList = new ArrayList<String>();
        // Request uploading file
        cmdList.add("reqFileUpload");
        // Request downloading file
        cmdList.add("reqFileDownload");
        return cmdList;
    }

    @Override
    public void dump(PrintWriter writer) {

    }

    private static final class MessageHandler extends Handler {
        private static final String TAG =
                FileMessageHandler.MessageHandler.class.getSimpleName();

        private static FileMessageHandler mHost = null;

        private MessageHandler(Looper looper, FileMessageHandler host) {
            super(looper);
            mHost = host;
        }

        @Override
        public void handleMessage(Message msg) {
            int type = msg.arg1;

            String message = (String) msg.obj;
            Timber.d("Received message = %s", message);
        }
    }

    private void uploadFile(Uri source, String target) {
        // create upload service client
        FileUploadService service =
                HttpServiceGenerator.createService(FileUploadService.class, target);

        // use the FileUtils to get the actual file by uri
        File file = FileUtils.getFile(mServiceContext, source);

        ContentResolver contentResolver = mServiceContext.getContentResolver();

        // create RequestBody instance from file
        RequestBody requestFile =
                RequestBody.create(file, MediaType.parse(contentResolver.getType(source)));

        // MultipartBody.Part is used to send also the actual file name
        MultipartBody.Part body =
                MultipartBody.Part.createFormData("fileData", file.getName(), requestFile);

        // add another part within the multipart request
        String descriptionString = "hello, this is description speaking";
        RequestBody description =
                RequestBody.create(descriptionString, okhttp3.MultipartBody.FORM);

        // finally, execute the request
        Call<ResponseBody> call = service.upload(description, body);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call,
                                   Response<ResponseBody> response) {
                Log.v("Upload", "success");
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Log.e("Upload error:", t.getMessage());
            }
        });
    }

    private void downloadFile(String source, Uri target) {
        FileDownloadService downloadService =
                HttpServiceGenerator.createService(FileDownloadService.class, source);

        Call<ResponseBody> call = downloadService.download(source);

        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    Timber.d("server contacted and has file");

                    boolean writtenToDisk = writeResponse(response.body());

                    Timber.d("file download was a success? " + writtenToDisk);
                } else {
                    Timber.d("server contact failed");
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Timber.e("error");
            }
        });
    }

    private boolean writeResponse(ResponseBody body) {
        try {
            // todo change the file location/name according to your needs
            File futureStudioIconFile = new File(mServiceContext.getFilesDir() + File.separator + "temp");

            InputStream inputStream = null;
            OutputStream outputStream = null;

            try {
                byte[] fileReader = new byte[4096];

                long fileSize = body.contentLength();
                long fileSizeDownloaded = 0;

                inputStream = body.byteStream();
                outputStream = new FileOutputStream(futureStudioIconFile);

                while (true) {
                    int read = inputStream.read(fileReader);

                    if (read == -1) {
                        break;
                    }

                    outputStream.write(fileReader, 0, read);
                    fileSizeDownloaded += read;
                    Timber.d("file download: " + fileSizeDownloaded + " of " + fileSize);
                }
                outputStream.flush();
                return true;
            } catch (IOException e) {
                return false;
            } finally {
                if (inputStream != null) {
                    inputStream.close();
                }
                if (outputStream != null) {
                    outputStream.close();
                }
            }
        } catch (IOException e) {
            return false;
        }
    }
}
