package com.lge.service.thinq.mqtt;

import android.content.Context;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;

import com.amazonaws.services.iot.client.AWSIotMessage;
import com.amazonaws.services.iot.client.AWSIotMqttClient;
import com.amazonaws.services.iot.client.AWSIotQos;
import com.amazonaws.services.iot.client.AWSIotTopic;
import com.amazonaws.services.iot.client.AWSIotException;
import com.lge.service.thinq.HandlerMessageIds;
import com.lge.service.thinq.product.ExtraMessageHandler;
import com.lge.service.thinq.product.FotaMessageHandler;
import com.lge.service.thinq.product.MainMessageHandler;
import com.lge.service.thinq.product.FileMessageHandler;
import com.lge.service.thinq.utils.StringUtils;
import com.lge.service.thinq.utils.ThreadUtil;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import timber.log.Timber;

public class MqttMessageBroker {

    private Context mServiceContext;

    private AWSIotMqttClient mClient = null;

    private MqttMsgGenerator mMessageGenerator = null;

    private Handler mServiceHandler = null;

    private MainMessageHandler mMainMessageHandler = null;

    private FileMessageHandler mFileMessageHandler = null;

    private FotaMessageHandler mFotaMessageHandler = null;

    private ExtraMessageHandler mExtraMessageHandler = null;

    private boolean mReady = false;

    private final HandlerThread mHandlerThread
            = ThreadUtil.getHandlerThread(getClass().getSimpleName());

    private final MqttMessageBroker.MqttMessageProcHandler mHandler
            = new MqttMessageBroker.MqttMessageProcHandler(mHandlerThread.getLooper(), this);

    private final Map<String, Handler> mMessageReceivers;

    public class Subscriber extends AWSIotTopic {

        public Subscriber(String topic, AWSIotQos qos) {
            super(topic, qos);
        }

        @Override
        public void onMessage(AWSIotMessage message) {
            Timber.d("<===== " + message.getStringPayload());

            // send message to delegators.
            boolean handled = sendMessage(message.getStringPayload());

            // no message processor, let's handle here.
            if (handled == false) {
                processMessage(message.getStringPayload());
            }
        }

        private void processMessage(String message) {
            JSONObject jsonObject = null;
            boolean handled = false;
            try {
                jsonObject = new JSONObject(message);
                String command = jsonObject.getString("cmd");
                int type = jsonObject.getInt("type");

                switch (command) {
                    case "completeProvisioning":
                        mServiceHandler.obtainMessage(HandlerMessageIds.MSG_MQTT_COMPLETEPROVISIONING).sendToTarget();
                        break;
                    default:
                        Timber.e("Unhandled message = %s", message);
                        break;

                }
            } catch (JSONException e) {
                Timber.e("Received message but, invalid json format");
            }
        }

        private boolean sendMessage(String message) {
            JSONObject jsonObject = null;
            boolean handled = false;
            try {
                jsonObject = new JSONObject(message);
                String cmdOfMessage = jsonObject.getString("cmd");
                int typeOfMsg = jsonObject.getInt("type");

                // find receiver to handle message
                for( String command : mMessageReceivers.keySet() ){
                    if (command.compareTo(cmdOfMessage) == 0) {
                        Handler receiver = mMessageReceivers.get(command);
                        if (receiver != null) {
                            Message msg =
                                    receiver.obtainMessage(
                                            HandlerMessageIds.MSG_MQTT_PACKET,
                                            typeOfMsg,
                                            0 /*Unused*/,
                                            jsonObject.getString("data")
                                    );

                            // send message to delegator
                            handled = receiver.sendMessage(msg);
                            break;
                        }
                    }
                }
            } catch (JSONException e) {
                Timber.e("Received message but, invalid json format");
            }

            return handled;
        }
    }

    public static class NonBlockingPublishListener extends AWSIotMessage {
        public NonBlockingPublishListener(String topic, AWSIotQos qos, String payload) {
            super(topic, qos, payload);
        }

        @Override
        public void onSuccess() {
        }

        @Override
        public void onFailure() {
            Timber.d("onFailure() " + getStringPayload());
        }

        @Override
        public void onTimeout() {
            Timber.d("onTimeout() " + getStringPayload());
        }
    }

    public static class Publisher implements Runnable {
        private final AWSIotMqttClient _client;
        private final AWSIotMessage _message;
        private boolean _result = false;

        public boolean getResult() {
            return _result;
        }

        public Publisher(AWSIotMqttClient awsIotClient, AWSIotMessage awsIotMessage) {
            this._client = awsIotClient;
            this._message = awsIotMessage;
        }

        public Publisher(AWSIotMqttClient awsIotClient, NonBlockingPublishListener awsIotMessage) {
            this._client = awsIotClient;
            this._message = awsIotMessage;
        }

        @Override
        public void run() {
            try {
                _client.publish(_message);
                Timber.d(" =====> %s", _message.getStringPayload());
                _result = true;
            } catch (AWSIotException e) {
                _result = false;
                Timber.d("Published Failed %s, Exception %s", _message.getStringPayload(), e.getMessage());
            }
        }
    }

    private static final class MqttMessageProcHandler extends Handler {
        private static final String TAG = MqttMessageBroker.MqttMessageProcHandler.class.getSimpleName();

        private static MqttMessageBroker mHost = null;

        private static final int MSG_CONTROL = 1;
        private static final int MSG_CLOUDLET = 2;

        private MqttMessageProcHandler(Looper looper, MqttMessageBroker host) {
            super(looper);
            mHost = host;
        }

        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case MSG_CONTROL:
                    break;

                case MSG_CLOUDLET:
                    break;
            }
        }
    }

    public Handler getHandler() {
        return mHandler;
    }

    public MqttMessageBroker(Context context, AWSIotMqttClient mqttClient, MqttMsgGenerator msgGenerator, Handler serviceHandler) {
        mServiceContext = context;
        mClient = mqttClient;
        mMessageGenerator = msgGenerator;
        mServiceHandler = serviceHandler;
        mReady = false;

        mMessageReceivers = new HashMap<>();
    }

    private void deInitialize () {
        mServiceHandler.obtainMessage(HandlerMessageIds.MSG_MQTT_DEINIT).sendToTarget();
    }

    public void start() {
        String subscribeTopic =
                mMessageGenerator.makeTopic(MqttMsgGenerator.TopicType.TOPIC_SUBSCRIBE);
        Subscriber subscriber =
                new MqttMessageBroker.Subscriber(subscribeTopic, AWSIotQos.QOS0);

        try {
            mClient.subscribe(subscriber, false);
            mReady = true;
        } catch (AWSIotException e) {
            Timber.e("Failed AWSIotMqttClient.subscribe() has exception %s", e.getMessage());
        }

        mMainMessageHandler = new MainMessageHandler(this, mMessageGenerator);
        for(String cmdKey : mMainMessageHandler.getCommands()) {
            Timber.d("Command = \"%s\" will be delegated to MainMessageHandler", cmdKey);
            mMessageReceivers.put(cmdKey, mMainMessageHandler.getHandler());
        }

        mExtraMessageHandler = new ExtraMessageHandler(this, mMessageGenerator);
        for(String cmdKey : mExtraMessageHandler.getCommands()) {
            Timber.d("Command = \"%s\" will be delegated to ExtraMessageHandler", cmdKey);
            mMessageReceivers.put(cmdKey, mExtraMessageHandler.getHandler());
        }

        mFileMessageHandler = new FileMessageHandler(mServiceContext, this, mMessageGenerator);
        for(String cmdKey : mFileMessageHandler.getCommands()) {
            Timber.d("Command = \"%s\" will be delegated to FileMessageHandler", cmdKey);
            mMessageReceivers.put(cmdKey, mFileMessageHandler.getHandler());
        }

        mFotaMessageHandler = new FotaMessageHandler(this, mMessageGenerator);
        for(String cmdKey : mFotaMessageHandler.getCommands()) {
            Timber.d("Command = \"%s\" will be delegated to FotaMessageHandler", cmdKey);
            mMessageReceivers.put(cmdKey, mFotaMessageHandler.getHandler());
        }

        Timber.d("MessageReceivers has %d message's delegators", mMessageReceivers.size());
    }

    public void stop() {
        Timber.d("MessageBroker request to stop");
    }

    public boolean sendProvisioning(String provisionData) {
        String topic =
                mMessageGenerator.makeTopic(MqttMsgGenerator.TopicType.TOPIC_PROVISIONING);
        String payload = mMessageGenerator.getProvisioningPayload(provisionData);
        AWSIotMessage message = mMessageGenerator.makeIotMessage(topic, payload);
        Publisher blockingPublisher = new Publisher(mClient, message);
        // waiting done by publishing message.
        ThreadUtil.runOnLooperSync(mHandlerThread.getLooper(), blockingPublisher);
        // get result after done.
        return blockingPublisher.getResult();
    }

    private void publishDelayed(String payload, int delayMillis) {
        String publishTopic = mMessageGenerator.makeTopic(MqttMsgGenerator.TopicType.TOPIC_PUBLISH);

        NonBlockingPublishListener nonBlockMessage =
                new NonBlockingPublishListener(publishTopic, AWSIotQos.QOS0, payload);

        Publisher publisher = new Publisher(mClient, nonBlockMessage);

        // Run on HandlerThread
        mHandler.postDelayed(publisher, delayMillis);
    }

    public void publish(String data) {
        String payload = mMessageGenerator.getDevicePacketPayload(data);
        publishDelayed(payload, 0);
    }

    public void publish(byte[] data) {
        String payload =
                mMessageGenerator.getDevicePacketPayload(StringUtils.convertBytesToString(data));
        publishDelayed(payload, 0);
    }

}
