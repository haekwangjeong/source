package com.lge.service.thinq.network;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/*
{
  "resultCode": "0000",
  "result": ""
}
* */
public class BasicStringResult {
    @SerializedName("resultCode")
    @Expose
    private String mResultCode;

    @SerializedName("result")
    @Expose
    private String mResult;

    public String getResultCode() {
        return mResultCode;
    }

    public String getResult() {
        return mResult;
    }

    public boolean isSuccess() { return mResultCode.compareTo("0000") == 0; }
}
