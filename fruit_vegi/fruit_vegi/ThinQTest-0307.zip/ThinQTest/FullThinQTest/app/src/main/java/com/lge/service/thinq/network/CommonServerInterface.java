package com.lge.service.thinq.network;

import com.google.gson.JsonObject;

import java.util.Map;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.HeaderMap;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface CommonServerInterface {
    @Headers({
            "Content-Type: application/json"
    })
    @POST("/device/{deviceId}/certificate")
    Call<DeviceCertificationResult> issueDeviceCertificate(
            @Header("x-message-id") String messageId,
            @Path("deviceId") String deviceId,
            @Body JsonObject body
    );

    @Headers({
            "Content-Type: application/json",
            "x-iot-sdk-type: aws-sdk-android/12.0.0",
            "x-platform-type: ANDROID/12.0.0"
    })
    @GET("/route")
    Call<BasicObjectResult> getEndPoint(
            @Header("x-country-code") String countryCode,
            @Header("x-service-phase") String phase,
            @Header("x-service-code") String serviceCode
    );

    @POST("/iot/device/{deviceId}/control-sync")
    Call<ResponseBody> controlSync(
            @HeaderMap Map<String, String> headers,
            @Path("deviceId") String deviceId,
            @Body JsonObject body
    );
}
