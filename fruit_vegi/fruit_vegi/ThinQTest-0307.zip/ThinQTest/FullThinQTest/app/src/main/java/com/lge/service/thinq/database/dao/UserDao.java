package com.lge.service.thinq.database.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.lge.service.thinq.database.entities.User;

@Dao
public abstract class UserDao {
    @Query("SELECT * FROM user LIMIT 1")
    public abstract User getUser();

    @Query("SELECT COUNT(*) FROM user")
    public abstract int getCount();

    @Query("UPDATE user SET access_token = :accessToken, token_expired_at = :expiredAt")
    public abstract void updateToken(String accessToken, long expiredAt);

    @Query("UPDATE user SET endpoint_url = :endpoint")
    public abstract void updateEndPointUrl(String endpoint);

    @Query("DELETE FROM user")
    public abstract void deleteAll();

    @Insert
    public abstract void insert(User user);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    public abstract void insertOrReplace(User user);

    @Update
    public abstract void update(User user);
}
