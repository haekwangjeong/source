package com.lge.service.thinq.product;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;

import com.lge.service.thinq.mqtt.MqttMessageBroker;
import com.lge.service.thinq.mqtt.MqttMsgGenerator;
import com.lge.service.thinq.utils.StringUtils;
import com.lge.service.thinq.utils.ThreadUtil;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import timber.log.Timber;

public class MainMessageHandler implements MessageHandlerBase {

    private final MqttMessageBroker mMessageBroker;

    private final MqttMsgGenerator mMessageGenerator;

    private final HandlerThread mHandlerThread
            = ThreadUtil.getHandlerThread(getClass().getSimpleName());

    private final MessageHandler mHandler
            = new MessageHandler(mHandlerThread.getLooper(), this);


    public MainMessageHandler(MqttMessageBroker mMessageBroker, MqttMsgGenerator mMessageGenerator) {
        this.mMessageBroker = mMessageBroker;
        this.mMessageGenerator = mMessageGenerator;
    }

    private boolean mIsMonitoring = false;
    private boolean mIsReporting = false;

    private PeriodReporter mPeriodRepoter = null;

    @Override
    public void init() {

    }

    @Override
    public void release() {

    }

    @Override
    public Handler getHandler() {
        return mHandler;
    }

    @Override
    public List<String> getCommands() {
        List<String> cmdList = new ArrayList<String>();
        // Controls packet
        cmdList.add("packet");
        // Controls device
        cmdList.add("modem_cmd");
        // Ack message for published
        cmdList.add("ack");
        return cmdList;
    }

    @Override
    public void dump(PrintWriter writer) {

    }

    private static final class MessageHandler extends Handler {
        private static final String TAG =
                MessageHandler.class.getSimpleName();

        private static MainMessageHandler mHost = null;

        private MessageHandler(Looper looper, MainMessageHandler host) {
            super(looper);
            mHost = host;
        }

        @Override
        public void handleMessage(Message msg) {
            int type = msg.arg1;

            String strPacket = (String) msg.obj;
            int hexPacketLen = strPacket.length() / 2;

            // type == 1 is string format. 0 means json format .
            if (type == 1) {
                mHost.processPacket(StringUtils.convertHexToBytes(strPacket), hexPacketLen);
            } else {
                Timber.e("Opps! message is json format %s", strPacket);
            }
        }
    }

    private boolean processPacket(byte[] packet, int length) {
        // checks valid packet
        if (PacketUtil.isValidPacket(packet, packet[BasePacket.PKT_LENGTH_INDEX]) == false) {
            Timber.d("Opps it is invalid packet. %s", packet);
            return false;
        }

        byte frameId = packet[3];

        switch(frameId) {
            case BasePacket.FID_ACK:
                Timber.d("Cloudlet command = FID_ACK, value = %s", packet[4]);
                break;

            case BasePacket.FID_REF_ACTIVEDATA_REQ: /* 0x1A */
                // [FRG-1956]
                // T1.0 제품을 위한 메세지로 T2에서는 현재 사용하지 않음.
                // T1/T2 제품이 구별되지 않아 일괄 전송됨.
                Timber.d("Cloudlet command = FID_REF_ACTIVEDATA_REQ");
                handleAck(frameId);
                break;

            case BasePacket.FID_PRODUCT_REGISTERED: /* 0x29 */
                boolean enabled = packet[BasePacket.PKT_DATA_INDEX] == 1;
                Timber.d("Cloudlet command = FID_PRODUCT_REGISTERED, value = %b", enabled);
                handleAck(frameId);
                break;

            case BasePacket.FID_BLACKBOX_SETTING: /* 0xCE */
                handleBlackBoxSetting(packet, length);
                handleAck(frameId);
                break;

            case BasePacket.FID_REF_MON_START_REQUEST: /* 0x11 */
                Timber.d("Cloudlet command = FID_REF_MON_START_REQUEST");
                mIsMonitoring = true;
                startReporting(packet, length);
                handleAck(frameId);
                break;

            case BasePacket.FID_REF_MON_STOP_REQUEST: /* 0xEA */
                Timber.d("Cloudlet command = FID_REF_MON_STOP_REQUEST");
                mIsMonitoring = false;
                handleAck(frameId);
                break;

            case BasePacket.FID_EVENT_DRIVEN_START_REQUEST:
                Timber.d("Cloudlet command = FID_EVENT_DRIVEN_START_REQUEST");
                mIsReporting = true;
                startReporting(packet, length);
                handleAck(frameId);
                break;

            case BasePacket.FID_EVENT_DRIVEN_STOP_REQUEST:
                Timber.d("Cloudlet command = FID_EVENT_DRIVEN_STOP_REQUEST");
                mIsReporting = false;
                stopReporting(packet, length);
                handleAck(frameId);
                break;

            case BasePacket.FID_EVENT_DRIVEN_MASK_ON_REQUEST:
                Timber.d("Cloudlet command = FID_EVENT_DRIVEN_MASK_ON_REQUEST");
                /* NOTHING TO DO */
                handleAck(frameId);
                break;

            case BasePacket.FID_REFDIAG_START_REQUEST:
                Timber.d("Cloudlet command = FID_REFDIAG_START_REQUEST");
                handleAck(frameId);
                break;

            default : {
                // TODO : 여기서 처리 하지 않는 데이타는 Hal Interface로 Bypass한다.
                break;
            }

        }
        return true;
    }

    private boolean handleAck(byte id) {
        byte[] packet = new byte[7];
        Arrays.fill(packet, (byte)0);
        packet[0] = (byte) 0xAA;
        packet[1] = (byte) 0x07;
        packet[2] = (byte) 0xF0;
        packet[3] = BasePacket.FID_ACK;
        packet[4] = id;
        packet[5] = (byte) PacketUtil.makeCRC(packet, packet[1]-2);
        packet[6] = (byte)0xBB;

        // Sends to Cloudlet
        mMessageBroker.publish(packet);
        return true;
    }

    private boolean handleBlackBoxSetting(byte[] packet, int length) {
        boolean enabled = packet[BasePacket.PKT_DATA_INDEX] == 1;
        Timber.d("Cloudlet command = FID_BLACKBOX_SETTING value = %b", enabled);
        return true;
    }

    private boolean startReporting(byte[] packet, int length) {

        if (mPeriodRepoter != null) {
            mPeriodRepoter = null;
        }

        mPeriodRepoter = new PeriodReporter(mMessageBroker);

        // data[6] : hour, data[7] : minute, data[8] : second
        int period = packet[6]*60*60 + packet[7]*60 + packet[8];

        // data[9] : 제품으로 monitoring request를 요청하기 위한 period
        int repeat = 0; // controlfridged에서 담당하므로 해당값을 no-used.

        // TODO : 삭제 할것.
        // 임시, ThinQ App에서 제품 데이타가 보이도록 하기 위해
        // FID_REF_MON_START_REQUEST를 수신후, Dummy device data를 전송한다.
        String testPayload = "AA1810EB020104010202FF00010000FF00000000FF0092BB";
        mMessageBroker.publish(testPayload);
        return true;
    }

    private boolean stopReporting(byte[] packet, int length) {
        // no need more.
        if (mPeriodRepoter != null) {
            mPeriodRepoter = null;
        }

        return true;
    }

}
