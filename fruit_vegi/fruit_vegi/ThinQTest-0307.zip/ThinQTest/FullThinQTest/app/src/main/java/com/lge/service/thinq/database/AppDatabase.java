package com.lge.service.thinq.database;

import android.content.Context;
import timber.log.Timber;

import androidx.annotation.NonNull;
import androidx.room.Database;

import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

import com.lge.service.thinq.database.dao.UserDao;
import com.lge.service.thinq.database.entities.User;

@Database(
        entities = {User.class},
        version = 1,
        exportSchema = false
)
public abstract class AppDatabase extends RoomDatabase {

    private static final String DATABASE_NAME = "com.lge.service.thinq.db";

    private static AppDatabase mInstance;

    synchronized public static AppDatabase getInstance(final Context context) {
        if (mInstance == null) {
            mInstance = buildDatabase(context);
        }
        return mInstance;
    }

    private static AppDatabase buildDatabase(Context context) {
        return Room.databaseBuilder(context, AppDatabase.class, DATABASE_NAME).addCallback(new Callback() {
            @Override
            public void onCreate(@NonNull SupportSQLiteDatabase db) {
                Timber.d("create database schema version = %d", db.getVersion());
                super.onCreate(db);
            }
        }).allowMainThreadQueries().build();
    }

    public abstract UserDao userDao();
}
