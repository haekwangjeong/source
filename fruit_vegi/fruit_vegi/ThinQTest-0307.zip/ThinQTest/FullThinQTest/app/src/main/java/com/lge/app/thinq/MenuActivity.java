package com.lge.app.thinq;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import lge.home.thinq.ThinQAgent;
import lge.home.thinq.ThinQConfigManager;
import lge.home.thinq.ThinQDeviceManager;
import lge.home.thinq.ThinQNetworkManager;
import lge.home.thinq.ThinQTokenManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;


public class MenuActivity extends AppCompatActivity {
    public Context mContext;
    private static final String TAG = "SettingActivity2";
    private static final int DELBTN_SHOW = 1;
    private static final int DELBTN_HIDE = 2;
    private static final int ADDBTN_SHOW = 3;
    private static final int ADDBTN_HIDE = 4;

    private static final int INTADDDEVICE = 0;
    private static final int INTDELDEVICE = 1;
    private static final int INTACCESSTOKEN = 2;
    private static final int INTREFRESHTOKEN = 3;
    private static final int INTGOTONEXTPAGE = 4;

    private static String ADDDEVICE ="adddevice";
    private static String DELDEVICE ="deldevice";
    private static String REFRESHTOKEN ="RefreshToken";
    private static String ACCESSTOKEN ="AccessToken";
    private static String NEXTPAGE ="GoToNextPage";

    private ThinQAgent mAgent;
    private ThinQConfigManager mConfigManager;
    private ThinQTokenManager mTokenManager;
    private ThinQDeviceManager mDeviceManager;
    private ThinQNetworkManager mNetworkManager;
    private String showTermsUrl;
    private String updateTermsUrl;
    private String accesstoken;
    private String refreshtoken;
    private String  backendUrl;

    private boolean isRegistered = false;
    private ExecutorService mExecutor;
    Button delBtn;
    Button addBtn;
    RadioButton nextPage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settingsactivity2);
        mContext = this;

        Intent secondIntent = getIntent();
        accesstoken = secondIntent.getStringExtra("accesstoken");
        refreshtoken = secondIntent.getStringExtra("refreshtoken");
        backendUrl = secondIntent.getStringExtra("url");
        isRegistered = secondIntent.getBooleanExtra("deviceRegistered", false);
        mExecutor = Executors.newSingleThreadExecutor();
        delBtn = findViewById(R.id.delete_button);
        addBtn = findViewById(R.id.adddevice_button);
        connectThinQAgent();

        accesstokenBtnEvent();
        addDeviceBtnEvent(addBtn, isRegistered);
        delDeviceBtnEvent(delBtn);
        getDefaultHeaderEvent();
        getConfigEvent();


    }
    private void controlBtn(Button btn, int num) {

        switch(num) {
            case DELBTN_SHOW:
            case ADDBTN_SHOW:
                btn.setEnabled(true);
                break;
            case DELBTN_HIDE:
            case ADDBTN_HIDE:
                btn.setEnabled(false);
                break;
            default:
                break;
        }

    }
    private void connectThinQAgent() {
        mAgent = ThinQAgent.createThinQAgent(this, null,
            (agent, ready) -> {
                if (!ready) return;

                mConfigManager = (ThinQConfigManager) agent.getManager(ThinQAgent.CONFIG_SERVICE);
                mDeviceManager = (ThinQDeviceManager) agent.getManager(ThinQAgent.DEVICE_SERVICE);
                mNetworkManager = (ThinQNetworkManager) agent.getManager(ThinQAgent.NETWORK_SERVICE);

                String deviceId = mConfigManager.getDeviceId();

                String serviceServerUrl = mNetworkManager.getServerUrl();
            });
    }

    protected String getAccessTokenFromService() {
        String accessToken = null;

        // ThinQ Network service는 MainThread에서 호출하면 안됨.
        Callable<String> callable = new Callable<String>() {
            @Override
            public String call() throws Exception {
                return mNetworkManager.getAccessToken();
            }
        };

        Future<String> future = mExecutor.submit(callable);
        try {
            accessToken = future.get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        return accessToken;
    }


    protected Map<String,String> getDefaultHeadersFromService() {
        Map<String,String> defaultHeaders = new HashMap<>();

        // ThinQ Network service는 MainThread에서 호출하면 안됨.
        Callable<Map<String,String>> callable = new Callable<Map<String,String>>() {
            @Override
            public Map<String,String> call() throws Exception {
                return mNetworkManager.getDefaultHeaders();
            }
        };

        Future<Map<String,String>> future = mExecutor.submit(callable);
        try {
            defaultHeaders = future.get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        return defaultHeaders;
    }

    protected void addDeviceBtnEvent(Button addBtn, boolean enable) {

        if (enable) {
            controlBtn(addBtn,ADDBTN_HIDE);
            controlBtn(delBtn,DELBTN_SHOW);
        } else if(enable == false) {
            controlBtn(addBtn,ADDBTN_SHOW);
            controlBtn(delBtn,DELBTN_HIDE);
        }

        addBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                boolean result = false;
                Callable<Boolean> callable = new Callable<Boolean>() {
                    @Override
                    public Boolean call() throws Exception {
                        // Network service는 MainThread에서 호출하면 안됨.
                        return mDeviceManager.addDevice(accesstoken, refreshtoken, backendUrl);
                    }
                };

                Future<Boolean> future = mExecutor.submit(callable);
                try {
                    result = future.get();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                TextView tv = findViewById(R.id.textView);

                if (!result) {
                    tv.setText("Failed device registration");
                    isRegistered = false;
                } else {
                    isRegistered = true;
                    // 제품 등록 되었으므로, 제품등록 버튼 비활성화.
                    tv.setText("registeration Success");

                    controlBtn(addBtn,ADDBTN_HIDE);
                    controlBtn(delBtn,DELBTN_SHOW);
                }
            }
        });
    }
    protected void delDeviceBtnEvent(Button delBtn) {

        delBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                boolean result = false;
                Callable<Boolean> callable = new Callable<Boolean>() {
                    @Override
                    public Boolean call() throws Exception {
                        // Network service는 MainThread에서 호출하면 안됨.
                        return mDeviceManager.deleteDevice();
                    }
                };

                Future<Boolean> future = mExecutor.submit(callable);
                try {
                    result = future.get();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                TextView tv = findViewById(R.id.textView);

                if (!result) {
                    tv.setText("Failed device unregistration");
                    isRegistered = true;
                } else {
                    tv.setText("unregistration Success");
                    isRegistered = false;

                    // deleteDevice() 완료시, WebviewActivity로 이동한다.
                    Intent intent = new Intent(MenuActivity.this, EmpLoginActivity.class);
                    startActivity(intent);

//                    controlBtn(addBtn,ADDBTN_SHOW);
//                    controlBtn(delBtn,DELBTN_HIDE);
                }
            }
        });
    }
    protected void accesstokenBtnEvent() {
        Button b = findViewById(R.id.access_button);
        b.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                TextView tv = findViewById(R.id.textView);

                if (!isRegistered) {
                    showMsgDialog("Failed", "Not yet AddDevice");
                    return;
                }

                String accessToken = getAccessTokenFromService();

                if (accessToken == null) {
                    showMsgDialog("Failed", "Failed issues accessToken");
                } else {
                    showMsgDialog("Success", accessToken);
                }
            }
        });
    }
    protected void getConfigEvent() {
        Button b = findViewById(R.id.configbutton);
        b.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showGetConfigDlg();
            }
        });
    }
    protected void getDefaultHeaderEvent() {
        Button b = findViewById(R.id.getHeader_button);
        b.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                TextView tv = findViewById(R.id.textView);
                Map<String,String> defaultHeaders = new HashMap<>();

                if (!isRegistered) {
                    showMsgDialog("Failed", "Not yet AddDevice");
                    return;
                }

                defaultHeaders = getDefaultHeadersFromService();//null;

                Log.d(TAG,"key 출력>>>" + defaultHeaders.keySet()); // [이름, 나이, 직업]
                Log.d(TAG,"value 출력>>>" + defaultHeaders.values()); // [siri, 13, 학생]
                Log.d(TAG,"키벨류 출력>>>" + defaultHeaders.toString());

                Log.d(TAG,"<< 전체 map2의 키 출력 >>");
                Set<String> set = defaultHeaders.keySet();
                Iterator<String> keyset = set.iterator();
                while (keyset.hasNext()) {
                    String key = keyset.next();
                    Log.d(TAG,key + "에 저장된 데이터 :" + defaultHeaders.get(key));
                }
            }
        });
    }

    protected void showMsgDialog(String title, String message) {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setNegativeButton("Cancel",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
        builder.show();
    }
    void showCountry() {
        final List<String> ListItems = new ArrayList<>();
        final List SelectedItems  = new ArrayList();
        int defaultItem = 0;
        ListItems.add("US");
        ListItems.add("KR");


        String getcountry = mConfigManager.getCountry();

        if(getcountry =="US") {
            defaultItem = 0;
        } else if(getcountry == "KR") {
            defaultItem = 1;
        } else {
            defaultItem = 0;
        }
        SelectedItems.add(defaultItem);
        final CharSequence[] items =  ListItems.toArray(new String[ ListItems.size()]);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("GetCountry");
        builder.setSingleChoiceItems(items, defaultItem,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        SelectedItems.clear();
                        SelectedItems.add(which);
                    }
                });
        builder.setPositiveButton("Ok",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        String msg="";

                        if (!SelectedItems.isEmpty()) {
                            int index = (int) SelectedItems.get(0);
                            msg = ListItems.get(index);
                        }
                        Toast.makeText(getApplicationContext(),
                                "Items Selected.\n"+ msg , Toast.LENGTH_LONG)
                                .show();
                    }
                });
        builder.setNegativeButton("Cancel",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
        builder.show();

    }
    void showStage() {
        final List<String> StageListItems = new ArrayList<>();
        final List StageSelectedItems  = new ArrayList();
        int defaultItem = 0;
        String getStage;
        StageListItems.add("ST");
        StageListItems.add("OS");
        StageListItems.add("OP");

        getStage = mConfigManager.getStage();


        if(getStage == "ST") {
            defaultItem = 0;
        } else if(getStage == "OS") {
            defaultItem = 1;
        } else if(getStage == "OP") {
            defaultItem = 2;
        } else {
            defaultItem = 0;
        }

        final CharSequence[] stageitems =  StageListItems.toArray(new String[ StageListItems.size()]);


        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("getStage");
        builder.setSingleChoiceItems(stageitems, defaultItem,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        StageSelectedItems.clear();
                        StageSelectedItems.add(which);
                    }
                });
        builder.setPositiveButton("Ok",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        String msg="";

                        if (!StageSelectedItems.isEmpty()) {
                            int index = (int) StageSelectedItems.get(0);
                            msg = StageListItems.get(index);
                        }


                        Toast.makeText(getApplicationContext(),
                                "Items Selected.\n"+ msg , Toast.LENGTH_LONG)
                                .show();
                    }
                });
        builder.setNegativeButton("Cancel",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
        builder.show();
    }
    void showconfigInfo() {
        String deviceId;
        String serverUrl;
        deviceId = mConfigManager.getDeviceId();
        serverUrl = mNetworkManager.getServerUrl();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        String messageStr = "1.deviceId:"+deviceId+"\n"+"2.serverUrl:"+serverUrl;


        builder.setTitle("ConfigInfo");
        builder.setMessage(messageStr);

        builder.setPositiveButton("ok",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

        builder.show();
    }
    void showGetConfigDlg()
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setPositiveButton("showCountry",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        showCountry();
                    }
                });

        builder.setNegativeButton("showStage",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        showStage();
                    }
                });
        builder.setNeutralButton("showconfigInfo",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        showconfigInfo();
                    }
                });
        builder.show();
    }
}