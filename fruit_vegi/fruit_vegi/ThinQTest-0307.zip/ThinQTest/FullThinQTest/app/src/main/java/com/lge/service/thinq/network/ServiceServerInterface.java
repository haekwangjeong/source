package com.lge.service.thinq.network;

import com.google.gson.JsonObject;

import java.util.Map;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.HTTP;
import retrofit2.http.HeaderMap;
import retrofit2.http.POST;
import retrofit2.http.DELETE;

import retrofit2.http.Path;

public interface ServiceServerInterface {
    @GET("/v1/service/application/gateway-uri")
    Call<ResponseBody> getGatewayUri();

    @GET("/v1/product/devices/{deviceId}/key")
    Call<ResponseBody> registerKey(
            @HeaderMap Map<String, String> headers,
            @Path("deviceId") String deviceId,
            @Body JsonObject body
    );

    @POST("/v1/product/users/client")
    Call<BasicStringResult> addClient(
            @HeaderMap Map<String, String> headers,
            @Body JsonObject body
    );

    @POST("/v1/product/devices/otp/certificate")
    Call<CertResult> getCertificate(
            @HeaderMap Map<String, String> headers
    );

    @POST("/v1/product/devices")
    Call<RegisteredDeviceResult> addDevice(
            @HeaderMap Map<String, String> headers,
            @Body JsonObject body
    );

    @HTTP(method="DELETE", path="/v1/product/devices/{deviceId}/initialize", hasBody = true)
    Call<BasicStringResult> deleteDevice(
            @HeaderMap Map<String, String> headers,
            @Path("deviceId") String deviceId,
            @Body JsonObject body
    );

    @POST("/v1/product/devices/{deviceId}/control-sync")
    Call<BasicObjectResult> controlDeviceSync(
            @HeaderMap Map<String, String> headers,
            @Path("deviceId") String deviceId,
            @Body JsonObject body
    );

    @GET("/v1/product/devices/{deviceId}/firmware")
    Call<ResponseBody> checkNewFirmware(
            @HeaderMap Map<String, String> headers,
            @Path("deviceId") String deviceId
    );

    @GET("/v1/product/devices/directFota/firmware?partNumber={partNumber}")
    Call<ResponseBody> checkNewDirectFirmware(
            @HeaderMap Map<String, String> headers,
            @Path("partNumber") String partNumber
    );
}
