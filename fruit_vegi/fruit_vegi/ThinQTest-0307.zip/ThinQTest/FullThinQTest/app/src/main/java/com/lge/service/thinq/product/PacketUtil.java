package com.lge.service.thinq.product;

public class PacketUtil {

    static public int makeCRC(byte[] data, int length) {
        int idx = 0;
        int sum = 0;

        while (length > 0) {
            length--;
            sum += data[idx];
            idx++;
        }

        return (sum ^ 0x55);
    }

    static public boolean isValidPacket(byte[] data, int length) {
        if (BasePacket.PKT_START_BYTE != data[0]) {
            return false;
        }

        if (length < BasePacket.PKT_MINIMUM_SIZE) {
            return false;
        }

        if (BasePacket.PKT_END_BYTE != data[length - 1]) {
            return false;
        }

        if (makeCRC(data, length - 2) != data[length - 2]) {
            return false;
        }

        return true;
    }
}
