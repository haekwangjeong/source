package com.lge.service.thinq.network;

import android.content.Context;

import androidx.annotation.NonNull;

import com.lge.service.thinq.configuration.ConfigProxy;
import com.lge.service.thinq.configuration.StringConstants;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import timber.log.Timber;

public class OAuthServerMoudle {

    // TODO : Read from Config.json
    private final static int HTTP_TIMEOUT = 20;

    private Context mContext;

    private OAuthServerInterface mOAuthInterface;

    public OAuthServerMoudle(Context context) {
        mContext = context;
    }

    @NonNull
    private Retrofit.Builder getRetroBuilder(String url) {
        return new Retrofit.Builder()
                .baseUrl(url)
                .client(getOkHttpClient())
                .addConverterFactory(GsonConverterFactory.create());
    }

    @NonNull
    private OkHttpClient getOkHttpClient() {
        return new OkHttpClient.Builder()
                .connectTimeout(HTTP_TIMEOUT, TimeUnit.SECONDS)
                .readTimeout(HTTP_TIMEOUT, TimeUnit.SECONDS)
                .writeTimeout(HTTP_TIMEOUT, TimeUnit.SECONDS)
                .addInterceptor(new HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY))
                .build();
    }

    public OAuthServerInterface createOAuthServerInterface() {
        String baseUrl = ConfigProxy.getInstance(mContext).getOAuthDomain();
        baseUrl += "/";

        if (mOAuthInterface == null) {
            mOAuthInterface = getRetroBuilder(baseUrl).build().create(OAuthServerInterface.class);
        }

        return mOAuthInterface;
    }

}
