package com.lge.service.thinq.network;

import android.content.Context;
import android.os.Bundle;
import android.util.Base64;

import com.google.gson.JsonObject;
import com.lge.service.thinq.configuration.ConfigProxy;
import com.lge.service.thinq.database.UserRepository;
import com.lge.service.thinq.database.entities.User;
import com.lge.service.thinq.utils.CipherTextGenerator;
import com.lge.service.thinq.utils.IdentifierGenerator;

import org.spongycastle.operator.OperatorCreationException;
import org.spongycastle.pkcs.PKCS10CertificationRequest;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.security.KeyPair;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutionException;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Response;
import timber.log.Timber;

public class CommonServerProxy {

    private static final String TAG = "CommonServerProxy";

    private Context mServiceContext;

    private static CommonServerProxy mInstance;

    private CommonServerInterface mCommonServerInterface;

    public synchronized static CommonServerProxy getInstance(Context context) {
        if (mInstance == null) {
            mInstance = new CommonServerProxy(context);
        }

        return mInstance;
    }

    public CommonServerProxy(Context context) {
        mServiceContext = context;

        mCommonServerInterface =
                HttpAdapter.getInstance(mServiceContext).createCommonServerModule();
    }

    public JsonObject issueServerCertification(
            Key signKey,
            String randomKey,
            String otp,
            String deviceId,
            KeyPair deviceKeyPair) {
        String publicKey = null;
        try {
            publicKey = CipherTextGenerator.convertToPemString(deviceKeyPair.getPublic());
        } catch (IOException e) {
            e.printStackTrace();
        }

        String csr = null;
        try {
            PKCS10CertificationRequest certificationRequest
                    = CipherTextGenerator.generateCSR(deviceKeyPair, UUID.randomUUID().toString());
            csr = CipherTextGenerator.convertToPemString(certificationRequest);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (OperatorCreationException e) {
            e.printStackTrace();
        }

        String cipherText = CipherTextGenerator.generateCipherText(signKey, randomKey, otp, deviceId, csr, publicKey);

        JsonObject body = new JsonObject();
        body.addProperty("otp", otp);
        body.addProperty("publickey", publicKey);
        body.addProperty("csr", csr);
        body.addProperty("certificate", "");
        body.addProperty("ciphertext", cipherText);

        Call<DeviceCertificationResult> call = mCommonServerInterface.issueDeviceCertificate(
                IdentifierGenerator.getMessageId(),
                deviceId,
                body
        );

        String resultString = null;
        try {
            Response<DeviceCertificationResult> response = call.execute();

            if (!response.isSuccessful()) {
                Timber.e("Failed issueServerCertification() response = %s", response.errorBody().string());
                return null;
            }

            DeviceCertificationResult responseBody = response.body();

            if (!responseBody.isSuccess()) {
                return null;
            }

            return responseBody.getResult();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    public JsonObject getEndPoint() {
        String countryCode =
                ConfigProxy.getInstance(mServiceContext).getConfig(ConfigProxy.ConfigValue.TARGET_COUNTRY);
        String stage =
                ConfigProxy.getInstance(mServiceContext).getConfig(ConfigProxy.ConfigValue.TARGET_STAGE);
        String svcCode =
                ConfigProxy.getInstance(mServiceContext).getThinQServiceCode();

        Call<BasicObjectResult> call =
                mCommonServerInterface.getEndPoint(countryCode, stage, svcCode);

        try {
            Response<BasicObjectResult> response = call.execute();

            if (!response.isSuccessful()) {
                Timber.e("Failed getEndPoint() response = %s", response.errorBody().string());
                return null;
            }

            BasicObjectResult responseBody = response.body();

            if (!responseBody.isSuccess()) {
                return null;
            }

            return responseBody.getJsonResult();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    private Map<String, String> getDefaultHeaders(String deviceId, String userNo) {
        Map<String, String> headers = new HashMap<>();

        headers.put("Content-Type", "application/json");
        headers.put("x-service-code", "SVC202");
        headers.put("x-service-phase", "ST");
        headers.put("x-country-code", "KR");
        headers.put("x-api-key", "W6aiX4OOg466HuML0JIPL5uAqGbwZF0h52Bx6gfC");
        headers.put("x-client-id", deviceId);
        headers.put("x-user-no", userNo);
        headers.put("x-message-id", "_A4P5VkqRDeJLk1nD7sICg");
        headers.put("x-max-timeout", "5");

        return headers;
    }

    public void controlSync(String deviceId, String userNo, String payload) {
        Map<String, String> headers = getDefaultHeaders(deviceId, userNo);

        JsonObject reqBody = new JsonObject();
        reqBody.addProperty("Message", payload);

        Call<ResponseBody> call =
                mCommonServerInterface.controlSync(headers, deviceId, reqBody);

        try {
            Response<ResponseBody> response = call.execute();

            if (!response.isSuccessful()) {
                Timber.e("Failed controlSync() response = %s", response.errorBody().string());
                return;
            }

            ResponseBody responseBody = response.body();

            Timber.d("controlSync responseBody = %s", responseBody.string());

            return;
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
