package com.lge.service.thinq.network;

import com.google.gson.JsonObject;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/*
{
  "resultCode": "0000",
  "result": {
    "certificatePem": "-----BEGIN CERTIFICATE-----\n-----END CERTIFICATE-----\n",
    "publication": {
      "message": "$aws/rules/clip_http_action_rule/clip/devices/7777-8888-9999-000011112222/message",
      "provisioning": "$aws/rules/clip_provisioning_rule/clip/provisioning/devices/7777-8888-9999-000011112222",
      "control": "$aws/rules/clip_control_rule/clip/control/devices/7777-8888-9999-000011112222"
    },
    "subscription": {
      "message": "lime/devices/7777-8888-9999-000011112222"
    }
  }
}
* */
public class DeviceCertificationResult {
    @SerializedName("resultCode")
    @Expose
    private String mResultCode;

    @SerializedName("result")
    @Expose
    private JsonObject mResult;

    public String getResultCode() {
        return mResultCode;
    }

    public JsonObject getResult() { return mResult; }

    public boolean isSuccess() { return mResultCode.compareTo("0000") == 0; }
}
