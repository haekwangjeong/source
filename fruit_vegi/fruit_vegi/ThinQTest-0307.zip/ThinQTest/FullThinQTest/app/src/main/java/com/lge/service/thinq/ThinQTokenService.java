package com.lge.service.thinq;

import android.content.Context;
import android.os.RemoteException;

import com.lge.service.thinq.network.OAuthServerProxy;
import com.lge.service.thinq.network.ServiceServerProxy;

import java.io.PrintWriter;

import lge.home.thinq.IThinQToken;

public class ThinQTokenService extends IThinQToken.Stub
        implements ThinQServiceBase {

    private Context mServiceContext;

    private OAuthServerProxy mOAuthProxy;

    private ServiceServerProxy mServiceServerProxy;

    ThinQTokenService(Context context, OAuthServerProxy oauthProxy, ServiceServerProxy serviceProxy) {
        mServiceContext = context;
        mOAuthProxy = oauthProxy;
        mServiceServerProxy = serviceProxy;
    }

    @Override
    public void init() {
    }

    @Override
    public void release() {
    }

    @Override
    public void dump(PrintWriter writer) {
    }

    @Override
    public String getAccessToken() throws RemoteException {
        if (!mOAuthProxy.isReady()) {
            // TODO : Error 에 대한 detail한 정보를 넘겨야 한다.
            // "{"result":true, "errorText":"not ready or not register device"}"
            return new String("mOAuthProxy isn't ready");
        }

        return mOAuthProxy.getAccessToken();
    }
}
