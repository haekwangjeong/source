package com.lge.service.thinq.network;

import android.content.Context;

import com.lge.service.thinq.database.UserRepository;

public final class HttpAdapter {

    private static HttpAdapter mHttpAdapter;

    private Context mContext;

    private OAuthServerMoudle mOAuthServer;

    private ServiceServerModule mServiceServer;

    private CommonServerMoudle mCommonServer;

    private HttpAdapter(Context context) {
        mContext = context;

        mOAuthServer = new OAuthServerMoudle(context);

        mServiceServer = new ServiceServerModule(context);

        mCommonServer = new CommonServerMoudle(context);
    }

    public synchronized static HttpAdapter getInstance(Context context) {
        if (mHttpAdapter == null) {
            mHttpAdapter = new HttpAdapter(context);
        }

        return mHttpAdapter;
    }

    public OAuthServerInterface createOAuthServerModule() {
        return mOAuthServer.createOAuthServerInterface();
    }

    public ServiceServerInterface createServiceServerModule(UserRepository userRepository) {
        return mServiceServer.createServiceServerInterface(userRepository);
    }

    public CommonServerInterface createCommonServerModule() {
        return mCommonServer.createCommonServerInterface();
    }
}
