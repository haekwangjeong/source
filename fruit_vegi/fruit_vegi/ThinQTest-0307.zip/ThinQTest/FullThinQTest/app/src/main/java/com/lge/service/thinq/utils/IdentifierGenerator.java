package com.lge.service.thinq.utils;

import android.util.Base64;

import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Random;
import java.util.UUID;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

public class IdentifierGenerator {


    public static String getMessageId() {
        String messageId = "";

        UUID uuid = UUID.randomUUID();
        ByteBuffer byteBuffer = ByteBuffer.wrap(new byte[16]);
        byteBuffer.putLong(uuid.getMostSignificantBits());
        byteBuffer.putLong(uuid.getLeastSignificantBits());
        byteBuffer.flip();

        try {
            messageId = new String(
                    Base64.encode(byteBuffer.array(),
                    Base64.URL_SAFE | Base64.NO_PADDING),
                    "UTF-8").trim();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        return messageId;
    }

    public static String getRandomKey(int length) {
        String randomKey = "";

        Random ranGen = new SecureRandom();
        byte[] randomKeyBytes = new byte[length];
        ranGen.nextBytes(randomKeyBytes);

        randomKey = StringUtils.convertBytesToString(randomKeyBytes);

        return randomKey.substring(0,length);
    }

    public static String getSecretKey(int keySize) {
        SecretKey secretKey = null;
        String stringKey = null;

        try {
            final KeyGenerator keyGen = KeyGenerator.getInstance("AES");
            keyGen.init(keySize);
            secretKey = keyGen.generateKey();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }

        stringKey = StringUtils.convertBytesToString(secretKey.getEncoded());
        return stringKey;
    }
}
