package com.lge.service.thinq.network;

import android.content.Context;
import android.os.Bundle;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.lge.service.thinq.configuration.ConfigProxy;
import com.lge.service.thinq.database.UserRepository;
import com.lge.service.thinq.database.entities.User;
import com.lge.service.thinq.utils.IdentifierGenerator;
import lge.home.thinq.ThinQError;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Response;
import timber.log.Timber;

public class ServiceServerProxy {

    private static final String TAG = "ServiceServerProxy";

    private Context mServiceContext;

    private static ServiceServerProxy mInstance;

    private final OAuthServerProxy mOAuthProxy;

    private static final Object mLock = new Object();

    private ServiceServerInterface mServiceServerInterface;

    private UserRepository mUserRepository;

    private boolean mReadyUserRepository;

    private User mUser;

    private String mUserNo;

    public synchronized static ServiceServerProxy getInstance(
            Context context,
            UserRepository userRepository,
            OAuthServerProxy oauthProxy
    ) {
        if (mInstance == null) {
            mInstance = new ServiceServerProxy(context, userRepository, oauthProxy);
        }

        return mInstance;
    }

    public ServiceServerProxy(Context context, UserRepository userRepository, OAuthServerProxy oauthProxy) {
        mServiceContext = context;
        mUserRepository = userRepository;

        mOAuthProxy = oauthProxy;

        mServiceServerInterface =
                HttpAdapter.getInstance(mServiceContext).createServiceServerModule(mUserRepository);

        try {
            mReadyUserRepository = mUserRepository.hasUser();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        if (!mReadyUserRepository) {
            return;
        }

        try {
            mUser = mUserRepository.getUser();
            mUserNo = mUser.userNo;
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public boolean isReady() {
        return mReadyUserRepository;
    }

    private String getUserNum() {
        String userNo = null;
        if (mUserNo != null && !mUserNo.isEmpty()) {
            return mUserNo;
        } else {
            if (mReadyUserRepository == false) return null;

            try {
                mUser = mUserRepository.getUser();
                userNo = mUser.userNo;
                mUserNo = userNo;
            } catch (ExecutionException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        return userNo;
    }

    public Map<String, String> getDefaultHeaders() {
//        String accessToken = mOAuthProxy.getAccessToken();
//        String userNum = getUserNum();
//        return getDefaultHeaders(accessToken, userNum);
        User user = null;
        try {
            user = mUserRepository.getUser();
        } catch (ExecutionException | InterruptedException e) {
            throw new UnsupportedOperationException(ThinQError.ERROR_NO_DEVICE_REGISTRATION.toString());
        }

        return getDefaultHeaders(user.accessToken, user.userNo);
    }

    public Map<String, String> getDefaultHeaders(String accessToken, String userNo) {
        Map<String, String> headers = new HashMap<>();

        // default headers
        Map<String, List<String>> defaultHeaders =
                CommonHeader.builder(mServiceContext, new IdentifierGenerator()).build().toMultimap();

        for (String key : defaultHeaders.keySet()) {
            headers.put(key, defaultHeaders.get(key).get(0));
        }

        // variable headers
        headers.put("x-emp-token", accessToken);
        headers.put("x-user-no", userNo);
        return headers;
    }

    public String getServerUrlInfo() {
        Call<ResponseBody> call = mServiceServerInterface.getGatewayUri();

        String resultString = null;
        try {
            resultString = call.execute().body().string();
            Timber.d("result = %s", resultString);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return resultString;
    }

    public boolean registerKey(String key) {
        JsonObject body = new JsonObject();
        body.addProperty("key", key);
        Map<String, String> headers = getDefaultHeaders();
        return true;
    }

    public boolean requestAddClient(String accessToken, String userNo) {
        JsonObject dummyBody = new JsonObject();
        Map<String, String> headers = getDefaultHeaders(accessToken, userNo);
        Call<BasicStringResult> call = mServiceServerInterface.addClient(headers, dummyBody);

        try {
            BasicStringResult response = call.execute().body();
            boolean result = response.isSuccess();

            if (!result) {
                Timber.e("failed requestAddClient() message = %s", response.toString());
            }

            return true;
        } catch (IOException e) {
            e.printStackTrace();
        }

        return false;
    }

    public CertResult.Cert requestCertificate(String accessToken, String userNo) {
        Map<String, String> headers = getDefaultHeaders(accessToken, userNo);

        Call<CertResult> call = mServiceServerInterface.getCertificate(headers);
        Bundle bundle = new Bundle();

        try {
            CertResult response = call.execute().body();
            boolean result = response.isSuccess();

            if (!result) {
                Timber.e("failed requestCertificate()");
            }

            return response.getResult();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    public boolean requestAddDevice(String accessToken, String refreshToken, String userNo, String deviceId, String cipherText) {
        Map<String, String> headers = getDefaultHeaders(accessToken, userNo);

        JsonObject body = new JsonObject();
        body.addProperty("deviceId", deviceId);
        body.addProperty("deviceType", ConfigProxy.getInstance(mServiceContext).getConfig(ConfigProxy.ConfigValue.TARGET_DEVICE_TYPE));
        body.addProperty("modelName", ConfigProxy.getInstance(mServiceContext).getConfig(ConfigProxy.ConfigValue.TARGET_MODELNAME));
        body.addProperty("countryCode", ConfigProxy.getInstance(mServiceContext).getConfig(ConfigProxy.ConfigValue.TARGET_COUNTRY));
        body.addProperty("aliasPrefix", ConfigProxy.getInstance(mServiceContext).getConfig(ConfigProxy.ConfigValue.TARGET_DEVICE_ALIAS));
        body.addProperty("deviceRegistKey", refreshToken);
        body.addProperty("ciphertext", cipherText);
        body.addProperty("platformType", "thinq2");

        Call<RegisteredDeviceResult> call = mServiceServerInterface.addDevice(headers, body);

        try {
            RegisteredDeviceResult response = call.execute().body();

            boolean result = response.isSuccess();

            if (!result) {
                Timber.e("failed addDevice()");
            }

            return result;
        } catch (IOException e) {
            e.printStackTrace();
        }

        return false;
    }

    public boolean requestDeleteDevice(String accessToken, String refreshToken, String deviceId, String userNo) {
        Map<String, String> headers = getDefaultHeaders(accessToken, userNo);

        JsonObject body = new JsonObject();
        body.addProperty("userNo", userNo);
        body.addProperty("deviceRegistKey", refreshToken);

        Call<BasicStringResult> call = mServiceServerInterface.deleteDevice(headers, deviceId, body);

        try {
            Response<BasicStringResult> response = call.execute();

            // TODO : 아래와 같이 HTTP Status Code 200가 아닌 경우를 감안해서 처리 해야 한다.
            if (!response.isSuccessful()) {
                Timber.e("failed deleteDevice() response = %s",  response.errorBody().string());
                return false;
            }

            BasicStringResult serverResult = response.body();

            boolean result = serverResult.isSuccess();

            if (!result) {
                Timber.e("failed deleteDevice()");
            }

            return result;
        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    public String controlDeviceSync(String accessToken, String userNo, String targetDeviceId, String jsonMessage) {

        Map<String, String> headers = getDefaultHeaders(accessToken, userNo);

        if (headers == null) {
            return null;
        }

        JsonObject reqBody = JsonParser.parseString(jsonMessage).getAsJsonObject();

        Call<BasicObjectResult> call = mServiceServerInterface.controlDeviceSync(headers, targetDeviceId, reqBody);

        try {
            Response<BasicObjectResult> response = call.execute();

            if (!response.isSuccessful()) {
                Timber.e("failed controlDeviceSync() response = %s",  response.errorBody().string());
                return null;
            }

            BasicObjectResult serverResult = response.body();

            boolean result = serverResult.isSuccess();

            if (!result) {
                Timber.e("failed deleteDevice()");
            }

            return null;
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }
}
