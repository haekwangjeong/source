package lge.home.thinq;

import android.os.IBinder;
import android.os.RemoteException;

import java.util.HashMap;
import java.util.Map;

public class ThinQNetworkManager extends ThinQManagerBase {
    IThinQNetwork mThinQNetworkService;

    public ThinQNetworkManager(ThinQAgent agent, IBinder service) {
        super(agent);

        mThinQNetworkService = IThinQNetwork.Stub.asInterface(service);
    }

    @Override
    protected void onServiceDisconnected() {

    }

    // TODO : Network을 통해 accessToken을 발급중인데 다른 App에서 호출한다면?
    public String getAccessToken() {
        String accessToken = null;

        try {
            accessToken = mThinQNetworkService.getAccessToken();
        } catch (RemoteException e) {
            e.printStackTrace();
        }

        return accessToken;
    }

    public String getServerUrl() {
        String serverUrl = null;

        try {
            serverUrl = mThinQNetworkService.getServiceServerUrl();
        } catch (RemoteException e) {
            e.printStackTrace();
        }

        return serverUrl;
    }

    public Map<String, String> getDefaultHeaders() {
        Map<String, String> headers = new HashMap<>();

        try {
            headers = mThinQNetworkService.getDefaultHeaders();
        } catch (RemoteException e) {
            e.printStackTrace();
        }

        return headers;
    }
}
