package lge.home.thinq;

import com.google.gson.JsonObject;

public enum ThinQError {
    ERROR_NOERROR(0, "No error"),

    ERROR_FETAL_ERROR(1, "Fetal errors"),
    ERROR_INTERNAL_ERROR(2, "Internal errors"),
    ERROR_INVALID_PARAM(3, "Invalid params"),

    // 30~ 사용자 제품 등록 관련 error.
    ERROR_NO_DEVICE_REGISTRATION(30, "No device registration"),
    ERROR_FAILED_ADD_CLIENT(31, "Failed add client"),
    ERROR_FAILED_ADD_DEVICE(32, "Failed add device"),

    //
    ERROR_FAILED_DELETE_DEVICE(40, "Failed delete device"),

    ERROR_NETWORK_UNAVAILABLE(1000, "Unavailable internet connection"),

    ERROR_OPENAPI_RETURN_ERROR(2000, "Invalid params"),

    ERROR_MAX(9999, "Error max");

    private int mErrorCode;
    private String mErrorMessage;

    ThinQError(int errorCode, String message) {
        mErrorCode = errorCode;
        mErrorMessage = message;
    }

    public String toString() {
        JsonObject message = new JsonObject();
        message.addProperty("errorCode", mErrorCode);
        message.addProperty("errorText", mErrorMessage);
        return message.toString();
    }

    public static void throwException(String message) {
        throw new IllegalArgumentException(message);
    }
}
