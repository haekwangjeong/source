package lge.home.thinq;

import android.content.Context;
import android.os.Handler;
import android.os.RemoteException;

/**
 * Common base class for ThinQ Manager
 */
public abstract class ThinQManagerBase {

    private final ThinQAgent mAgent;

    public ThinQManagerBase(ThinQAgent agent) {
        mAgent = agent;
    }

    protected Context getContext() {
        return mAgent.getContext();
    }

    protected Handler getEventHandler() {
        return mAgent.getEventHandler();
    }

    protected <T> T handleRemoteExceptionFromThinQService(RemoteException e, T returnValue) {
        return mAgent.handleRemoteExceptionFromThinQService(e, returnValue);
    }

    protected void handleRemoteExceptionFromThinQService(RemoteException e) {
        mAgent.handleRemoteExceptionFromThinQService(e);
    }

    protected abstract void onServiceDisconnected();
}