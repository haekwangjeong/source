package lge.home.thinq;

import android.os.IBinder;
import android.os.RemoteException;

public class ThinQTokenManager extends ThinQManagerBase {
    IThinQToken mThinQTokenService;

    public ThinQTokenManager(ThinQAgent agent, IBinder service) {
        super(agent);

        mThinQTokenService = IThinQToken.Stub.asInterface(service);
    }

    @Override
    protected void onServiceDisconnected() {

    }

    // TODO : Network을 통해 accessToken을 발급중인데 다른 App에서 호출한다면?
    public String getAccessToken() {
        String accessToken = null;

        try {
            accessToken = mThinQTokenService.getAccessToken();
        } catch (RemoteException e) {
            e.printStackTrace();
        }

        return accessToken;
    }
}
