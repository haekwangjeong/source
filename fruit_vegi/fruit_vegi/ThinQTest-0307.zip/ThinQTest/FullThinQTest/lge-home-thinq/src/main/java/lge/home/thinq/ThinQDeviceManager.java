package lge.home.thinq;

import android.os.IBinder;
import android.os.RemoteException;

public class ThinQDeviceManager extends ThinQManagerBase {
    IThinQDevice mThinQDeviceService;

    public ThinQDeviceManager(ThinQAgent agent, IBinder service) {
        super(agent);

        mThinQDeviceService = IThinQDevice.Stub.asInterface(service);
    }

    @Override
    protected void onServiceDisconnected() {

    }

    public boolean addDevice(String accessToken, String refreshToken, String backendUrl) {
        boolean result = false;

        try {
            result = mThinQDeviceService.addDevice(accessToken, refreshToken, backendUrl);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }

    public boolean deleteDevice() {
        boolean result = false;

        try {
            result = mThinQDeviceService.deleteDevice();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }

    public boolean isDeviceRegistered() {
        boolean retval = false;

        try {
            retval = mThinQDeviceService.isDeviceRegistered();
        } catch (RemoteException e) {
            e.printStackTrace();
        }

        return retval;
    }

    public String controlDevice(String targetDeviceId, String jsonMessage) {
        String response = null;

        try {
            response = mThinQDeviceService.controlDeviceSync(targetDeviceId, jsonMessage);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return response;
    }
}
