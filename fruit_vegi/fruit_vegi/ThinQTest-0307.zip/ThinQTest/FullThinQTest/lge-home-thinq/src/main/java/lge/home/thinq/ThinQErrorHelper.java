package lge.home.thinq;

import java.util.HashMap;

public class ThinQErrorHelper {
    static HashMap<String, String> mErrorMap = new HashMap<>();

    static {
        ThinQError[] enumValues = ThinQError.values();
        for (ThinQError enumString : enumValues) {
            mErrorMap.put(enumString.name(), enumString.toString());
        }
    }

    static public String get(String key) {
        if (!mErrorMap.containsKey(key)) {
            return new String("{}");
        }

        return mErrorMap.get(key);
    }
}
