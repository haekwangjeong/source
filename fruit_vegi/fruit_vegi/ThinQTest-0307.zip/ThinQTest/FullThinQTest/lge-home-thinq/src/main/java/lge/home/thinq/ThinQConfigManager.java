package lge.home.thinq;

import android.os.IBinder;
import android.os.RemoteException;

public class ThinQConfigManager extends ThinQManagerBase {
    IThinQConfiguration mThinQConfigService;

    public ThinQConfigManager(ThinQAgent agent, IBinder service) {
        super(agent);

        mThinQConfigService = IThinQConfiguration.Stub.asInterface(service);
    }

    @Override
    protected void onServiceDisconnected() {

    }

    public String getCountry() {
        String country = null;

        try {
            country = mThinQConfigService.getCountry();
        } catch (RemoteException e) {
            e.printStackTrace();
        }

        return country;
    }

    public String getStage() {
        String stage = null;

        try {
            stage = mThinQConfigService.getStage();
        } catch (RemoteException e) {
            e.printStackTrace();
        }

        return stage;
    }

    public String getDeviceId() {
        String deviceId = null;

        try {
            deviceId = mThinQConfigService.getDeviceId();
        } catch (RemoteException e) {
            e.printStackTrace();
        }

        return deviceId;
    }

    public String getLogInUrl() {
        String logInUrl = null;

        try {
            logInUrl = mThinQConfigService.getLogInUrl();
        } catch (RemoteException e) {
            e.printStackTrace();
        }

        return logInUrl;
    }

    public String getLogOutUrl() {
        String logOutUrl = null;

        try {
            logOutUrl = mThinQConfigService.getLogOutUrl();
        } catch (RemoteException e) {
            e.printStackTrace();
        }

        return logOutUrl;
    }
    public String getShowTermsUrl() {
        String termsUrl = null;

        try {
            termsUrl = mThinQConfigService.getShowTermsUrl();
        } catch (RemoteException e) {
            e.printStackTrace();
        }

        return termsUrl;
    }

    public String getUpdateTermsUrl() {
        String termsUrl = null;

        try {
            termsUrl = mThinQConfigService.getUpdateTermsUrl();
        } catch (RemoteException e) {
            e.printStackTrace();
        }

        return termsUrl;
    }

}
