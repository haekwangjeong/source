package lge.home.thinq;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.ComponentName;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.RemoteException;
import android.os.TransactionTooLargeException;
import android.util.Log;

import androidx.annotation.GuardedBy;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

//import com.lge.service.thinq.ThinQService;

import java.util.HashMap;
import java.util.Objects;

public final class ThinQAgent {
    private static final String TAG = "ThinQAgent";

    private static final String THINQ_SERVICE_PACKAGE = "com.lge.service.thinq";

    public static final String THINQ_SERVICE_INTERFACE_NAME = "lge.home.thinqlib.IThinQ";

    private static final String THINQ_SERVICE_CLASS = "com.lge.service.thinq.ThinQService";

    public static final String CONFIG_SERVICE = "config_service";

    public static final String TOKEN_SERVICE = "token_service";

    public static final String DEVICE_SERVICE = "device_service";

    public static final String NETWORK_SERVICE = "network_service";

    private static final long THINQ_SERVICE_BIND_RETRY_INTERVAL_MS = 500;

    private static final int THINQ_SERVICE_BIND_MAX_RETRY = 5;

    private static final long THINQ_SERVICE_BINDER_POLLING_INTERVAL_MS = 100;

    private static final long THINQ_SERVICE_BINDER_POLLING_MAX_RETRY = 1000;

    private final Context mContext;

    private final Object mLock = new Object();

    /** Handler for generic event dispatching. */
    private final Handler mEventHandler;

    private final Handler mMainThreadEventHandler;

    private int mConnectionRetryCount;

    private final HashMap<String, ThinQManagerBase> mServiceMap = new HashMap<>();

    @GuardedBy("mLock")
    private IThinQ mService;
    @GuardedBy("mLock")
    private boolean mServiceBound;

    private int mConnectionState;
    private static final int STATE_DISCONNECTED = 0;
    private static final int STATE_CONNECTING = 1;
    private static final int STATE_CONNECTED = 2;

    private final ThinQServiceLifecycleListener mStatusChangeCallback;

    private final ServiceConnection mServiceConnectionListenerClient;

    public interface ThinQServiceLifecycleListener {
        /**
         * ThinQ service has gone through status change.
         *
         * This is always called in the main thread context.
         */
        void onLifecycleChanged(@NonNull ThinQAgent agent, boolean ready);
    }

    private final Runnable mConnectionRetryRunnable = new Runnable() {
        @Override
        public void run() {
            startThinQService();
        }
    };

    private final Runnable mConnectionRetryFailedRunnable = new Runnable() {
        @Override
        public void run() {
            mServiceConnectionListener.onServiceDisconnected(
                    new ComponentName(THINQ_SERVICE_PACKAGE, THINQ_SERVICE_CLASS)
            );
        }
    };

    private final ServiceConnection mServiceConnectionListener = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            Log.v(TAG, "ComponentName = " + name.toString());
            synchronized (mLock) {
                IThinQ newService = IThinQ.Stub.asInterface(service);
                if (newService == null) {
                    Log.e(TAG, "null binder service", new RuntimeException());
                    return;  // should not happen.
                }
                if (mService != null && mService.asBinder().equals(newService.asBinder())) {
                    // already connected.
                    return;
                }
                mConnectionState = STATE_CONNECTED;
                mService = newService;
            }
            if (mStatusChangeCallback != null) {
                mStatusChangeCallback.onLifecycleChanged(ThinQAgent.this, true);
            } else if (mServiceConnectionListenerClient != null) {
                mServiceConnectionListenerClient.onServiceConnected(name, service);
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            synchronized (mLock) {
                if (mConnectionState  == STATE_DISCONNECTED) {
                    // can happen when client calls disconnect before onServiceDisconnected call.
                    return;
                }
                handleThinQDisconnectLocked();
            }
            if (mStatusChangeCallback != null) {
                mStatusChangeCallback.onLifecycleChanged(ThinQAgent.this, false);
            } else if (mServiceConnectionListenerClient != null) {
                mServiceConnectionListenerClient.onServiceDisconnected(name);
            } else {
                // This client does not handle thinq service restart, so should be terminated.
                //finishClient();
            }
        }
    };


    public static ThinQAgent createThinQAgent(@NonNull Context context, @Nullable Handler handler) {
        assertNonNullContext(context);
        ThinQAgent agent = null;

        agent = new ThinQAgent(context, null,
                null /*serviceConnectionListener*/, null /*statusChangeListener*/, handler);

        agent.startThinQService();

        return agent;
    }

    public static ThinQAgent createThinQAgent(@NonNull Context context,
                                              @Nullable Handler handler,
                                              @NonNull ThinQServiceLifecycleListener statusChangeListener) {
        assertNonNullContext(context);
        ThinQAgent agent = null;

        agent = new ThinQAgent(context, null,
                null /*serviceConnectionListener*/, statusChangeListener, handler);

        agent.startThinQService();

        return agent;
    }


    private ThinQAgent(Context context, @Nullable IThinQ service,
                       @Nullable ServiceConnection serviceConnectionListener,
                       @Nullable ThinQServiceLifecycleListener statusChangeListener,
                       @Nullable Handler handler) {
        mContext = context;
        mEventHandler = determineEventHandler(handler);
        mMainThreadEventHandler = determineMainThreadEventHandler(mEventHandler);

        mService = service;
        if (service != null) {
            mConnectionState = STATE_CONNECTED;
        } else {
            mConnectionState = STATE_DISCONNECTED;
        }
        mServiceConnectionListenerClient = serviceConnectionListener;
        mStatusChangeCallback = statusChangeListener;
    }

    private static Handler determineMainThreadEventHandler(Handler eventHandler) {
        Looper mainLooper = Looper.getMainLooper();
        return (eventHandler.getLooper() == mainLooper) ? eventHandler : new Handler(mainLooper);
    }

    private static Handler determineEventHandler(@Nullable Handler handler) {
        if (handler == null) {
            Looper looper = Looper.getMainLooper();
            handler = new Handler(looper);
        }
        return handler;
    }

    private static void assertNonNullContext(Context context) {
        Objects.requireNonNull(context);
        if (context instanceof ContextWrapper
                && ((ContextWrapper) context).getBaseContext() == null) {
            throw new NullPointerException(
                    "ContextWrapper with null base passed as Context, forgot to set base Context?");
        }
    }

    private void startThinQService() {
        Intent intent = new Intent();
        intent.setPackage(THINQ_SERVICE_PACKAGE);
        // TODO : for test app
        try {
            intent.setClass(mContext, Class.forName("com.lge.service.thinq.ThinQService"));
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        intent.setAction(THINQ_SERVICE_INTERFACE_NAME);

        boolean bound = mContext.bindService(intent, mServiceConnectionListener, Context.BIND_AUTO_CREATE);

        synchronized (mLock) {
            if (!bound) {
                mConnectionRetryCount++;
                if (mConnectionRetryCount > THINQ_SERVICE_BIND_MAX_RETRY) {
                    Log.w(TAG, "cannot bind to thinq service after max retry");
                    mMainThreadEventHandler.post(mConnectionRetryFailedRunnable);
                } else {
                    mEventHandler.postDelayed(mConnectionRetryRunnable,
                            THINQ_SERVICE_BIND_RETRY_INTERVAL_MS);
                }
            } else {
                mEventHandler.removeCallbacks(mConnectionRetryRunnable);
                mMainThreadEventHandler.removeCallbacks(mConnectionRetryFailedRunnable);
                mConnectionRetryCount = 0;
                mServiceBound = true;
            }
        }
    }

    private void handleThinQDisconnectLocked() {
        if (mConnectionState == STATE_DISCONNECTED) {
            // can happen when client calls disconnect with onServiceDisconnected already called.
            return;
        }
        mEventHandler.removeCallbacks(mConnectionRetryRunnable);
        mMainThreadEventHandler.removeCallbacks(mConnectionRetryFailedRunnable);
        mConnectionRetryCount = 0;
        //tearDownCarManagersLocked();
        mService = null;
        mConnectionState = STATE_DISCONNECTED;
    }

    private void tearDownThinQManagersLocked() {
//        // All disconnected handling should be only doing its internal cleanup.
//        for (CarManagerBase manager: mServiceMap.values()) {
//            manager.onCarDisconnected();
//        }
//        mServiceMap.clear();
    }

    public boolean isConnected() {
        synchronized (mLock) {
            return mService != null;
        }
    }

    public Context getContext() {
        return mContext;
    }

    public Handler getEventHandler() {
        return mEventHandler;
    }

    public <T> T handleRemoteExceptionFromThinQService(RemoteException e, T returnValue) {
        handleRemoteExceptionFromThinQService(e);
        return returnValue;
    }

    void handleRemoteExceptionFromThinQService(RemoteException e) {
        if (e instanceof TransactionTooLargeException) {
            Log.w(TAG, "ThinQ service threw TransactionTooLargeException", e);
            throw new UnsupportedOperationException(e);
        } else {
            Log.w(TAG, "ThinQ service has crashed", e);
        }
    }

    private ThinQManagerBase createThinQManagerLocked(String serviceName, IBinder binder) {
        ThinQManagerBase manager = null;

        switch (serviceName) {
            case CONFIG_SERVICE:
                manager = new ThinQConfigManager(this, binder);
                break;
            case TOKEN_SERVICE:
                manager = new ThinQTokenManager(this, binder);
                break;
            case DEVICE_SERVICE:
                manager = new ThinQDeviceManager(this, binder);
                break;

            case NETWORK_SERVICE:
                manager = new ThinQNetworkManager(this, binder);
                break;
            default:
                break;
        }

        return manager;
    }

    public Object getManager(String serviceName) {
        ThinQManagerBase manager;

        synchronized (mLock) {
            if (mService == null) {
                Log.w(TAG, "getManager not working while thinq service not ready");
                return null;
            }
            manager = mServiceMap.get(serviceName);
            if (manager == null) {
                try {
                    IBinder binder = mService.getThinQService(serviceName);
                    if (binder == null) {
                        Log.w(TAG, "getManager could not get binder for service:"
                                + serviceName);
                        return null;
                    }
                    manager = createThinQManagerLocked(serviceName, binder);
                    if (manager == null) {
                        Log.w(TAG, "getManager could not create manager for service:"
                                + serviceName);
                        return null;
                    }
                    mServiceMap.put(serviceName, manager);
                } catch (RemoteException e) {
                    handleRemoteExceptionFromThinQService(e);
                }
            }
        }

        return manager;
    }

}
